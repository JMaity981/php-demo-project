<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/
// Route::post('db-bkp', 'Controller@dbBkp');
Route::get('db-export', 'Controller@dbexport');
// Route::get('save-zip-file', 'Controller@saveZipFile')->middleware('web');
Route::get('download-any-file', 'Controller@downloadAnyFile')->middleware('web');
Route::get('/', 'LoginCtrl@login')->middleware('web','prevent-back-history', 'beforelogin');
Route::post('login-auth', 'LoginCtrl@loginauth')->middleware('web','prevent-back-history', 'beforelogin');
Route::post('change-password','LoginCtrl@cngPsw')->middleware('web','prevent-back-history', 'afterlogin');

Route::get('get-stock-details','Controller@getStockDetails')->middleware('web','prevent-back-history', 'afterlogin');	

	/*================== Lager Route =============*/
Route::get('ledger', 'LedgerCtrl@ledger')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('add-ledger', 'LedgerCtrl@addLager')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('userregistration-ajax-tbl', 'LedgerCtrl@userregistrationAjaxTbl')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('customer-status-change', 'LedgerCtrl@customerStatusChange')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('customer-delete', 'LedgerCtrl@customerDelete')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('customer-update', 'LedgerCtrl@customerUpdate')->middleware('web','prevent-back-history', 'afterlogin');

	/*================== Received Route =============*/
Route::get('received', 'ReceivedCtrl@received')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('get-ledger-data','ReceivedCtrl@getLedgerData')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('insert-received-data','ReceivedCtrl@insertReceivedData')->middleware('web','prevent-back-history', 'afterlogin');
// Route::post('get-rate-data', 'ReceivedCtrl@getRateData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('generate-bill-pdf','PdfCtrl@generateBillPdf')->middleware('web','prevent-back-history', 'afterlogin');

	/*================== Delivery Route =============*/
Route::get('delivery', 'DeliveryCtrl@delivery')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('delivery-tbl-data', 'DeliveryCtrl@deliveryTblData')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('delivery-submit', 'DeliveryCtrl@deliverySubmit')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('delete-delivery', 'DeliveryCtrl@deleteDelivery')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('xrf-man-update', 'DeliveryCtrl@xrfManUpdate')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('lager-man-update', 'DeliveryCtrl@lagerManUpdate')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('get-received-data', 'DeliveryCtrl@getReceivedData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('xrf-man-update-view', 'DeliveryCtrl@xrfManUpdateView')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('lager-man-update-view', 'DeliveryCtrl@lagerManUpdateView')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('checked-xrf-change', 'DeliveryCtrl@checkedXrfChange')->middleware('web','prevent-back-history', 'afterlogin');

		/*================== Statement Route =============*/
//---------------------------Party Deu Deposite
Route::get('party-due-deposite-statement', 'StatementCtrl@partyDueDepositeStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('party-due-deposite-statement-data', 'StatementCtrl@partyDueDepositeStatementData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('party-due-deposite-statement-pdf', 'PdfCtrl@partyDueDepositeStatementPdf')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------Daily Seet
Route::get('daily-seet-statement', 'StatementCtrl@dailySeetStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('daily-seet-statement-data', 'StatementCtrl@dailySeetStatementData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('daily-seet-statement-pdf', 'PdfCtrl@dailySeetStatementPdf')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------Card In Out
Route::get('card-in-out-statement', 'StatementCtrl@cardInOutStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('card-in-out-statement-data', 'StatementCtrl@cardInOutStatementData')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------Rebons In Out
Route::get('rebons-in-out-statement', 'StatementCtrl@rebonsInOutStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('rebons-in-out-statement-data', 'StatementCtrl@rebonsInOutStatementData')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------Photo In Out
Route::get('photo-in-out-statement', 'StatementCtrl@photoInOutStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('photo-in-out-statement-data', 'StatementCtrl@photoInOutStatementData')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------Absent Party
Route::get('absent-party-statement', 'StatementCtrl@absentPartyStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('absent-party-statement-data', 'StatementCtrl@absentPartyStatementData')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------All Party Due
Route::get('all-party-due-statement', 'StatementCtrl@allPartyDueStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('all-party-due-statement-data', 'StatementCtrl@allPartyDueStatementData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('all-party-due-statement-pdf', 'PdfCtrl@allPartyDueStatementPdf')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------Monthly Working Sheet
Route::get('monthly-working-sheet-statement', 'StatementCtrl@monthlyWorkingSheetStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('monthly-working-sheet-statement-data', 'StatementCtrl@monthlyWorkingSheetStatementData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('monthly-working-sheet-statement-pdf', 'PdfCtrl@monthlyWorkingSheetStatementPdf')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('clear-all-data', 'StatementCtrl@clearAllData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('clear-data', 'StatementCtrl@clearData')->middleware('web','prevent-back-history', 'afterlogin');
//---------------------------Own Fund
Route::get('own-fund-statement', 'StatementCtrl@ownFundStatement')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('own-fund-statement-data', 'StatementCtrl@ownFundStatementData')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('own-fund-statement-pdf', 'PdfCtrl@ownFundStatementPdf')->middleware('web','prevent-back-history', 'afterlogin');


	/*================== Stock Update Route =============*/
Route::get('stock-update', 'StockUpdateCtrl@stockUpdate')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('card-in', 'StockUpdateCtrl@cardIn')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('photo-in', 'StockUpdateCtrl@photoIn')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('rebons-in', 'StockUpdateCtrl@rebonsIn')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('card-rebons-out', 'StockUpdateCtrl@cardRebonsOut')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('photo-out', 'StockUpdateCtrl@photoOut')->middleware('web','prevent-back-history', 'afterlogin');

	/*================== Rate Update Route =============*/
Route::get('rate-update', 'RateUpdateCtrl@rateUpdate')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('ledger-tbl-rate-data', 'RateUpdateCtrl@ledgerTblRateData')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('insert-rate-update', 'RateUpdateCtrl@insertRateUpdate')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('ledger-rate-update', 'RateUpdateCtrl@ledgerRateUpdate')->middleware('web','prevent-back-history', 'afterlogin');

	/*================== Customer Fund Route =============*/
Route::get('customer-fund', 'CustomerFundCtrl@customerFund')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('customer-fund-submit', 'CustomerFundCtrl@customerFundSubmit')->middleware('web','prevent-back-history', 'afterlogin');

	/*================== Expenses Route =============*/
Route::get('expenses', 'ExpensesCtrl@expenses')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('expenses-submit', 'ExpensesCtrl@expensesSubmit')->middleware('web','prevent-back-history', 'afterlogin');
Route::get('expenses-tbl-data', 'ExpensesCtrl@expensesTblData')->middleware('web','prevent-back-history', 'afterlogin');

	/*================== Own Fund Route =============*/
Route::get('own-fund', 'OwnFundCtrl@ownFund')->middleware('web','prevent-back-history', 'afterlogin');
Route::post('own-fund-submit', 'OwnFundCtrl@ownFundSubmit')->middleware('web','prevent-back-history', 'afterlogin');


Route::get('logout', function(){
	session()->forget('is_login');
	session()->forget('username');
	session()->flush();
	return Redirect::to('/');
})->middleware('web', 'prevent-back-history');





	



