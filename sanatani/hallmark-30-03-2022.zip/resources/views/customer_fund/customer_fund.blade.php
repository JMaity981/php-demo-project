@extends('common.layout')
@section('title', 'Custmer Fund')
@section('style')
	{!! Html::style('public/assets/plugins/select2/css/select2.min.css')!!}
	{!! Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css')!!}
	{!! Html::style('public/assets/plugins/notifications/css/lobibox.min.css') !!}
@endsection
@section('script')
	
	{!! Html::script('public/assets/pages-js/CustomerFund.js') !!}
	{!! Html::script('public/assets/plugins/select2/js/select2.min.js') !!}
	{!! Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js') !!}
	{!! Html::script('public/assets/js/sweetalert.js') !!}
	{!! Html::script('public/assets/plugins/notifications/js/lobibox.min.js') !!}
	{!! Html::script('public/assets/plugins/notifications/js/notifications.min.js') !!}
	
	<script>
		CommonJS.getStockDetails();
		CommonJS.SingleDropdown();
		CommonJS.NumberValidation();
		CustomerFundJs.CustomerFund();
	</script>

@endsection
@section('content')
    <div class="card reg-frm-loder">
        <div class="card-header">
            <h4>Customer Fund</h4>
        </div>
        {{ Form::open(['id' => 'customerFundForm']) }}
            <div class="card-body row">
                <div class="col-md-5 col-sm-5 col-lg-5">
                    <label>Select Jewellers Name / Proprietor Name:</label>
                    <div class="input-group">
                        <select class = "single-select ledger_name" id="jn" name="ledger_name">
                            <option value="" disabled selected>Select Jewellers Name / Propriter Name</option>
                            @foreach($data['ledger'] as $key=> $ledger_data)
                                <option value="{{ $ledger_data['id'] }}">{{ $ledger_data['jewellers_name'] }} / {{ $ledger_data['propriter_name'] }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-lg-3">
                    <label>Address:</label>
                    <input class="form-control address" type="text" placeholder="Address" disabled>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <label>Phone No.:</label>
                    <input class="form-control ph_no" type="text" placeholder="Phone no" disabled>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <label>Old Due:</label>    
                    <input class="form-control old_due" type="text" id="old_due" disabled>
                </div>
            </div>
            <div class="card-body row">
                <div class="col-md-7 col-sm-7 col-lg-7">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Remarks</span>
                        </div>
                        <input class="form-control remarks" type="text" name="remarks">
                    </div>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fadeIn animated bx bx-rupee"></i></span>
                        </div>
                        <input class="form-control number-validate amount" type="text" name="amount">
                    </div>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <div class="wraper">
                        <input type="radio" name="transaction_type" id="transaction_type1" value="C">
                        <input type="radio" name="transaction_type" id="transaction_type2" value="D">
                        <label for="transaction_type1" class="option credit-option">
                            <div class="sales dot"></div>
                            <span>Credit</span>
                        </label>
                        <label for="transaction_type2" class="option debit-option">
                            <div class="purchase dot"></div>
                            <span>Debit</span>
                        </label>
                    </div>
                </div>
                <div class="col-md-1 col-sm- col-lg-1">
                    <button type="submit" class="btn btn-primary finish-btn">Submit</button>
                </div>
            </div>
        {{ Form::close() }}
	</div>
    {{-----------------STOCK SHOW-------------------}}
    <div class='card'>
        <div class="col-md-12 card-body render-info-box">
        </div>
    </div>
@endsection