@extends('common.layout')
@section('title', 'Received')
@section('style')
	{!! Html::style('public/assets/plugins/select2/css/select2.min.css')!!}
	{!! Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css')!!}
	{!! Html::style('public/assets/plugins/notifications/css/lobibox.min.css') !!}
@endsection
@section('script')
	
	{!! Html::script('public/assets/pages-js/Received.js') !!}
	{!! Html::script('public/assets/plugins/select2/js/select2.min.js') !!}
	{!! Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js') !!}
	{!! Html::script('public/assets/plugins/notifications/js/lobibox.min.js') !!}
	{!! Html::script('public/assets/plugins/notifications/js/notifications.min.js') !!}
	
	<script>
		CommonJS.getStockDetails();
		CommonJS.SingleDropdown();
		CommonJS.NumberValidation();
		CommonJS.NumberValidationIntger();
		ReceivedJs.Received();
	</script>

@endsection
@section('content')
    <div class="card reg-frm-loder">
        <div class="card-header"><h4>Received</h4></div>
		<div class="tab-content mt-3">
			<div class="tab-pane fade show active" id="Recived">
				<div class="card-body">
					{{ Form::open(['id' => 'receivedForm']) }}
						<input type="hidden" class="ledger_id" name="ledger_id">
						{{-- <input type="hidden" class="h_rate" name="h_rate">
						<input type="hidden" class="h_rate_4" name="h_rate_4">
						<input type="hidden" class="o_rate" name="o_rate">
						<input type="hidden" class="card_rate" name="card_rate">
						<input type="hidden" class="photo_rate" name="photo_rate"> --}}
						<input type="hidden" class="card_view" name="card_view" value="H">
						<input type="hidden" class="photo_view" name="photo_view" value="H">
						<div class="card">
							<div class="card-body">
								<div class="row">
									<div class="col-md-1 col-sm-1 col-lg-1">
										<button type="button" id="manualTypeBtn" class="btn btn-info btn-sm manual-type-btn">Manual Type</button>
										<button type="button" id="selectLedgerBtn" class="btn btn-info btn-sm d-none select-ledger-btn">Select Ledger</button>
									</div>
									<div class="col-md-6 col-sm-6 col-lg-6 div-ledger">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Jewellers/Propriter</span>
											</div>
											<select class = "single-select ledger_name" id="jn" >
												<option value="" disabled selected>Select Jewellers Name / Propriter Name</option>
												@foreach($data['ledger'] as $key=> $ledger_data)
													<option value="{{ $ledger_data['id'] }}">{{ $ledger_data['jewellers_name'] }} / {{ $ledger_data['propriter_name'] }}</option>
												@endforeach
											</select>
										</div>
									</div>
									<div id="customerName" class="col-md-6 col-sm-6 col-lg-6 d-none">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Customer Name</span>
											</div>
											<input class="form-control customer_name" type="text" name="customer_name">
										</div>
									</div>
									<div class="col-md-3 col-sm-3 col-lg-3">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Token No.</span>
											</div>
											<input class="form-control token_no" name="token_no" type="text" placeholder="Token No">
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">SL No.</span>
											</div>
											<input class="form-control sl_no" type="text" name="sl_no" value="{{$data['sl_no']}}"  disabled>
										</div>
									</div>
									<div class="col-md-1 col-sm-1 col-lg-1"></div>
									<div class="col-md-6 col-sm-6 col-lg-6 div-ledger">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Address</span>
											</div>
											<input class="form-control address" type="text" placeholder="Address" disabled>
										</div>
									</div>
									<div class="col-md-3 col-sm-3 col-lg-3 div-ledger">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Phone No.</span>
											</div>
											<input class="form-control ph_no" type="text" placeholder="Phone no" disabled>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2 div-ledger">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Old Due</span>
											</div>
											<input class="form-control old_due" type="text" id="old_due" disabled>
										</div>
									</div>
								</div>
							</div>	
						</div>
						<div class="card">
							<div class="card-body">
								<div class="row">
									<div class="col-md-2 col-sm-2 col-lg-2 mb-2 form-group select2">
										<label>Select Type:</label><br>
										<div class="wraper">
											<input type="radio" name="type" id="typeHid" value="H">
											<input type="radio" name="type" id="typeOid" value="O">
											<label for="typeHid" class="option type-h-option">
												<div class="dot"></div>
												<span>H</span>
											</label>
											<label for="typeOid" class="option type-o-option">
												<div class="dot"></div>
												<span>O</span>
											</label>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<div class="form-group">
											<label>Weight:</label>
											<div class="input-group">
												<input class="form-control number-validate weight" type="text" placeholder="Weight" name="weight">
												<div class="input-group-prepend">
													<span class="input-group-text">gm.</span>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-1 col-sm-1 col-lg-1">
										<div class="form-group">
											<label>Piece:</label>
											<input class="form-control number-validate-int piece" name="piece" type="text" placeholder="Piece">
										</div>
									</div>
									<div class="col-md-1 col-sm-1 col-lg-1">
										<div class="form-group">
											<label>Purity:</label>
											<input class="form-control number-validate purity" type="text" placeholder="Purity" name="purity">
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<div class="form-group">
											<label>Logo:</label>
											<input class="form-control logo" type="text" disabled>
										</div>
									</div>
									<div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>Remarks:</label>
											<input class="form-control remarks" type="text" placeholder="Enter Remarks" name="remarks">
										</div>
									</div>
								</div>
							</div>	
						</div>
						<div id="cardShowHide" class="card d-none">
							<div class="card-body">
								<div class="row add-sample-row-card">
									<div class="col-md-3 col-sm-3 col-lg-3">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Card Weight</span>
											</div>
											<input class="form-control number-validate card_weight" type="text" name="card_weight[]">
											<div class="input-group-prepend">
												<span class="input-group-text">gm.</span>
											</div>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Card Piece</span>
											</div>
											<input class="form-control number-validate-int card_piece" type="text" name="card_piece[]">
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-lg-6">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Card Remarks</span>
											</div>
											<input class="form-control card_remarks" type="text" name="card_remarks[]">
										</div>
									</div>
									<div class="col-md-1 col-sm-1 col-lg-1">
										<button type="button" class="btn btn-primary btn-sm card-append-btn">
											<i class="fadeIn animated bx bx-plus"></i>
										</button>
									</div>
								</div>
							</div>
						</div>
						<div id="photoShowHide" class="card d-none">
							<div class="card-body">
								<div class="row add-sample-row-photo">
									<div class="col-md-3 col-sm-3 col-lg-3">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Photo Weight</span>
											</div>
											<input class="form-control number-validate photo_weight" type="text" name="photo_weight[]">
											<div class="input-group-prepend">
												<span class="input-group-text">gm.</span>
											</div>
										</div>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Photo Piece</span>
											</div>
											<input class="form-control number-validate-int photo_piece" type="text" name="photo_piece[]">
										</div>
									</div>
									<div class="col-md-6 col-sm-6 col-lg-6">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text">Photo Remarks</span>
											</div>
											<input class="form-control photo_remarks" type="text" name="photo_remarks[]">
										</div>
									</div>
									<div class="col-md-1 col-sm-1 col-lg-1">
										<button type="button" class="btn btn-primary btn-sm photo-append-btn">
											<i class="fadeIn animated bx bx-plus"></i>
										</button>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-body">
								<div class="row">
									<div class="col-md-5 col-sm-5 col-lg-5">
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<button type="button" id="cardShowBtn" class="btn btn-info card-show-btn">Card Show</button>
										<button type="button" id="cardHideBtn" class="btn btn-danger d-none card-hide-btn">Card Hide</button>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<button type="button" id="photoShowBtn" class="btn btn-info photo-show-btn">Photo Show</button>
										<button type="button" id="photoHideBtn" class="btn btn-danger d-none photo-hide-btn">Photo Hide</button>
									</div>
									<div class="col-md-2 col-sm-2 col-lg-2">
										<label  class="fs-18">
											Print Enable
											<input type="checkbox" name="print" class="w-28 h-18 print-enable" checked>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										</label>
									</div>
									<div class="col-md-1 col-sm- col-lg-1">
										<button type="submit" class="btn btn-primary finish-btn">Submit</button>
									</div>
								</div>
							</div>
						</div>
					{{ Form::close() }}
				</div>
			</div>
		</div>
	</div>
	{{-----------------STOCK SHOW-------------------}}
    <div class='card'>
        <div class="col-md-12 card-body render-info-box">
        </div>
    </div>
@endsection