

<div class="form-row">
	<div class="col-md-6">
		<div class="form-group">
			<label>Date Range</label>
			<input type="hidden" name="daterange" class="form-control daterange">
			<div id="reportrange" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
				<i class="fa fa-calendar"></i>&nbsp;
				<span></span> <i class="fa fa-caret-down"></i>
			</div>
		</div>
	</div>
	{{-- <input type = "hidden" class="hidden_pageno" value="0">
	<input type="hidden" class="hidden_filepath" value=""> --}}
	<div class="col-md-5">
		<div class="form-group">
			<label>Select Jewellers Name / Proprietor Name</label>
			<select class="single-select ledger-id" name="ledger_id">
				<option value="" disabled selected>Select Jewellers Name / Proprietor Name</option>
				 @foreach ($data['ledger'] as $key => $ledger_data)
					<option value="{{ $ledger_data['id'] }}">{{ $ledger_data['jewellers_name'] }} / {{ $ledger_data['propriter_name'] }} </option>
				@endforeach 
			</select>
		</div>
	</div>
	<div class="col-md-1">
		<label for="validationCustom02">&nbsp;</label>
		<div class="form-group">
			<button class="btn btn-primary statement-search" type="button">Search</button>
		</div>
	</div>
</div>

<script>
	$(function() {
		var start = moment().subtract(29, 'days');
		var end = moment();

		function cb(start, end) {
			$('#reportrange span').html(start.format('D/MM/YYYY') + ' - ' + end.format('D/MM/YYYY'));
			$(".daterange").val(start.format('D/MM/YYYY') + ' - ' + end.format('D/MM/YYYY'));
		}

		$('#reportrange').daterangepicker({
			"autoApply": true,
			startDate: start,
			endDate: end,
			ranges: {
			'Today': [moment(), moment()],
			'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			'This Month': [moment().startOf('month'), moment().endOf('month')],
			'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
			}
		}, cb);

		cb(start, end);
		//$(".sarchtable").trigger("click");
	});
</script>