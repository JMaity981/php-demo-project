@extends('common.layout')
@section('title', 'Ledger')
@section('style')
	{!! Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css') !!}
	{!! Html::style('public/assets/plugins/datatable/css/buttons.bootstrap4.min.css') !!}
	{!! Html::style('public/assets/plugins/notifications/css/lobibox.min.css') !!}
@endsection
@section('script')
	{!! Html::script('public/assets/plugins/notifications/js/lobibox.min.js') !!}
	{!! Html::script('public/assets/plugins/notifications/js/notifications.min.js') !!}
	{!! Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js') !!}
	{!! Html::script('public/assets/js/sweetalert.js') !!}
	{!! Html::script('public/assets/pages-js/Ledger.js') !!}
	
	<script>
		LedgerJs.Ledger();
		CommonJS.NumberValidation();
		CommonJS.NumberValidationIntger();
	</script>
	<script>
		function img_pathUrl(input){
		    if(input.files[0] != ''){
		        $('#img_url').removeClass('d-none');
		        $('#img_url')[0].src = (window.URL ? URL : webkitURL).createObjectURL(input.files[0]);
		    }
		}
	</script>
@endsection
@section('content')
    <div class="color-acordians reg-frm-loder">
		<div id="accordion2" class="accordion">
			<div class="card">
				<div class="card-header collapsed bg-primary cursor-pointer" data-toggle="collapse" href="#collapsefour">	
					<a class="card-title text-white collapse-title">
						Ledger List
					</a>
				</div>
				<div id="collapsefour" class="card-body collapse" data-parent="#accordion2">
					{{ Form::open(array('url' => 'add-ledger' , 'id' => 'ledger' , 'autocomplete' => 'off' , 'files' => 'true' , 'enctype' => "multipart/form-data")) }}
						<input type = "hidden" name="hidden_userid" class="hiddenuserid">
						<input type = "hidden" name = "hidden_mb_no" class = "hidden_mb_no">
						{{-- <input type = "hidden" name = "hidden_file_name" class = "hidden_file_name"> --}}
						<div class="row">
							<div class="col-md-9 col-sm-9 col-lg-9">
								<div class="row">
									<div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>Jewellers Name:</label>
											<input type="text" class="form-control jewellers_name" placeholder="Enter Jewellers Name" name="jewellers_name">
										</div>
									</div>
									<div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>Proprietor Name:</label>
											<input type="text" class="form-control propriter_name" placeholder="Enter Proprietor Name" name="propriter_name">
										</div>
									</div>
									<div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>PH No:</label>
											<input type="text" class="form-control number-validate-int ph_no" placeholder="Enter Phone number" name="ph_no">
										</div>
									</div>
									<div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>L/C No.(optional):</label>
												<input type="text" class="form-control lc_no" placeholder="Enter L/C No." name="lc_no">
										</div>
									</div>
									<div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>GST No.(optional):</label>
											<input type="text" class="form-control gst_no" placeholder="Enter GST No." name="gst_no">
										</div>
									</div>
									{{-- <div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>User Image:</label>
											<div class="custom-file">
												<input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" name="user_photo">
												<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
											</div>
										</div>
									</div> --}}
									<div class="col-md-4 col-sm-4 col-lg-4">
										<div class="form-group">
											<label>Logo:</label>
											<input type="text" class="form-control logo" placeholder="Enter Logo" name="logo">
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-3 col-sm-3 col-lg-3">
								<div class="form-group">
									<label>Address:</label>
									{{-- <input type="text" class="form-control address" placeholder="Enter Address" name="address"> --}}
									<textarea class="form-control" id="address" placeholder="Enter address" name="address"></textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-10"></div>
							<div class="col-md-2 col-sm-2 col-lg-2">
								<button type="submit" class="btn btn-primary user-reg-btn float-right">Save</button>
							</div>
						</div>
					{{ Form::close() }}
				</div>
			</div>
			<div class="card">
				<div class="card-body">
					<div class="table-responsive">
						<table id="user_list_tbl" class="table table-striped table-bordered" style="width:100%">
							<thead class="thead-dark">
								<tr>
									<th>Jewellers Name</th>
									<th>Proprietor Name</th>
									<th>Phone No</th>
									<th>L/C No.</th>
									<th>GST No.</th>
									<th>Address</th>
									<th>Logo</th>
									<th style="width: 0px;">Is Active</th>
									<th style="width: 0px;">Action</th>
								</tr>
							</thead>
							<tbody>
								
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	
					
@endsection