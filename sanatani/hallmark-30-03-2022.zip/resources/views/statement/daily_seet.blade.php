@extends('common.layout')
@section('title', 'Statement')
@section('style')
    {!! Html::style('public/assets/plugins/select2/css/select2.min.css') !!}
    {!! Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css') !!}
    {!! Html::style('public/assets/plugins/notifications/css/lobibox.min.css') !!}
    {!! Html::style('public/assets/npm/daterangepicker/daterangepicker.css') !!}
    {!! Html::style('public/assets/npm/date-picker/bootstrap-datepicker.css') !!}
	{!! Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css') !!}
@endsection

@section('script')
    {!! Html::script('public/assets/plugins/select2/js/select2.min.js') !!}
    {!! Html::script('public/assets/plugins/notifications/js/notifications.min.js') !!}
    {!! Html::script('public/assets/momentjs/latest/moment.min.js') !!}
    {!! Html::script('public/assets/npm/daterangepicker/daterangepicker.min.js') !!}
    {!! Html::script('public/assets/npm/date-picker/bootstrap-datepicker.js') !!}
    {!! Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js') !!}
    {!! Html::script('public/assets/pages-js/Statement.js') !!}

    <script>
        CommonJS.SingleDropdown();
		StatementJs.DailySeet();
        $(".datepicker").datepicker({
	        autoclose: true,
	        todayHighlight: true,
	        format: "dd/mm/yyyy"
	    });
        $('.datepicker').datepicker({ dateFormat: 'dd/mm/yyyy' });
        $('.datepicker').datepicker('setDate', new Date());
    </script>
   
@endsection
@section('content')
    <div class="card">
        <div class="card-body">
            <div class="card-title">
                <h5 class="mb-0">Search Daily Sheet</h5>
            </div>
			<hr />
			<div class="form-row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label>Select Date</label>
                        <input type="text" class="form-control datepicker" name="datepicker" placeholder="dd/mm/yyyy">
                    </div>
                </div>
                <input type = "hidden" class="hidden_pageno" value="0">
                <input type="hidden" class="hidden_filepath" value="">
                <div class="col-md-1">
                    <label for="validationCustom02">&nbsp;</label>
                    <div class="form-group">
                        <button class="btn btn-primary statement-search" type="button">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="card-title">
				<div class="row">
					<div class="col-md-9">
						<h5 class="mb-0">Daily Sheet</h5>
					</div>
					<div class="col-md-3">
						<button type="button" class="btn btn-primary btn-sm ml-5 daily-seet-download float-right">Download Statement</button>
					</div>
				</div>
            </div>
            <hr />
			<input type="hidden" class="hidden_tbl_id" value="dailySeetStatementTbl">
            <table class="table table-bordered" id="dailySeetStatementTbl" style="width:100%">
                <thead class="thead-dark ">
                    <tr>
                        <th scope="col">Sl No.</th>
                        {{-- <th scope="col">Token No.</th> --}}
                        <th scope="col">Jewellers/ Customer Name</th>
                        {{-- <th scope="col">Propriter Name</th> --}}
                        <th scope="col">Received Weight</th>
                        <th scope="col">Delivery Weight</th>
                        <th scope="col">Ornament Piece</th>
                        <th scope="col">Hallmark ch./pcs.</th>
                        {{-- <th scope="col">Card</th> --}}
                        <th scope="col">Card rate/P</th>
                        {{-- <th scope="col">Photo</th> --}}
                        <th scope="col">Photo rate/P</th>
                        <th scope="col">Received Time</th>
                        <th scope="col">Delivery<br>Time</th>
                        <th scope="col">Total Amount</th>
                        <th scope="col">Due</th>
                        <th scope="col">Discount</th>
                        <th scope="col">Received</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

@endsection
