{{-- <?php
    print_r($data['year_month']);die;
?> --}}
@extends('common.layout')
@section('title', 'Statement')
@section('style')
    {!! Html::style('public/assets/plugins/select2/css/select2.min.css') !!}
    {!! Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css') !!}
    {!! Html::style('public/assets/plugins/notifications/css/lobibox.min.css') !!}
    {!! Html::style('public/assets/npm/daterangepicker/daterangepicker.css') !!}
	{!! Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css') !!}
    <style>
        label {
            display: block;
            font: 1rem 'Fira Sans', sans-serif;
        }
        input,
        label {
            margin: .4rem 0;
        }
    </style>
@endsection
<style>
    label {
        display: block;
        font: 1rem 'Fira Sans', sans-serif;
    }
    input,
    label {
        margin: .4rem 0;
    }
</style>

@section('script')
    {!! Html::script('public/assets/plugins/select2/js/select2.min.js') !!}
    {!! Html::script('public/assets/plugins/notifications/js/notifications.min.js') !!}
    {!! Html::script('public/assets/momentjs/latest/moment.min.js') !!}
    {!! Html::script('public/assets/npm/daterangepicker/daterangepicker.min.js') !!}
    {!! Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js') !!}
	{!! Html::script('public/assets/js/sweetalert.js') !!}
    {!! Html::script('public/assets/pages-js/Statement.js') !!}

    <script>
        CommonJS.SingleDropdown();
		StatementJs.MonthlyWorkingSheet();
    </script>
   
@endsection
@section('content')
    <div class="card">
        <div class="card-body">
            <div class="card-title row">
                <div class="col-md-9">
                    <h5 class="mb-0">Search Monthly Working Sheet Statement</h5>
                </div>
                <div class="col-md-3">
                    <button class="btn btn-warning float-right btn-sm clear-data" type="button">Clear Data</button>
                    <button class="btn btn-danger float-right btn-sm mr-2 clear-all-data" type="button">Clear All Data</button>
                </div>
            </div>
			<hr />
			<div class="form-row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="start">Select Month:</label>
                        {{-- <input type="month" id="start" name="start" min="2022-01" value="2022-03" class="form-control month-year"> --}}
                        <input type="month" id="start" name="start" min="2022-01" value="{{$data['year_month']}}" class="form-control month-year">
                    </div>
                </div>
                <div class="col-md-1">
                    <label for="validationCustom02">&nbsp;</label>
                    <div class="form-group">
                        <button class="btn btn-primary statement-search" type="button">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="card-title">
				<div class="row">
					<div class="col-md-9">
						<h5 class="mb-0">Monthly Working Sheet</h5>
					</div>
					<div class="col-md-3">
						<button type="button" class="btn btn-primary btn-sm ml-5 monthly-working-sheet-download float-right">Download Statement</button>
					</div>
				</div>
            </div>
            <hr />
			<input type="hidden" class="hidden_tbl_id" value="monthlyStatementTbl">
            <table class="table table-bordered" id="monthlyStatementTbl">
                <thead class="thead-dark ">
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Work</th>
                        <th scope="col">Due</th>
                        <th scope="col">Discount</th>
                        <th scope="col">Paid</th>
                        <th scope="col">Expenenses Details</th>
                        <th scope="col">Expenenses</th>
                        <th scope="col">Remaining</th>
                        <th scope="col">Balance</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

@endsection
