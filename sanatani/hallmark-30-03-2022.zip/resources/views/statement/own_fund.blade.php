@extends('common.layout')
@section('title', 'Statement')
@section('style')
    {!! Html::style('public/assets/plugins/select2/css/select2.min.css') !!}
    {!! Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css') !!}
    {!! Html::style('public/assets/plugins/notifications/css/lobibox.min.css') !!}
    {!! Html::style('public/assets/npm/daterangepicker/daterangepicker.css') !!}
	{!! Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css') !!}
@endsection

@section('script')
    {!! Html::script('public/assets/plugins/select2/js/select2.min.js') !!}
    {!! Html::script('public/assets/plugins/notifications/js/notifications.min.js') !!}
    {!! Html::script('public/assets/momentjs/latest/moment.min.js') !!}
    {!! Html::script('public/assets/npm/daterangepicker/daterangepicker.min.js') !!}
    {!! Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js') !!}
    {!! Html::script('public/assets/pages-js/Statement.js') !!}
    <script>
        $(function() {
            var start = moment().subtract(29, 'days');
            var end = moment();

            function cb(start, end) {
                $('#reportrange span').html(start.format('D/MM/YYYY') + ' - ' + end.format('D/MM/YYYY'));
                $(".daterange").val(start.format('D/MM/YYYY') + ' - ' + end.format('D/MM/YYYY'));
            }

            $('#reportrange').daterangepicker({
                "autoApply": true,
                startDate: start,
                endDate: end,
                ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            }, cb);

            cb(start, end);
            //$(".sarchtable").trigger("click");
        });
        CommonJS.SingleDropdown();
		StatementJs.OwnFund();
    </script>
   
@endsection
@section('content')
    <div class="card">
        <div class="card-body">
            <div class="card-title">
                <h5 class="mb-0">Search Own Fund Statement</h5>
            </div>
			<hr />
			<div class="form-row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Date Range</label>
                        <input type="hidden" name="daterange" class="form-control daterange">
                        <div id="reportrange" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
                            <i class="fa fa-calendar"></i>&nbsp;
                            <span></span> <i class="fa fa-caret-down"></i>
                        </div>
                    </div>
                </div>   
                <div class="col-md-3">
                    <br><br>
                    <label class="fs-18">Paid Amount</label>
                    <input type="checkbox" class="w-28 h-18 paid_amount" name="paid_amount" checked>&nbsp;&nbsp;&nbsp;
                    <label class="fs-18"> Due Collection</label>
                    <input type="checkbox" class="w-28 h-18 customer_fund" name="customer_fund" checked>
                </div>    
                <div class="col-md-1">
                    <label for="validationCustom02">&nbsp;</label>
                    <div class="form-group">
                        <button class="btn btn-primary statement-search" type="button">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="card-title">
				<div class="row">
					<div class="col-md-9">
						<h5 class="mb-0">Own Fund Statement List</h5>
					</div>
					<div class="col-md-3">
						<button type="button" class="btn btn-primary btn-sm ml-5 own-fund-download float-right">Download Statement</button>
					</div>
				</div>
            </div>
            <hr />
			<input type="hidden" class="hidden_tbl_id" value="ownFundStatementTbl">
            <table class="table table-bordered" id="ownFundStatementTbl">
                <thead class="thead-dark ">
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Remarks</th>
                        <th scope="col">Debit(Paid Amount)</th>
                        <th scope="col">Debit(Due Collection)</th>
                        <th scope="col">Balance</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

@endsection
