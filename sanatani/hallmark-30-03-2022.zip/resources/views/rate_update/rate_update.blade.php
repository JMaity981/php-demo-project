@extends('common.layout')
@section('title', 'Rate Update')
@section('style')
	{!! Html::style('public/assets/plugins/select2/css/select2.min.css')!!}
	{!! Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css')!!}
	{!! Html::style('public/assets/plugins/notifications/css/lobibox.min.css') !!}
	{!! Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css') !!}
@endsection
@section('script')
	
	{!! Html::script('public/assets/pages-js/RateUpdate.js') !!}
	{!! Html::script('public/assets/plugins/select2/js/select2.min.js') !!}
	{!! Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js') !!}
	{!! Html::script('public/assets/js/sweetalert.js') !!}
	{!! Html::script('public/assets/plugins/notifications/js/lobibox.min.js') !!}
	{!! Html::script('public/assets/plugins/notifications/js/notifications.min.js') !!}
	
	<script>
		CommonJS.NumberValidation();
		CommonJS.NumberValidationIntger();
		RateUpdateJs.RateUpdate();
	</script>

@endsection
@section('content')
    <div class="card reg-frm-loder">
        <div class="card-header">
            <h4>Rate Update</h4>
        </div>
        <div class="card-body">
            <div class="card">
				{{ Form::open(['id' => 'rateUpdateForm']) }}
                    <div class="card-body row">
                        <div class="col-md-2 col-sm-2 col-lg-2">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">H Rate</span>
                                </div>
                                <input class="form-control number-validate hallmarking-rate-h" name="hallmarking_rate_h" type="text" value="{{$data['hallmarking_h_rate']}}">
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-lg-4">
                            <div class="input-group">
                                 <div class="input-group-prepend">
                                    <span class="input-group-text">More then</span>
                                </div>
                                <input class="form-control number-validate-int more-then" name="more_then" type="text" value="{{$data['more_then']}}">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">H Rate</span>
                                </div>
                                <input class="form-control number-validate hallmarking-rate-h-more" name="hallmarking_rate_h_more" type="text" value="{{$data['hallmarking_h_rate_more']}}">
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-lg-2">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">O Rate</span>
                                </div>
                                <input class="form-control number-validate hallmarking-rate-o" name="hallmarking_rate_o" type="text" value="{{$data['hallmarking_o_rate']}}">
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-lg-2">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Card Rate</span>
                                </div>
                                <input class="form-control number-validate card-rate" name="card_rate" type="text" value="{{$data['card_rate']}}">
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-2 col-lg-2">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Photo Rate</span>
                                </div>
                                <input class="form-control number-validate photo-rate" name="photo_rate" type="text" value="{{$data['photo_rate']}}">
                            </div>
                        </div>
                    </div>	
                    <button type="button" id="allUpdateBtn" class="btn btn-info float-right all-update-btn">Update</button>
                    <button type="submit" id="allSubmitBtn" class="btn btn-primary float-right finish-btn all-submit-btn d-none">Save</button>
				{{ Form::close() }}

            </div>
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered" id="rateTbl">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">Jewellers Name</th>
                                <th scope="col">Propriter Name</th>
                                <th scope="col" class="h-rate-th">H Rate({{$data['more_then']}}pcs.)</th>
                                <th scope="col" class="h-rate-more-th">H Rate(more than {{$data['more_then']}})</th>
                                <th scope="col">O Rate</th>
                                <th scope="col">Card Rate</th>
                                <th scope="col">Photo Rate</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>          
		</div>
	</div>
@endsection