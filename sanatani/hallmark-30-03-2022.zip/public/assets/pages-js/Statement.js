var StatementJs = {
	init: function (){
		StatementJs.PartyDueDeposit();
		StatementJs.DailySeet();
		StatementJs.CardInOut();
		StatementJs.RebonsInOut();
		StatementJs.PhotoInOut();
		StatementJs.AbsentParty();
		StatementJs.AllPartyDue();
		StatementJs.MonthlyWorkingSheet();
		StatementJs.OwnFund();
	},
	//=======Party Deu Deposit Statemet==========//
    PartyDueDeposit: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var partyDueDepopsitTbl = $('#partyStatementTbl').DataTable({
				"lengthMenu": [
				  [100, 500, 1000],
				  [100, 500, 1000]
				],
				"processing": false,
				"serverSide": true,
				"ajax": {
				  "url": base_url + "/party-due-deposite-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					  data.daterange = $('.daterange').val();
					  data.ledger_id = $('.ledger-id').val();
				  },
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
        /*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
        /*------------ Download ---------*/
		$('.party-due-deposite-download').on('click',function(){
			var dateRange = $('.daterange').val();
			var ledger_id = $('.ledger-id').val();
			$.ajax({
				url: base_url + '/party-due-deposite-statement-pdf',
				type: "GET",
				data: {dateRange:dateRange , ledger_id:ledger_id},
				beforeSend: function() {
					CommonJS.showLoader('page-wrapper');
					$( ".wrapper" ).addClass( "loader" );
				},
				complete: function() {
					CommonJS.hideLoader('page-wrapper');
					$( ".wrapper" ).removeClass( "loader" );
				},
				success: function(res) {
					if(res.key == 'S'){
						window.location.href = 'download-any-file?filename='+res.filepath;
						CommonJS.Toaster({
							'type': 'success',
							'msg': res.msg,
						});
					}
				},
				error: function(error) {
					console.log(error.responseText);
				}
			});
		});
    },
	//=======Daily Seet Statemet==========//
    DailySeet: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var dailySeetTbl = $('#dailySeetStatementTbl').DataTable({
				// "lengthMenu": [
				//   [100, 500, 1000],
				//   [100, 500, 1000]
				// ],
				"processing": false,
				"serverSide": true,
				"ordering": false,
				"lengthChange": false,
				"bPaginate":false,
				"fnRowCallback": function( nRow, aData ) {
					// console.log(aData[13])
					if ( aData[13] == "Deleted" ){
						$('td', nRow).css('background-color', '#d9d9d9');
					}
					
				},
				"ajax": {
				  "url": base_url + "/daily-seet-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					  data.datepicker = $('.datepicker').val();
				  },
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
        /*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
        /*------------ Download ---------*/
		$('.daily-seet-download').on('click',function(){
			var datepicker = $('.datepicker').val();
			$.ajax({
				url: base_url + '/daily-seet-statement-pdf',
				type: "GET",
				data: {datepicker:datepicker},
				beforeSend: function() {
					CommonJS.showLoader('page-wrapper');
					$( ".wrapper" ).addClass( "loader" );
				},
				complete: function() {
					CommonJS.hideLoader('page-wrapper');
					$( ".wrapper" ).removeClass( "loader" );
				},
				success: function(res) {
					console.log(res);
					if(res.key == 'S'){
						window.location.href = 'download-any-file?filename='+res.filepath;
						CommonJS.Toaster({
							'type': 'success',
							'msg': res.msg,
						});
					}
				},
				error: function(error) {
					console.log(error.responseText);
				}
			});
		});
    },
	//=======Card In Out Statemet==========//
    CardInOut: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var cardInOutTbl = $('#cardStatementTbl').DataTable({
				"lengthMenu": [
				  [100, 500, 1000],
				  [100, 500, 1000]
				],
				"processing": false,
				"serverSide": true,
				"ordering": false,
				"ajax": {
				  "url": base_url + "/card-in-out-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					  data.daterange = $('.daterange').val();
					  data.ledger_id = $('.ledger-id').val();
				  },
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
        /*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
    },
	//=======Rebons In Out Statemet==========//
    RebonsInOut: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var rebonsInOutTbl = $('#rebonsStatementTbl').DataTable({
				"lengthMenu": [
				  [100, 500, 1000],
				  [100, 500, 1000]
				],
				"processing": false,
				"serverSide": true,
				"ordering": false,
				"ajax": {
				  "url": base_url + "/rebons-in-out-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					  data.daterange = $('.daterange').val();
					  data.ledger_id = $('.ledger-id').val();
				  },
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
        /*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
    },
	//=======Photo In Out Statemet==========//
    PhotoInOut: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var photoInOutTbl = $('#photoStatementTbl').DataTable({
				"lengthMenu": [
				  [100, 500, 1000],
				  [100, 500, 1000]
				],
				"processing": false,
				"serverSide": true,
				"ordering": false,
				"ajax": {
				  "url": base_url + "/photo-in-out-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					  data.daterange = $('.daterange').val();
					  data.ledger_id = $('.ledger-id').val();
				  },
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
        /*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
    },
	//=======Absent Party Statemet==========//
    AbsentParty: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var absentPartyTbl = $('#absentPartyStatementTbl').DataTable({
				"lengthMenu": [
				  [100, 500, 1000],
				  [100, 500, 1000]
				],
				"processing": false,
				"serverSide": true,
				"ordering": false,
				"ajax": {
				  "url": base_url + "/absent-party-statement-data",
				  "type": "get",
				  "dataType": "json",
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
    },
	//=======All Party Due Statemet==========//
	AllPartyDue: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var allPartyDueTbl = $('#allPartyDueStatementTbl').DataTable({
				// "lengthMenu": [
				//   [100, 500, 1000],
				//   [100, 500, 1000]
				// ],
				"processing": false,
				"serverSide": true,
				"lengthChange": false,
				"bPaginate":false,
				"ajax": {
				  "url": base_url + "/all-party-due-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					data.daterange = $('.daterange').val();
					data.ledger_id = $('.ledger-id').val();
				  },
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
		/*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
		 /*------------ Download ---------*/
		 $('.all-party-due-download').on('click',function(){
			var dateRange = $('.daterange').val();
			var ledger_id = $('.ledger-id').val();
			$.ajax({
				url: base_url + '/all-party-due-statement-pdf',
				type: "GET",
				data: {dateRange:dateRange , ledger_id:ledger_id},
				beforeSend: function() {
					CommonJS.showLoader('page-wrapper');
					$( ".wrapper" ).addClass( "loader" );
				},
				complete: function() {
					CommonJS.hideLoader('page-wrapper');
					$( ".wrapper" ).removeClass( "loader" );
				},
				success: function(res) {
					if(res.key == 'S'){
						window.location.href = 'download-any-file?filename='+res.filepath;
						CommonJS.Toaster({
							'type': 'success',
							'msg': res.msg,
						});
					}
				},
				error: function(error) {
					console.log(error.responseText);
				}
			});
		});
    },
	//=======Monthly Working Sheet Statemet==========//
    MonthlyWorkingSheet: function(){
        /*------------ Table ---------*/
        $(document).ready(function (){
			var monthlyWorkingSheetTbl = $('#monthlyStatementTbl').DataTable({
				// "lengthMenu": [
				//   [100, 500, 1000],
				//   [100, 500, 1000]
				// ],
				"processing": false,
				"serverSide": true,
				"ordering": false,
				"searching": false,
				"lengthChange": false,
				"bInfo" : false,
				"bPaginate":false,
				"ajax": {
				  "url": base_url + "/monthly-working-sheet-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					data.month_year = $('.month-year').val();
				},
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
		/*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
		 /*------------ Download ---------*/
		 $('.monthly-working-sheet-download').on('click',function(){
			var month_year = $('.month-year').val();
			$.ajax({
				url: base_url + '/monthly-working-sheet-statement-pdf',
				type: "GET",
				data: {month_year:month_year},
				beforeSend: function() {
					CommonJS.showLoader('page-wrapper');
					$( ".wrapper" ).addClass( "loader" );
				},
				complete: function() {
					CommonJS.hideLoader('page-wrapper');
					$( ".wrapper" ).removeClass( "loader" );
				},
				success: function(res) {
					if(res.key == 'S'){
						window.location.href = 'download-any-file?filename='+res.filepath;
						CommonJS.Toaster({
							'type': 'success',
							'msg': res.msg,
						});
					}
				},
				error: function(error) {
					console.log(error.responseText);
				}
			});
		});
		/*------------ Clear All Data ---------*/
		$('.clear-all-data').on('click',function(){
			const swalWithBootstrapButtons = swal.mixin({
				confirmButtonClass: 'btn btn-success btn-rounded',
				cancelButtonClass: 'btn btn-danger btn-rounded mr-3',
				buttonsStyling: false,
			})
			swalWithBootstrapButtons({
				title: 'Are you sure to Clear all Data ?',
				text: "You won't be able to revert this!",
				type: 'warning',
				showCancelButton: true,
				confirmButtonText: 'Yes, clear all data!',
				cancelButtonText: 'No, cancel!',
				reverseButtons: true,
				padding: '2em'
			}).then(function(result) {
				if (result.value == true) {
					$.ajax({
						url: base_url + '/clear-all-data',
						type: "GET",
						beforeSend: function() {
							CommonJS.showLoader('page-wrapper');
							$( ".wrapper" ).addClass( "loader" );
						},
						complete: function() {
							CommonJS.hideLoader('page-wrapper');
							$( ".wrapper" ).removeClass( "loader" );
						},
						success: function(res) {
							var tbl_id = $('.hidden_tbl_id').val();
							$('#'+tbl_id).DataTable().ajax.reload();
							if(res.key == 'S'){
								CommonJS.Toaster({
									'type': 'success',
									'msg': res.msg,
								});
							}
						},
						error: function(error) {
							console.log(error.responseText);
						}
					});

				}
			})
		});
		/*------------ Clear Data ---------*/
		$('.clear-data').on('click',function(){
			const swalWithBootstrapButtons = swal.mixin({
				confirmButtonClass: 'btn btn-success btn-rounded',
				cancelButtonClass: 'btn btn-danger btn-rounded mr-3',
				buttonsStyling: false,
			})
			swalWithBootstrapButtons({
				title: 'Are you sure to Clear Data ?',
				text: "You won't be able to revert this!",
				type: 'warning',
				showCancelButton: true,
				confirmButtonText: 'Yes, clear data!',
				cancelButtonText: 'No, cancel!',
				reverseButtons: true,
				padding: '2em'
			}).then(function(result) {
				if (result.value == true) {
					$.ajax({
						url: base_url + '/clear-data',
						type: "GET",
						beforeSend: function() {
							CommonJS.showLoader('page-wrapper');
							$( ".wrapper" ).addClass( "loader" );
						},
						complete: function() {
							CommonJS.hideLoader('page-wrapper');
							$( ".wrapper" ).removeClass( "loader" );
						},
						success: function(res) {
							var tbl_id = $('.hidden_tbl_id').val();
							$('#'+tbl_id).DataTable().ajax.reload();
							if(res.key == 'S'){
								CommonJS.Toaster({
									'type': 'success',
									'msg': res.msg,
								});
							}
						},
						error: function(error) {
							console.log(error.responseText);
						}
					});

				}
			})
		});
    },
	//=======Own Fund Statemet==========//
    OwnFund: function(){
        $(document).ready(function (){
        	/*------------ Paid Amount/Customer Fund On ch ---------*/
			var paid_amount = 'Y';
			var customer_fund = 'Y';
			$(".paid_amount").on('change', function(){
				paid_amount = ($(this).prop('checked')) ? 'Y' : 'N';
			});
			$(".customer_fund").on('change', function(){
				customer_fund = ($(this).prop('checked')) ? 'Y' : 'N';
			});
        	/*------------ Table ---------*/
			var ownFundTbl = $('#ownFundStatementTbl').DataTable({
				"lengthMenu": [
				  [100, 500, 1000],
				  [100, 500, 1000]
				],
				"processing": false,
				"serverSide": true,
				"searching": false,
				"ordering": false,
				"ajax": {
				  "url": base_url + "/own-fund-statement-data",
				  "type": "get",
				  "dataType": "json",
				  "data": function(data){
					  data.daterange = $('.daterange').val();
					  data.paid_amount = paid_amount;
					  data.customer_fund = customer_fund;
				  },
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});
        /*------------ Search ---------*/
		$(".statement-search").click(function(){
			var tbl_id = $('.hidden_tbl_id').val();
			$('#'+tbl_id).DataTable().ajax.reload();
		});
		 /*------------ Download ---------*/
		 $('.own-fund-download').on('click',function(){
			var daterange = $('.daterange').val();
			var paid_amount = ($(".paid_amount").prop('checked')) ? 'Y' : 'N';
			var customer_fund = ($(".customer_fund").prop('checked')) ? 'Y' : 'N';
			$.ajax({
				url: base_url + '/own-fund-statement-pdf',
				type: "GET",
				"data":{daterange: daterange, paid_amount: paid_amount, customer_fund: customer_fund},
				beforeSend: function() {
					CommonJS.showLoader('page-wrapper');
					$( ".wrapper" ).addClass( "loader" );
				},
				complete: function() {
					CommonJS.hideLoader('page-wrapper');
					$( ".wrapper" ).removeClass( "loader" );
				},
				success: function(res) {
					if(res.key == 'S'){
						window.location.href = 'download-any-file?filename='+res.filepath;
						CommonJS.Toaster({
							'type': 'success',
							'msg': res.msg,
						});
					}
				},
				error: function(error) {
					console.log(error.responseText);
				}
			});
		});
    }
}