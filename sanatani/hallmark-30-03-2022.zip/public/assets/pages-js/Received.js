var ReceivedJs = {
	init: function (){
		ReceivedJs.Received();
	},
	Received: function (){
        $( 'input[name="type"]:radio:first' ).click();
        $( ".old_due" ).prop( "disabled", true );
        document.addEventListener("keypress", function(event) {
            if (event.keyCode == 96) {
                $('#jn').select2('open');
            }
        });
        /*===========  Manual Type Show on Customer Name ============*/
        $(document).on('click','.manual-type-btn',function(){
            $(".ledger_id").val(0);
            $(".div-ledger").addClass("d-none");
            $("#customerName").removeClass("d-none");
            $("#manualTypeBtn").addClass("d-none");
            $("#selectLedgerBtn").removeClass("d-none");
            $(".ledger_name").val('');
            $('.ledger_name').trigger('change');
            $(".address").val('');
            $(".ph_no").val('');
            $(".old_due").val('');
            $(".logo").val('');
            $("#old_due").removeClass("input-field-red");
            $("#old_due").removeClass("input-field-green");
            /*$.ajax({
				url: base_url+"/get-rate-data",
				type: "POST",
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				dataType: 'json',
				success: function(res){
					$('.h_rate').val(res[0].hallmarking_h);
					$('.h_rate_4').val(res[0].hallmarking_h_4);
					$('.o_rate').val(res[0].hallmarking_o);
					$('.card_rate').val(res[0].card);
					$('.photo_rate').val(res[0].photo);
				},
				error:function(error){
					console.log(error.responseText);
				}
			});*/
        });
        /*===================  Select Ledger Show ====================*/
        $(document).on('click','.select-ledger-btn',function(){
            $(".ledger_id").val("");
            $("#customerName").addClass("d-none");
            $(".div-ledger").removeClass("d-none");
            $("#selectLedgerBtn").addClass("d-none");
            $("#manualTypeBtn").removeClass("d-none");
        });
        /*---------------- get Ledger details ------------------*/	
		$('.ledger_name').on('change',function(){
			var ledgerId = $(".ledger_name :selected").val();
			$.ajax({
				url: base_url+"/get-ledger-data",
				type: "POST",
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				data:{ledgerId:ledgerId},
				dataType: 'json',
				success: function(res){
					$('.ledger_id').val(res.ledger_details[0].id);
					// $('.h_rate').val(res.ledger_details[0].hallmarking_rate_h);
					// $('.h_rate_4').val(res.ledger_details[0].hallmarking_rate_h_4);
					// $('.o_rate').val(res.ledger_details[0].hallmarking_rate_o);
					// $('.card_rate').val(res.ledger_details[0].card_rate);
					// $('.photo_rate').val(res.ledger_details[0].photo_rate);
					$('.address').val(res.ledger_details[0].address);
					$('.ph_no').val(res.ledger_details[0].ph_no);
					$('.old_due').val(Math.abs(res.ledger_details[0].balance));
                    if(res.ledger_details[0].balance > 0){
						$("#old_due").addClass("input-field-green");
						$("#old_due").removeClass("input-field-red");
                    }else if(res.ledger_details[0].balance < 0){
						$("#old_due").addClass("input-field-red");
						$("#old_due").removeClass("input-field-green");
                    }else{
						$("#old_due").removeClass("input-field-red");
						$("#old_due").removeClass("input-field-green");
                    }
					$('.logo').val(res.ledger_details[0].logo);
				},
				error:function(error){
					console.log(error.responseText);
				}
			});
		});
        /*=================== Card Append Form ====================*/
        $(document).on('click','.card-append-btn',function(){
            var card_weight = $('.add-sample-row-card:last-child').find('.card_weight').val();
            var card_piece = $('.add-sample-row-card:last-child').find('.card_piece').val();
			if(card_weight != '' && card_piece != ''){
				var frmhtml = 
                `<div class="row add-sample-row-card remove-append-row">
                    <div class="col-md-3 col-sm-3 col-lg-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Card Weight</span>
                            </div>
                            <input class="form-control number-validate card_weight" type="text" name="card_weight[]">
                            <div class="input-group-prepend">
                                <span class="input-group-text">gm.</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-2 col-lg-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Card Piece</span>
                            </div>
                            <input class="form-control number-validate-int card_piece" type="text" name="card_piece[]">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Card Remarks</span>
                            </div>
                            <input class="form-control card_remarks" type="text" name="card_remarks[]">
                        </div>
                    </div>
                    <div class="col-md-1 col-sm-1 col-lg-1">
                        <button type="button" class="btn btn-danger btn-sm remove-one-card">
                            <i class="fadeIn animated bx bx-minus"></i>
                        </button>
                    </div>
                </div>`;
				$('.add-sample-row-card:last-child').after(frmhtml);
				
				CommonJS.NumberValidation();
		        CommonJS.NumberValidationIntger();
			}
			$(document).on("click",".remove-one-card",function() {
                $(this).closest(".add-sample-row-card").remove();
            });
		});        
        /*===================  Card Show Btn ====================*/
        $(document).on('click','.card-show-btn',function(){
            $(".card_view").val("S");
            $("#cardShowHide").removeClass("d-none");
            $("#cardShowBtn").addClass("d-none");
            $("#cardHideBtn").removeClass("d-none");
        });
        /*===================  Card Hide Btn ====================*/
        $(document).on('click','.card-hide-btn',function(){
            $(".card_view").val("H");
            $("#cardShowHide").addClass("d-none");
            $("#cardHideBtn").addClass("d-none");
            $("#cardShowBtn").removeClass("d-none");
        });
        /*=================== Photo Append Form ====================*/
        $(document).on('click','.photo-append-btn',function(){
            
            var photo_weight = $('.add-sample-row-photo:last-child').find('.photo_weight').val();
            var photo_piece = $('.add-sample-row-photo:last-child').find('.photo_piece').val();

            if(photo_weight != '' && photo_piece != ''){
                var frmhtml = 
                `<div class="row add-sample-row-photo remove-append-row">
                    <div class="col-md-3 col-sm-3 col-lg-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Photo Weight</span>
                            </div>
                            <input class="form-control number-validate photo_weight" type="text" name="photo_weight[]">
                            <div class="input-group-prepend">
                                <span class="input-group-text">gm.</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-2 col-lg-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Photo Piece</span>
                            </div>
                            <input class="form-control number-validate-int photo_piece" type="text" name="photo_piece[]">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Photo Remarks</span>
                            </div>
                            <input class="form-control photo_remarks" type="text" name="photo_remarks[]">
                        </div>
                    </div>
                    <div class="col-md-1 col-sm-1 col-lg-1">
                        <button type="button" class="btn btn-danger btn-sm remove-one-photo">
                            <i class="fadeIn animated bx bx-minus"></i>
                        </button>
                    </div>
                </div>`;
                $('.add-sample-row-photo:last-child').after(frmhtml);
                
                CommonJS.NumberValidation();
                CommonJS.NumberValidationIntger();
            }
            
			
			$(document).on("click",".remove-one-photo",function() {
                $(this).closest(".add-sample-row-photo").remove();
            });
		}); 
        /*===================  Photo Show Btn ====================*/
        $(document).on('click','.photo-show-btn',function(){
            $(".photo_view").val("S");
            $("#photoShowHide").removeClass("d-none");
            $("#photoShowBtn").addClass("d-none");
            $("#photoHideBtn").removeClass("d-none");
        });
        /*===================  Photo Hide Btn ====================*/
        $(document).on('click','.photo-hide-btn',function(){
            $(".photo_view").val("H");
            $("#photoShowHide").addClass("d-none");
            $("#photoHideBtn").addClass("d-none");
            $("#photoShowBtn").removeClass("d-none");
        });
        /*===================  Received Form Submit ====================*/
        $('#receivedForm').validate({
            submitHandler: function(form) {
                var isTrue = true;
                var rowChecked = false;
                var hallmark_weight = $("input[name=weight]").val();
                var hallmark_piece = $("input[name=piece]").val();
                var hallmark_purity = $("input[name=purity]").val();
                var card_view = $("input[name=card_view]").val();
                var photo_view = $("input[name=photo_view]").val();
                if(hallmark_weight != '' || hallmark_piece != '' || hallmark_purity != ''){
                    rowChecked = true;
                    if(hallmark_weight == ''){
                        $('.weight').addClass('border-danger');
                        isTrue = false;
                    }
                    if(hallmark_piece == ''){
                        $('.piece').addClass('border-danger');
                        isTrue = false;
                    }
                    if(hallmark_purity == ''){
                        $('.purity').addClass('border-danger');
                        isTrue = false;
                    }
                }
                if(card_view == 'S'){
                    rowChecked = true;
                    $('.add-sample-row-card').each(function(){
                        var card_weight = $(this).find('.card_weight').val();
                        var card_piece = $(this).find('.card_piece').val();
    
                        if(card_weight.trim() == ''){
                            isTrue = false;
                            $(this).find('.card_weight').addClass('border-danger');
                        }
                        if(card_piece.trim() == ''){
                            isTrue = false;
                            $(this).find('.card_piece').addClass('border-danger');
                        }
                    });
                }
                if(photo_view == 'S'){
                    rowChecked = true;
                    $('.add-sample-row-photo').each(function(){
                        var photo_weight = $(this).find('.photo_weight').val();
                        var photo_piece = $(this).find('.photo_piece').val();
    
                        if(photo_weight.trim() == ''){
                            isTrue = false;
                            $(this).find('.photo_weight').addClass('border-danger');
                        }
                        if(photo_piece.trim() == ''){
                            isTrue = false;
                            $(this).find('.photo_piece').addClass('border-danger');
                        }
                    });
                }
                if(isTrue && rowChecked){
                    var data = $('#receivedForm').serialize();
                    var ledgerId = $("input[name=ledger_id]").val();
                    var print_check = ($('.print-enable').is(":checked"));
                    // console.log(print_check)
                    if(ledgerId != ''){
                        $.ajax({
                            url: 'insert-received-data',
                            type: "POST",
                            data: data,
                            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                            beforeSend: function() {
                                $(".finish-btn").prop("disabled", true);
                                CommonJS.showLoader('reg-frm-loder');
                            },
                            complete: function() {
                                $(".finish-btn").prop("disabled", false);
                                CommonJS.hideLoader('reg-frm-loder');
                            },
                            success: function(res) {
                                if(res.key == 'S'){
                                    $('#receivedForm')[0].reset();
                                    $('.sl_no').val(res.sl_no + 1);
                                    $('.ledger_id').val('');
                                    // $('.h_rate').val('');
                                    // $('.h_rate_4').val('');
                                    // $('.o_rate').val('');
                                    // $('.card_rate').val('');
                                    // $('.photo_rate').val('');
                                    $(".card_view").val('H');
                                    $(".photo_view").val('H');
                                    $(".ledger_name").val('');
                                    $('.ledger_name').trigger('change');
                                    $("#customerName").addClass("d-none");
                                    $(".div-ledger").removeClass("d-none");
                                    $("#selectLedgerBtn").addClass("d-none");
                                    $("#manualTypeBtn").removeClass("d-none");
                                    $('.remove-append-row').remove();
                                    $("#cardShowHide").addClass("d-none");
                                    $("#cardHideBtn").addClass("d-none");
                                    $("#cardShowBtn").removeClass("d-none")
                                    $("#photoShowHide").addClass("d-none");
                                    $("#photoHideBtn").addClass("d-none");
                                    $("#photoShowBtn").removeClass("d-none");
                                    $("#old_due").removeClass("input-field-red");
                                    $("#old_due").removeClass("input-field-green");
                                    $( 'input[name="type"]:radio:first' ).click();
                                    CommonJS.Toaster({
                                        'type': 'success',
                                        'msg': res.msg
                                    });
                                    CommonJS.getStockDetails();
                                    $("input[type='checkbox']").val();
                                    if(print_check == true){
                                        // console.log('ok')
                                        url = base_url+'/generate-bill-pdf?slno='+res.sl_no;
                                        window.open(url,'_blank');
                                    }
                                }else if(res.key == 'E'){
                                    CommonJS.Toaster({
                                        'type': 'error',
                                        'msg': res.msg,
                                    });
                                }
                            },
                            error: function(error) {
                                CommonJS.Toaster({
                                    'type': 'error',
                                    'msg': error.responseText,
                                });
                            }
                        });
                    }else{
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': 'Please select a Ledger.',
                        });
                    }
                }
                
            }
        });
    }
}