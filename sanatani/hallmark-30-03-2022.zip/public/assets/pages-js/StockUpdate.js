var StockUpdateJs = {
	init: function (){
		StockUpdateJs.StockUpdate();
	},
	StockUpdate: function (){
        /*---------------- Card In ------------------*/	
        $(document).on('click','.card-in-btn',function(){
            var pcs = $('.card-in').val();
            if(pcs != ''){
                $.ajax({
                    url: 'card-in',
                    type: "POST",
                    data: {pcs: pcs},
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend: function() {
                        $(".finish-btn").prop("disabled", true);
                        CommonJS.showLoader('reg-frm-loder');
                    },
                    complete: function() {
                        $(".finish-btn").prop("disabled", false);
                        CommonJS.hideLoader('reg-frm-loder');
                    },
                    success: function(res) {
                        if(res.key == 'S'){
                            $('.card-in').val('');                            
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg
                            });
                            CommonJS.getStockDetails();
                        }else if(res.key == 'E'){
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                    },
                    error: function(error) {
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': error.responseText,
                        });
                    }
                });
            }else{
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'Car field is required.',
                });
            }
        });
        /*---------------- Photo In ------------------*/	
        $(document).on('click','.photo-in-btn',function(){
            var pcs = $('.photo-in').val();
            if(pcs != ''){
                $.ajax({
                    url: 'photo-in',
                    type: "POST",
                    data: {pcs: pcs},
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend: function() {
                        $(".finish-btn").prop("disabled", true);
                        CommonJS.showLoader('reg-frm-loder');
                    },
                    complete: function() {
                        $(".finish-btn").prop("disabled", false);
                        CommonJS.hideLoader('reg-frm-loder');
                    },
                    success: function(res) {
                        console.log(res);
                        if(res.key == 'S'){
                            $('.photo-in').val('');                            
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg
                            });
                            CommonJS.getStockDetails();
                        }else if(res.key == 'E'){
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                    },
                    error: function(error) {
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': error.responseText,
                        });
                    }
                });
            }else{
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'Photo field is required.',
                });
            }
        });
         /*---------------- Rebons In ------------------*/	
         $(document).on('click','.rebons-in-btn',function(){
            var pcs = $('.rebons-in').val();
            if(pcs != ''){
                $.ajax({
                    url: 'rebons-in',
                    type: "POST",
                    data: {pcs: pcs},
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend: function() {
                        $(".finish-btn").prop("disabled", true);
                        CommonJS.showLoader('reg-frm-loder');
                    },
                    complete: function() {
                        $(".finish-btn").prop("disabled", false);
                        CommonJS.hideLoader('reg-frm-loder');
                    },
                    success: function(res) {
                        console.log(res);
                        if(res.key == 'S'){
                            $('.rebons-in').val('');                            
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg
                            });
                            CommonJS.getStockDetails();
                        }else if(res.key == 'E'){
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                    },
                    error: function(error) {
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': error.responseText,
                        });
                    }
                });
            }else{
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'Rebons field is required.',
                });
            }
        });
        /*---------------- Card Rebons Reject ------------------*/	
        $(document).on('click','.card-rebons-out-btn',function(){
            var pcs = $('.card-rebons-out').val();
            var ledger_id = $('.card-rebons-out-ledger').val();
            if(pcs != '' && ledger_id != null){
                $.ajax({
                    url: 'card-rebons-out',
                    type: "POST",
                    data: {pcs: pcs, ledger_id: ledger_id},
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend: function() {
                        $(".finish-btn").prop("disabled", true);
                        CommonJS.showLoader('reg-frm-loder');
                    },
                    complete: function() {
                        $(".finish-btn").prop("disabled", false);
                        CommonJS.hideLoader('reg-frm-loder');
                    },
                    success: function(res) {
                        if(res.key == 'S'){
                            $('.card-rebons-out').val('');
                            $(".card-rebons-out-ledger").val('');
                            $('.card-rebons-out-ledger').trigger('change');                            
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg
                            });
                            CommonJS.getStockDetails();
                        }else if(res.key == 'E'){
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                    },
                    error: function(error) {
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': error.responseText,
                        });
                    }
                });
            }else if(pcs == ''){
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'Car/Rebons field is required.',
                });
            }else{
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'Please Select a Ledger.',
                });
            }
        });
        /*---------------- Photo Reject ------------------*/	
        $(document).on('click','.photo-out-btn',function(){
            var pcs = $('.photo-out').val();
            var ledger_id = $('.photo-out-ledger').val();
            if(pcs != '' && ledger_id != null){
                $.ajax({
                    url: 'photo-out',
                    type: "POST",
                    data: {pcs: pcs, ledger_id: ledger_id},
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend: function() {
                        $(".finish-btn").prop("disabled", true);
                        CommonJS.showLoader('reg-frm-loder');
                    },
                    complete: function() {
                        $(".finish-btn").prop("disabled", false);
                        CommonJS.hideLoader('reg-frm-loder');
                    },
                    success: function(res) {
                        if(res.key == 'S'){
                            $('.photo-out').val('');
                            $(".photo-out-ledger").val('');
                            $('.photo-out-ledger').trigger('change');                            
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg
                            });
                            CommonJS.getStockDetails();
                        }else if(res.key == 'E'){
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                    },
                    error: function(error) {
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': error.responseText,
                        });
                    }
                });
            }else if(pcs == ''){
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'Photo field is required.',
                });
            }else{
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'Please Select a Ledger.',
                });
            }
        });
    }
}