var DeliveryJs = {
	init: function (){
		DeliveryJs.Delivery();
	},
	Delivery: function (){
		//----------- Delivery Data Table -----------//
		var DeliveryDataTbl = $('#deliveryTbl').DataTable({
			"lengthMenu": [
				[10, 50, 100, 500, 1000],
				[10, 50, 100, 500, 1000]
			],
			"processing": false,
			"serverSide": true,
			"ordering": false,
			"ajax": {
				"url": base_url + "/delivery-tbl-data",
				"type": "get",
				"dataType": "json",
				beforeSend: function() {
					CommonJS.showLoader('tbl-loader');
				},
				complete: function() {
					CommonJS.hideLoader('tbl-loader');
				},
				"dataSrc": function(result) {
					// console.log(result);
					return result.data;
				},
				"error": function(error) {
					console.log(error.responseText);
				},
			},
			"columnDefs": [
				{ visible: false, targets: 0 }
			]
		});
		//----------- Row on click and Set the value Old Due -----------//
		DeliveryDataTbl.on('click', 'tr', function () {
			var data = DeliveryDataTbl.row(this).data();
			var balance = data[0];
			$('.old_due').val(Math.abs(balance));
				if(balance > 0){
					$("#old_due").addClass("input-field-green");
					$("#old_due").removeClass("input-field-red");
				}else if(balance < 0){
					$("#old_due").addClass("input-field-red");
					$("#old_due").removeClass("input-field-green");
				}else{
					$("#old_due").removeClass("input-field-red");
					$("#old_due").removeClass("input-field-green");
				}
		});
		//----------- edit btn click on Data Table -----------//
		$(document).on('click','.open-tbl-frm',function(){
			var id = $(this).data('id');
			$('.delivery-weight-value'+id).addClass('d-none');
			$('.paid-value'+id).addClass('d-none');
			$('.delivery-weight'+id).removeClass('d-none');
			$('.paid'+id).removeClass('d-none');
			$('.edittable-add-data'+id).html('');
			$('.edittable-add-data'+id).html('<i class="fadeIn animated bx bx-save"></i>');
			$('.edittable-add-data'+id).addClass('save-tbl-frm');
			$('.edittable-add-data'+id).addClass('edittable-save-data'+id);
			$('.edittable-add-data'+id).removeClass('open-tbl-frm');
			$('.edittable-add-data'+id).removeClass('edittable-add-data'+id);
			CommonJS.NumberValidation();
		});
		//-------- save data btn click on Data Table ---------//
		$(document).on('click','.save-tbl-frm',function(){
			var id = $(this).data('id');
			var delivery_weight = $('.delivery-weight'+id).val();
			var paid = $('.paid'+id).val();	
			$.ajax({
				url: base_url+"/delivery-submit",
				type: "POST",
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				data:{id:id , delivery_weight:delivery_weight , paid:paid},
				dataType: 'json',
				success: function(res){
					if(res.key=='S'){
						$('.old_due').val('');
						$("#old_due").removeClass("input-field-red");
						$("#old_due").removeClass("input-field-green");
						CommonJS.Toaster({
							'type': 'success',
							'msg': res.msg,
						});
					}else{
						CommonJS.Toaster({
							'type': 'error',
							'msg': res.msg,
						});
					}
					$('#deliveryTbl').DataTable().ajax.reload();
					CommonJS.getStockDetails();
				},
				error:function(error){
					console.log(error.responseText);
				}
			});
		});
		/*----------------- Delete Btn on click ---------------*/
		$(document).on('click','.delivery-delete-btn',function(){
			var id = $(this).data('id');
			const swalWithBootstrapButtons = swal.mixin({
				confirmButtonClass: 'btn btn-success btn-rounded',
				cancelButtonClass: 'btn btn-danger btn-rounded mr-3',
				buttonsStyling: false,
			})
			swalWithBootstrapButtons({
				title: 'Are you sure to Delete ?',
				text: "You won't be able to revert this!",
				type: 'warning',
				showCancelButton: true,
				confirmButtonText: 'Yes, delete it!',
				cancelButtonText: 'No, cancel!',
				reverseButtons: true,
				padding: '2em'
			}).then(function(result) {
				if (result.value == true) {
					$.ajax({
						url: base_url + '/delete-delivery',
						data: { id: id},
						type: "POST",
						headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
						success: function(data) {
							// console.log(data);
							if (data.key == 'S') {
								$('#deliveryTbl').DataTable().ajax.reload();
								$('.old_due').val('');
								$("#old_due").removeClass("input-field-red");
								$("#old_due").removeClass("input-field-green");
								CommonJS.Toaster({
									'type': 'success',
									'msg': data.msg,
								});
							}else if(data.key == 'E'){
								CommonJS.Toaster({
									'type': 'error',
									'msg': data.msg,
								});
							}
						},
						error: function(error) {
							console.log(error.responseText);
						},
					});
				}
			})
		});
		/*----------------- XRF man modal show ---------------*/
		$(document).on('click','.xrf-man-btn',function(){
			$("#xrfManForm")[0].reset();
			$('#xrfManModal').modal('show');
		});
		/*----------------- Lager man modal show ---------------*/
		$(document).on('click','.lager-man-btn',function(){
			$("#lagerManForm")[0].reset();
			$('#lagerManModal').modal('show');
		});
		/*----------------- XRF man form Submit ---------------*/
		$("#xrfManForm").validate({
            rules: {
                xrf_sl_no: { 
                    required: true,
                    number: true
                }
            },
            errorPlacement: function(label, element) {

            },
            highlight: function(element, errorClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            submitHandler: function(form) {
				var sl_no = $("input[name=xrf_sl_no]").val();
				var xrf_result = $("input[name=xrf_result]:checked").val();			
				if(xrf_result !== undefined){
					$.ajax({
						type: 'POST',
						url: base_url + "/xrf-man-update",
						data: {sl_no: sl_no, xrf_result: xrf_result},
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						dataType: 'json',
						success: function(res) {
							if(res.key == 'S'){
								$("#xrfManForm")[0].reset();
								$('.total-pcs-xrf').val(res.total_pcs);
								CommonJS.Toaster({
									'type': 'success',
									'msg': res.msg,
								});
								$('#deliveryTbl').DataTable().ajax.reload();
							}else if(res.key == 'E'){
								$('.total-pcs-xrf').val('');
								CommonJS.Toaster({
									'type': 'error',
									'msg': res.msg,
								});
							}
						},
						error: function(error) {
							console.log(error.responseText);
						}
					});
				}else{
					CommonJS.Toaster({
						'type': 'error',
						'msg': 'Choose Pass or Fail',
					});
				}
			}
        });
		/*----------------- lager man form Submit ---------------*/
		$("#lagerManForm").validate({
            rules: {
                lager_sl_no: { 
                    required: true,
                    number: true
                }
            },
            errorPlacement: function(label, element) {

            },
            highlight: function(element, errorClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            submitHandler: function(form) {
				var sl_no = $("input[name=lager_sl_no]").val();
				var lager_result = $("input[name=lager_result]:checked").val();			
				if(lager_result !== undefined){
					$.ajax({
						type: 'POST',
						url: base_url + "/lager-man-update",
						data: {sl_no: sl_no, lager_result: lager_result},
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						dataType: 'json',
						success: function(res) {
							console.log(res);
							if(res.key == 'S'){
								$("#lagerManForm")[0].reset();
								$('.total-pcs-lager').val(res.total_pcs);
								CommonJS.Toaster({
									'type': 'success',
									'msg': res.msg,
								});
								$('#deliveryTbl').DataTable().ajax.reload();
							}else if(res.key == 'E'){
								$('.total-pcs-lager').val('');
								CommonJS.Toaster({
									'type': 'error',
									'msg': res.msg,
								});
							}
						},
						error: function(error) {
							console.log(error.responseText);
						}
					});
				}else{
					CommonJS.Toaster({
						'type': 'error',
						'msg': 'Choose Right or Cross',
					});
				}
			}
        });
		/*----------------- View Btn on click ---------------*/
		$(document).on('click','.view-btn',function(){
			var id = $(this).data('id');
			$.ajax({
				url: base_url + '/get-received-data',
				data: { id: id},
				type: "POST",
				headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
				success: function(data) {
					var sl_no = 'SL No:- '+id;
					$(".apend-slno").html(sl_no);
					var td='';
					if((data.hallmark).length != 0){
						var remarks = (data.hallmark[0]['remarks']==null)?'':data.hallmark[0]['remarks'];
						td +=`<tr>
								<td scope="col">${data.hallmark[0]['type']}</td>
								<td scope="col">${data.hallmark[0]['weight']}</td>
								<td scope="col">${data.hallmark[0]['piece']}</td>
								<td scope="col">${data.hallmark[0]['purity']}</td>
								<td scope="col">${remarks}</td>
							</tr>`;
					}
					if((data.card).length != 0){
						$.each(data.card, function (key, val) {
							var remarks = (val['remarks']==null)?'':val['remarks'];
							td +=`<tr>
									<td scope="col">Card</td>
									<td scope="col">${val['weight']}</td>
									<td scope="col">${val['piece']}</td>
									<td scope="col"></td>
									<td scope="col">${remarks}</td>
								</tr>`;
						});
					}
					if((data.photo).length != 0){
						$.each(data.photo, function (key, val) {
							var remarks = (val['remarks']==null)?'':val['remarks'];
							td +=`<tr>
									<td scope="col">photo</td>
									<td scope="col">${val['weight']}</td>
									<td scope="col">${val['piece']}</td>
									<td scope="col"></td>
									<td scope="col">${remarks}</td>
								</tr>`;
						});
					}
					$(".apend-tbody").html(td);
					$('#viewDetailsModal').modal('show');
				},
				error: function(error) {
					console.log(error.responseText);
				},
			});
		});
		/*----------------- Chacked XRF on change ---------------*/
		$(document).on('change','.checked-xrf',function(){
			var _this = $(this);
            if (_this.prop("checked") == true) {
                var status = 'A';
            } else {
                var status = 'I';
            }
            $.ajax({
                url: base_url + '/checked-xrf-change',
                data: {status: status },
                type: "POST",
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                success: function(data) {
                    // console.log(data);
                    if (data.key == 'S') {
						$('#deliveryTbl').DataTable().ajax.reload();
                        CommonJS.Toaster({
                            'type': 'success',
                            'msg': data.msg,
                        });
                    }
                },
                error: function(error) {
                    console.log(error.responseText);
                },
            });
        });
    }
}