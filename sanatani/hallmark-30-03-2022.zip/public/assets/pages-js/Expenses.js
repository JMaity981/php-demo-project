var ExpensesJs = {
	init: function (){
		ExpensesJs.Expenses();
	},
	Expenses: function (){
		/*=================== Form Submit ====================*/
		$('#expensesForm').validate({
			rules: {
				remarks: {
					required: true,
				},
				amount: {
					required: true,
				}
			},
			highlight: function(element, errorClass) {
				$(element).addClass('is-invalid');
			},
			unhighlight: function(element, errorClass, validClass) {
				$(element).removeClass('is-invalid');
			},
			submitHandler: function(form) {
				var data = $('#expensesForm').serialize();
				$.ajax({
					url: 'expenses-submit',
					type: "POST",
					data: data,
					headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
					beforeSend: function() {
						$(".finish-btn").prop("disabled", true);
						CommonJS.showLoader('reg-frm-loder');
					},
					complete: function() {
						$(".finish-btn").prop("disabled", false);
						CommonJS.hideLoader('reg-frm-loder');
					},
					success: function(res) {
						if(res.key == 'S'){
							$('#expensesForm')[0].reset();
                            $(".monthly-expenses").val(res.monthly_expenses);
							$('#expensesTbl').DataTable().ajax.reload();
							CommonJS.Toaster({
								'type': 'success',
								'msg': res.msg,
							});
							CommonJS.getStockDetails();
						}else if(res.key == 'E'){
							CommonJS.Toaster({
								'type': 'error',
								'msg': res.msg,
							});
						}
					},
					error: function(error) {
						CommonJS.Toaster({
							'type': 'error',
							'msg': error.responseText,
						});
					}
				});
			}
		});
		/*------------ Table ---------*/
        $(document).ready(function (){
			var expensesTbl = $('#expensesTbl').DataTable({
				"processing": false,
				"serverSide": true,
				"ordering": false,
				"searching": false,
				"lengthChange": false,
				"bInfo" : false,
				"bPaginate":false,
				"ajax": {
				  "url": base_url + "/expenses-tbl-data",
				  "type": "get",
				  "dataType": "json",
				  beforeSend: function() {
					   CommonJS.showLoader('page-wrapper');
					  $( ".wrapper" ).addClass( "loader" );
				  },
				  complete: function() {
					  CommonJS.hideLoader('page-wrapper');
					  $( ".wrapper" ).removeClass( "loader" );
				  },
				  "dataSrc": function(result) {
					// console.log(result);
					return result.data;
				  },
				  "error": function(error) {
					console.log(error.responseText);
				  },
				},
			});
		});       
    }
}