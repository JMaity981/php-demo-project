var CustomerFundJs = {
	init: function (){
		CustomerFundJs.CustomerFund();
	},
	CustomerFund: function (){
        $( 'input[name="transaction_type"]:radio:first' ).click();
        document.addEventListener("keypress", function(event) {
            if (event.keyCode == 96) {
                $('#jn').select2('open');
            }
        });
        /*---------------- get Ledger details ------------------*/	
		$('.ledger_name').on('change',function(){
			var ledgerId = $(".ledger_name :selected").val();
			$.ajax({
				url: base_url+"/get-ledger-data",
				type: "POST",
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				},
				data:{ledgerId:ledgerId},
				dataType: 'json',
				success: function(res){
					$('.address').val(res.ledger_details[0].address);
					$('.ph_no').val(res.ledger_details[0].ph_no);
					$('.old_due').val(Math.abs(res.ledger_details[0].balance));
                    if(res.ledger_details[0].balance > 0){
						$("#old_due").addClass("input-field-green");
						$("#old_due").removeClass("input-field-red");
                    }else if(res.ledger_details[0].balance < 0){
						$("#old_due").addClass("input-field-red");
						$("#old_due").removeClass("input-field-green");
                    }else{
						$("#old_due").removeClass("input-field-red");
						$("#old_due").removeClass("input-field-green");
                    }
					$('.logo').val(res.ledger_details[0].logo);
				},
				error:function(error){
					console.log(error.responseText);
				}
			});
		});
        /*=================== Form Submit ====================*/
        $('#customerFundForm').validate({
            rules: {
                ledger_name: {
                    required: true,
                },
                amount: {
                    required: true,
                }
            },
            highlight: function(element, errorClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            submitHandler: function(form) {
                var data = $('#customerFundForm').serialize();
                $.ajax({
                    url: 'customer-fund-submit',
                    type: "POST",
                    data: data,
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend: function() {
                        $(".finish-btn").prop("disabled", true);
                        CommonJS.showLoader('reg-frm-loder');
                    },
                    complete: function() {
                        $(".finish-btn").prop("disabled", false);
                        CommonJS.hideLoader('reg-frm-loder');
                    },
                    success: function(res) {
                        if(res.key == 'S'){
							$('#customerFundForm')[0].reset();
                            $( 'input[name="transaction_type"]:radio:first' ).click();
                            $(".ledger_name").val('');
                            $('.ledger_name').trigger('change');
                            $("#old_due").removeClass("input-field-red");
						    $("#old_due").removeClass("input-field-green");
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg,
                            });
                            CommonJS.getStockDetails();
                        }else if(res.key == 'E'){
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                    },
                    error: function(error) {
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': error.responseText,
                        });
                    }
                });
            }
        });
    }
}