var OwnFundJs = {
	init: function (){
		OwnFundJs.OwnFund();
	},
	OwnFund: function (){
        /*=================== Form Submit ====================*/
		$('#ownFundFrom').validate({
			rules: {
				amount_type: {
					required: true,
				},
				amount: {
					required: true,
				}
			},
			highlight: function(element, errorClass) {
				$(element).addClass('is-invalid');
			},
			unhighlight: function(element, errorClass, validClass) {
				$(element).removeClass('is-invalid');
			},
			submitHandler: function(form) {
				var data = $('#ownFundFrom').serialize();
				$.ajax({
					url: 'own-fund-submit',
					type: "POST",
					data: data,
					headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
					beforeSend: function() {
						$(".finish-btn").prop("disabled", true);
						CommonJS.showLoader('reg-frm-loder');
					},
					complete: function() {
						$(".finish-btn").prop("disabled", false);
						CommonJS.hideLoader('reg-frm-loder');
					},
					success: function(res) {
						if(res.key == 'S'){
							$('#ownFundFrom')[0].reset();
							CommonJS.Toaster({
								'type': 'success',
								'msg': res.msg,
							});
							CommonJS.getStockDetails();
						}else if(res.key == 'E'){
							CommonJS.Toaster({
								'type': 'error',
								'msg': res.msg,
							});
						}
					},
					error: function(error) {
						CommonJS.Toaster({
							'type': 'error',
							'msg': error.responseText,
						});
					}
				});
			}
		});
    }
}