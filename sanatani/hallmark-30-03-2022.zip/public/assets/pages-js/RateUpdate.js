var RateUpdateJs = {
	init: function (){
		RateUpdateJs.RateUpdate();
	},
	RateUpdate: function (){
        $( ".hallmarking-rate-h" ).prop( "disabled", true );
        $( ".hallmarking-rate-h-more" ).prop( "disabled", true );
        $( ".more-then" ).prop( "disabled", true );
        $( ".hallmarking-rate-o" ).prop( "disabled", true );
        $( ".card-rate" ).prop( "disabled", true );
        $( ".photo-rate" ).prop( "disabled", true );

        //----------- Update Btn On click -----------//
        $(document).on('click','#allUpdateBtn',function(){
            $("#allUpdateBtn").addClass("d-none");
            $("#allSubmitBtn").removeClass("d-none");
            $( ".hallmarking-rate-h" ).prop( "disabled", false );
            $( ".more-then" ).prop( "disabled", false );
            $( ".hallmarking-rate-h-more" ).prop( "disabled", false );
            $( ".hallmarking-rate-o" ).prop( "disabled", false );
            $( ".card-rate" ).prop( "disabled", false );
            $( ".photo-rate" ).prop( "disabled", false );
        });
        /*===================  Rate Update Form Submit ====================*/
        $('#rateUpdateForm').validate({
            rules: {
                hallmarking_rate_h: {
                    required: true,
                },
                more_then: {
                    required: true,
                },
                hallmarking_rate_h_more: {
                    required: true,
                },
                hallmarking_rate_o: {
                    required: true,
                },
                card_rate:{
                    required: true,
                },
                photo_rate: {
                    required: true,
                }
            },
            highlight: function(element, errorClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            submitHandler: function(form) {
                var data = $('#rateUpdateForm').serialize();
                var more_then = $(".more-then").val();
                $.ajax({
                    url: 'insert-rate-update',
                    type: "POST",
                    data: data,
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    beforeSend: function() {
                        $(".finish-btn").prop("disabled", true);
                        CommonJS.showLoader('reg-frm-loder');;
                    },
                    complete: function() {
                        $(".finish-btn").prop("disabled", false);
                        CommonJS.hideLoader('reg-frm-loder');
                    },
                    success: function(res) {
                        if(res.key == 'S'){
                            var th3 = 'H Rate('+more_then+'pcs.)';
					        $(".h-rate-th").html(th3);
					        var th4 = 'H Rate(more than '+more_then+')';
					        $(".h-rate-more-th").html(th4);
							$('#rateTbl').DataTable().ajax.reload();
                            $( ".hallmarking-rate-h" ).prop( "disabled", true );
                            $( ".more-then" ).prop( "disabled", true );
                            $( ".hallmarking-rate-h-more" ).prop( "disabled", true );
                            $( ".hallmarking-rate-o" ).prop( "disabled", true );
                            $( ".card-rate" ).prop( "disabled", true );
                            $( ".photo-rate" ).prop( "disabled", true );
                            $("#allSubmitBtn").addClass("d-none");
                            $("#allUpdateBtn").removeClass("d-none");
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg,
                            });
                        }else if(res.key == 'E'){
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                    },
                    error: function(error) {
                        CommonJS.Toaster({
                            'type': 'error',
                            'msg': error.responseText,
                        });
                    }
                });
            }
        });

        //----------- Ledger Rate Data Table -----------//
		var rateDataTbl = $('#rateTbl').DataTable({
			"lengthMenu": [
				[100, 500, 1000],
				[100, 500, 1000]
			],
			"processing": false,
			"serverSide": true,
            columnDefs: [
                { orderable: false, targets: -1 }
            ],
			"ajax": {
				"url": base_url + "/ledger-tbl-rate-data",
				"type": "get",
				"dataType": "json",
				beforeSend: function() {
					CommonJS.showLoader('tbl-loader');
				},
				complete: function() {
					CommonJS.hideLoader('tbl-loader');
				},
				"dataSrc": function(result) {
					return result.data;
				},
				"error": function(error) {
					console.log(error.responseText);
				},
			}
		});

        //----------- edit btn click on Data Table -----------//
		$(document).on('click','.open-tbl-frm',function(){
			var id = $(this).data('id');
			$('.hallmarking-rate-h-value'+id).addClass('d-none');
			$('.hallmarking-rate-h'+id).removeClass('d-none');
            $('.hallmarking-rate-h-more-value'+id).addClass('d-none');
			$('.hallmarking-rate-h-more'+id).removeClass('d-none');
            $('.hallmarking-rate-o-value'+id).addClass('d-none');
			$('.hallmarking-rate-o'+id).removeClass('d-none');
            $('.card-rate-value'+id).addClass('d-none');
			$('.card-rate'+id).removeClass('d-none');
            $('.photo-rate-value'+id).addClass('d-none');
			$('.photo-rate'+id).removeClass('d-none');
			$('.edittable-add-data'+id).html('');
			$('.edittable-add-data'+id).html('<i class="fadeIn animated bx bx-save"></i>');
			$('.edittable-add-data'+id).addClass('save-tbl-frm');
			$('.edittable-add-data'+id).addClass('edittable-save-data'+id);
			$('.edittable-add-data'+id).removeClass('open-tbl-frm');
			$('.edittable-add-data'+id).removeClass('edittable-add-data'+id);
			CommonJS.NumberValidation();
		});

        //-------- save data btn click on Data Table ---------//
		$(document).on('click','.save-tbl-frm',function(){
			var id = $(this).data('id');
			var hallmarking_rate_h = $('.hallmarking-rate-h'+id).val();
            var hallmarking_rate_h_more = $('.hallmarking-rate-h-more'+id).val();
			var hallmarking_rate_o = $('.hallmarking-rate-o'+id).val();
			var card_rate = $('.card-rate'+id).val();
			var photo_rate = $('.photo-rate'+id).val();
            if(hallmarking_rate_h == '' || hallmarking_rate_h_more =='' || hallmarking_rate_o == '' || card_rate == '' || photo_rate == ''){
                CommonJS.Toaster({
                    'type': 'error',
                    'msg': 'All fields are required',
                });
            }else{
                $.ajax({
                    url: base_url+"/ledger-rate-update",
                    type: "POST",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data:{id:id , hallmarking_rate_h:hallmarking_rate_h, hallmarking_rate_h_more:hallmarking_rate_h_more, hallmarking_rate_o:hallmarking_rate_o, card_rate:card_rate, photo_rate:photo_rate},
                    dataType: 'json',
                    success: function(res){
                        if(res.key=='S'){
                            
                            CommonJS.Toaster({
                                'type': 'success',
                                'msg': res.msg,
                            });
                        }else{
                            CommonJS.Toaster({
                                'type': 'error',
                                'msg': res.msg,
                            });
                        }
                        $('#rateTbl').DataTable().ajax.reload();
                    },
                    error:function(error){
                        console.log(error.responseText);
                    }
                });
            }
		});
    }
}