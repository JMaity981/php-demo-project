var common_loader = `<div class="spinner-border" style="width: 3rem; height: 3rem;" role="status">	<span class="sr-only">Loading...</span>
							</div>`;
					
var CommonJS = {
	
	/*------------ Menu Active ----------*/
	MenuActive: function (main_menu , sub_menu){
		if(sub_menu != ''){
			var mainclass = 'mnu_active';
			$("#"+sub_menu).addClass('mnu_active');
		}else{
			var mainclass = 'mnu_active';
		}
		$("#"+main_menu).addClass(mainclass);
	},
	
	/*------------ Common Loader ---------*/
		//show loader
	showLoader: function (div_class){
		$(document).find("."+div_class).prepend(common_loader);
	},
		//hide loader
	hideLoader:function (div_class){
		$(document).find("."+div_class).find('.spinner-border').remove();
	},
	
	/*------------ Common Toaster -----------*/
	Toaster:function(param){
    	var	msg = param.msg;
			type = param.type;
		Lobibox.notify(type, {
			pauseDelayOnHover: true,
			size: 'mini',
			icon: 'bx bx-check-circle',
			continueDelayOnInactiveTab: false,
			position: 'bottom right',
			msg: msg
		});
    },
	
	/*-------------- Common Button Loader ---------*/
	ButtonLoader:function (param){
		var setbtn = param.btn_set;
		var btnText = param.btntext;
		var btnloaderhtml = `<button class="btn btn-primary btn-block loader-btn" type="button" disabled>	
								<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
								${btnText}
							</button>`;
		$(document).find("."+setbtn).prepend(btnloaderhtml);
	},
	
	/*---------------- Nubber Validation --------------------*/
	NumberValidation:function(){
		$('.number-validate').keypress(function (event) {
			var _this = $(this);
			if(_this.hasClass('border-danger')){
				_this.removeClass('border-danger')
			}
		    var keycode = event.which;
		    if (!(event.shiftKey == false && (keycode == 46 || keycode == 8 || keycode == 37 || keycode == 39 || (keycode >= 48 && keycode <= 57)))) {
		        event.preventDefault();
		    }
		});
	},

	NumberValidationIntger:function(){
		$('.number-validate-int').keypress(function (event) {
			var _this = $(this);
			if(_this.hasClass('border-danger')){
				_this.removeClass('border-danger')
			}
			// console.log(_this)
		    var keycode = event.which;
		    if (!(event.shiftKey == false && (keycode == 8 || keycode == 37 || keycode == 39 || (keycode >= 48 && keycode <= 57)))) {
		        event.preventDefault();
		    }
		});
	},
	
	/*----------------- Single dropdown ----------------*/
	SingleDropdown:function(){
		$('.single-select').select2({
			theme: 'bootstrap4',
			width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
			placeholder: $(this).data('placeholder'),
			allowClear: Boolean($(this).data('allow-clear')),
		});
	},
	
	/*------------------ Common Daterange --------------*/
	/*commonDaterange : function (){
		$(function() {
			$('.daterange').daterangepicker({
				autoUpdateInput: false,
				locale: {
					cancelLabel: 'Clear'
				}
			});
			$('.daterange').on('apply.daterangepicker', function(ev, picker) {
				$(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format('DD/MM/YYYY'));
			});

			$('.daterange').on('cancel.daterangepicker', function(ev, picker) {
				$(this).val('');
			});
		});
	},*/
	

	getStockDetails : function(){
		$.ajax({
			url:base_url+'/get-stock-details',
			type:'GET',
			beforeSend: function() {
				CommonJS.showLoader('page-wrapper');
				$( ".wrapper" ).addClass( "loader" );
			},
			complete: function() {
				CommonJS.hideLoader('page-wrapper');
				$( ".wrapper" ).removeClass( "loader" );
			},
			success:function(data){
				var html = `<div class="row">
								<div class="col-md-2 col-sm-2 col-lg-2">
									<div class="card radius-15 bg-sunset">
										<div class="card-body">
											<div class="d-flex align-items-center">
												<h2 class="mb-0 text-white paid-amount">0</h2>
											</div>
											<div class="d-flex align-items-center">
												<h4 class="mb-0 text-white">Paid Amount</h4>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-2 col-sm-2 col-lg-2">
									<div class="card radius-15 bg-voilet">
										<div class="card-body">
											<div class="d-flex align-items-center">
												<h2 class="mb-0 text-white customer-fund">0</h2>
											</div>
											<div class="d-flex align-items-center">
												<h4 class="mb-0 text-white">Due Collect.</h4>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-2 col-sm-2 col-lg-2">
									<div class="card radius-15 bg-google">
										<div class="card-body">
											<div class="d-flex align-items-center">
												<h2 class="mb-0 text-white total-cash">0</h2>
											</div>
											<div class="d-flex align-items-center">
												<h4 class="mb-0 text-white">Total Cash</h4>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-2 col-sm-2 col-lg-2">
									<div class="card radius-15 bg-wall">
										<div class="card-body">
											<div class="d-flex align-items-center">
												<h2 class="mb-0 text-white rebon">0</h2>
											</div>
											<div class="d-flex align-items-center">
												<h4 class="mb-0 text-white">Rebon</h4>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-2 col-sm-2 col-lg-2">
									<div class="card radius-15 bg-danger">
										<div class="card-body">
											<div class="d-flex align-items-center">
												<h2 class="mb-0 text-white card-value">0</h2>
											</div>
											<div class="d-flex align-items-center">
												<h4 class="mb-0 text-white">Card</h4>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-2 col-sm-2 col-lg-2">
									<div class="card radius-15 bg-dark-blue">
										<div class="card-body">
											<div class="d-flex align-items-center">
												<h2 class="mb-0 text-white photo">0</h2>
											</div>
											<div class="d-flex align-items-center">
												<h4 class="mb-0 text-white">Photo</h4>
											</div>
										</div>
									</div>
								</div>
							</div>`;
				$('.render-info-box').html(html);
				if(data != ''){
					$('.paid-amount').html(parseInt(data[0].paid_amount));
					$('.customer-fund').html(parseInt(data[0].customer_fund));
					$('.total-cash').html(parseInt(data[0].customer_fund) + parseInt(data[0].paid_amount));
					$('.rebon').html(data[0].rebons);
					$('.card-value').html(data[0].card);
					$('.photo').html(data[0].photo);
				}
			},
			error:function(error){
				console.log(error.responseText);
				CommonJS.hideLoader('card-body');
			},
		});
	},
}