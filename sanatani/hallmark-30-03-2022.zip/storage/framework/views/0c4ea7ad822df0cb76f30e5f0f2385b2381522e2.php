
<?php $__env->startSection('title', 'LAGER'); ?>
<?php $__env->startSection('style'); ?>
	<?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

	<?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<?php echo Html::script('public/assets/pages-js/Delivery.js'); ?>

	<?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

	<?php echo Html::script('public/assets/js/sweetalert.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/lobibox.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

	
	<script>
		CommonJS.getStockDetails();
		CommonJS.NumberValidation();
		CommonJS.NumberValidationIntger();
		DeliveryJs.Delivery();
	</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-3 col-sm-3 col-lg-3"></div>
        <div class="col-md-5 col-sm-5 col-lg-5">
            <div class="card reg-frm-loder">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8 col-sm-8 col-lg-8">
                            <h4>Lager Man Update</h4>
                        </div>
                        <div class="col-md-4 col-sm-4 col-lg-4">
                            <div class="input-group">
                                <input class="form-control input-red total-pcs-lager" type="text" disabled>
                                <div class="input-group-prepend">
                                    <span class="input-group-text">pcs.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::open(array('id' => 'lagerManForm'))); ?>

                <div class="card-body row">
                    <div class="col-md-5 col-sm-5 col-lg-5 form-group">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control number-validate-int lager-sl-no" name="lager_sl_no" placeholder="SL No."> 
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-5 col-lg-5 form-group">
                        <div class="wraper">
                            <input type="radio" name="lager_result" id="lagerResultYid" value="Y">
                            <input type="radio" name="lager_result" id="lagerResultNid" value="N">
                            <label for="lagerResultYid" class="option lager-y-option">
                                <div class="dot"></div>
                                <span><i class="fadeIn animated bx bx-check"></i></span>
                            </label>
                            <label for="lagerResultNid" class="option lager-n-option">
                                <div class="dot"></div>
                                <span><i class="fadeIn animated bx bx-x"></i></span>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-2 col-lg-2 form-group">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/delivery/lager.blade.php ENDPATH**/ ?>