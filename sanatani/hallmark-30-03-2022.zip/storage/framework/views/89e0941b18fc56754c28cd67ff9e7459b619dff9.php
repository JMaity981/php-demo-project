
<?php $__env->startSection('title', 'XRF'); ?>
<?php $__env->startSection('style'); ?>
	<?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

	<?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<?php echo Html::script('public/assets/pages-js/Delivery.js'); ?>

	<?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

	<?php echo Html::script('public/assets/js/sweetalert.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/lobibox.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

	
	<script>
		CommonJS.getStockDetails();
		CommonJS.NumberValidation();
		CommonJS.NumberValidationIntger();
		DeliveryJs.Delivery();
	</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-3 col-sm-3 col-lg-3"></div>
        <div class="col-md-5 col-sm-5 col-lg-5">
            <div class="card reg-frm-loder">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8 col-sm-8 col-lg-8">
                            <h4>XRF Man Update</h4>
                        </div>
                        <div class="col-md-4 col-sm-4 col-lg-4">
                            <div class="input-group">
                                <input class="form-control input-red total-pcs-xrf" type="text" disabled>
                                <div class="input-group-prepend">
                                    <span class="input-group-text">pcs.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::open(array('id' => 'xrfManForm'))); ?>

                <div class="card-body row">
                    <div class="col-md-5 col-sm-5 col-lg-5 form-group">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control number-validate-int xrf-sl-no" name="xrf_sl_no" placeholder="SL No."> 
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-5 col-lg-5 form-group">
                        <div class="wraper">
                            <input type="radio" name="xrf_result" id="xrfResultPid" value="P">
                            <input type="radio" name="xrf_result" id="xrfResultFid" value="F">
                            <label for="xrfResultPid" class="option xrf-p-option">
                                <div class="dot"></div>
                                <span>PASS</span>
                            </label>
                            <label for="xrfResultFid" class="option xrf-f-option">
                                <div class="dot"></div>
                                <span>FAIL</span>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-2 col-lg-2 form-group">
                        <button type="submit" class="btn btn-primary">Save</button> 
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/delivery/xrf.blade.php ENDPATH**/ ?>