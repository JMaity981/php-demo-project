
<?php $__env->startSection('title', 'Stock Update'); ?>
<?php $__env->startSection('style'); ?>
	<?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

	<?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<?php echo Html::script('public/assets/pages-js/StockUpdate.js'); ?>

	<?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/lobibox.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

	
	<script>
		CommonJS.getStockDetails();
		CommonJS.SingleDropdown();
		CommonJS.NumberValidationIntger();
		StockUpdateJs.StockUpdate();
	</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card reg-frm-loder">
        <div class="card-header"><h4>Stock Update</h4></div>
		<div class="tab-content mt-3">
			<div class="tab-pane fade show active">
				<div class="card-body row">
				    <?php if(Session::get('username')!='card'): ?>
                    <div class="col-md-4 col-sm-4 col-lg-4">
                        <div class="card">
                            <div class="card-body row">
                                <div class="col-md-9 col-sm-9 col-lg-9">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Card</span>
                                        </div>
                                        <input class="form-control number-validate-int card-in" name="card_in" type="text" placeholder="Card">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">pcs.</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-lg-2">
								    <button type="button" class="btn btn-primary finish-btn card-in-btn">Buy</button>
                                </div>
                            </div>
                        </div>	
                    </div>
                    <div class="col-md-4 col-sm-4 col-lg-4">
                        <div class="card">
                            <div class="card-body row">
                                <div class="col-md-9 col-sm-9 col-lg-9">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Photo</span>
                                        </div>
                                        <input class="form-control number-validate-int photo-in" name="photo_in" type="text" placeholder="Photo">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">pcs.</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-lg-2">
								    <button type="button" class="btn btn-primary finish-btn photo-in-btn">Buy</button>
                                </div>
                            </div>
                        </div>	
                    </div>
                    <div class="col-md-4 col-sm-4 col-lg-4">
                        <div class="card">
                            <div class="card-body row">
                                <div class="col-md-9 col-sm-9 col-lg-9">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Rebons</span>
                                        </div>
                                        <input class="form-control number-validate-int rebons-in" name="rebons_in" type="text" placeholder="Rebons">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">pcs.</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 col-sm-2 col-lg-2">
								    <button type="button" class="btn btn-primary finish-btn rebons-in-btn">Buy</button>
                                </div>
                            </div>
                        </div>	
                    </div>
				    <?php endif; ?>
				    <?php if(Session::get('username')!='manager'): ?>
                    <div class="col-md-1 col-sm-1 col-lg-1"></div>
                    <div class="col-md-10 col-sm-10 col-lg-10">
                        <div class="card">
                            <div class="card-body row">
                                <div class="col-md-4 col-sm-4 col-lg-4">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Card/Rebons</span>
                                        </div>
                                        <input class="form-control number-validate-int card-rebons-out" name="card_rebons_out" type="text" placeholder="Card">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">pcs.</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-sm-7 col-lg-7">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fadeIn animated bx bx-user"></i></span>
                                        </div>
                                        <select class = "single-select card-rebons-out-ledger" id="jn" >
                                            <option value="" disabled selected>Select Jewellers Name / Propriter Name</option>
                                            <?php $__currentLoopData = $data['ledger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $ledger_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($ledger_data['id']); ?>"><?php echo e($ledger_data['jewellers_name']); ?> / <?php echo e($ledger_data['propriter_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-1 col-sm-1 col-lg-1">
								    <button type="button" class="btn btn-danger ml-20 finish-btn card-rebons-out-btn">Reject</button>
                                </div>
                            </div>
                        </div>	
                    </div>
                    <div class="col-md-1 col-sm-1 col-lg-1"></div>
                    <div class="col-md-1 col-sm-1 col-lg-1"></div>
                    <div class="col-md-10 col-sm-10 col-lg-10">
                        <div class="card">
                            <div class="card-body row">
                                <div class="col-md-4 col-sm-4 col-lg-4">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Photo</span>
                                        </div>
                                        <input class="form-control number-validate-int photo-out" name="photo_out" type="text" placeholder="Photo">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">pcs.</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7 col-sm-7 col-lg-7">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fadeIn animated bx bx-user"></i></span>
                                        </div>
                                        <select class = "single-select photo-out-ledger" id="jn2" >
                                            <option value="" disabled selected>Select Jewellers Name / Propriter Name</option>
                                            <?php $__currentLoopData = $data['ledger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $ledger_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($ledger_data['id']); ?>"><?php echo e($ledger_data['jewellers_name']); ?> / <?php echo e($ledger_data['propriter_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-1 col-sm-1 col-lg-1">
								    <button type="button" class="btn btn-danger ml-20 finish-btn photo-out-btn">Reject</button>
                                </div>
                            </div>
                        </div>	
                    </div>
				    <?php endif; ?>
				</div>
			</div>
		</div>
	</div>
    
    <div class='card'>
        <div class="col-md-12 card-body render-info-box">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/stock_update/stock_update.blade.php ENDPATH**/ ?>