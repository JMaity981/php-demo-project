
<?php $__env->startSection('title', 'Custmer Fund'); ?>
<?php $__env->startSection('style'); ?>
	<?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

	<?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<?php echo Html::script('public/assets/pages-js/CustomerFund.js'); ?>

	<?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

	<?php echo Html::script('public/assets/js/sweetalert.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/lobibox.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

	
	<script>
		CommonJS.getStockDetails();
		CommonJS.SingleDropdown();
		CommonJS.NumberValidation();
		CustomerFundJs.CustomerFund();
	</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card reg-frm-loder">
        <div class="card-header">
            <h4>Customer Fund</h4>
        </div>
        <?php echo e(Form::open(['id' => 'customerFundForm'])); ?>

            <div class="card-body row">
                <div class="col-md-5 col-sm-5 col-lg-5">
                    <label>Select Jewellers Name / Proprietor Name:</label>
                    <div class="input-group">
                        <select class = "single-select ledger_name" id="jn" name="ledger_name">
                            <option value="" disabled selected>Select Jewellers Name / Propriter Name</option>
                            <?php $__currentLoopData = $data['ledger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $ledger_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ledger_data['id']); ?>"><?php echo e($ledger_data['jewellers_name']); ?> / <?php echo e($ledger_data['propriter_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-lg-3">
                    <label>Address:</label>
                    <input class="form-control address" type="text" placeholder="Address" disabled>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <label>Phone No.:</label>
                    <input class="form-control ph_no" type="text" placeholder="Phone no" disabled>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <label>Old Due:</label>    
                    <input class="form-control old_due" type="text" id="old_due" disabled>
                </div>
            </div>
            <div class="card-body row">
                <div class="col-md-7 col-sm-7 col-lg-7">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Remarks</span>
                        </div>
                        <input class="form-control remarks" type="text" name="remarks">
                    </div>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fadeIn animated bx bx-rupee"></i></span>
                        </div>
                        <input class="form-control number-validate amount" type="text" name="amount">
                    </div>
                </div>
                <div class="col-md-2 col-sm-2 col-lg-2">
                    <div class="wraper">
                        <input type="radio" name="transaction_type" id="transaction_type1" value="C">
                        <input type="radio" name="transaction_type" id="transaction_type2" value="D">
                        <label for="transaction_type1" class="option credit-option">
                            <div class="sales dot"></div>
                            <span>Credit</span>
                        </label>
                        <label for="transaction_type2" class="option debit-option">
                            <div class="purchase dot"></div>
                            <span>Debit</span>
                        </label>
                    </div>
                </div>
                <div class="col-md-1 col-sm- col-lg-1">
                    <button type="submit" class="btn btn-primary finish-btn">Submit</button>
                </div>
            </div>
        <?php echo e(Form::close()); ?>

	</div>
    
    <div class='card'>
        <div class="col-md-12 card-body render-info-box">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/customer_fund/customer_fund.blade.php ENDPATH**/ ?>