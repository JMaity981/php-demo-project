<ul class="metismenu" id="menu">
    <?php if(Session::get('username')!='card'): ?>
        <li id = "mnu_ledger">
            <a href="<?php echo e(url('ledger')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-user-check"></i>
                </div>
                <div class="menu-title">Ledger</div>
            </a>
        </li>
    <?php endif; ?>

    <?php if(Session::get('username')=='received' || Session::get('username')=='owner'): ?>
        <li id = "mnu_received">
            <a href="<?php echo e(url('received')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-archive-in"></i>
                </div>
                <div class="menu-title">Received</div>
            </a>
        </li>
    <?php endif; ?>

    <?php if(Session::get('username')!='manager'): ?>
        <li id = "mnu_delivery">
            <a href="<?php echo e(url('delivery')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-archive-out"></i>
                </div>
                <div class="menu-title">Delivery</div>
            </a>
        </li>
    <?php endif; ?>

    <?php if(Session::get('username')!='received'): ?>
        <li id = "mnu_stock_update">
            <a href="<?php echo e(url('stock-update')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-sync"></i>
                </div>
                <div class="menu-title">Stock Update</div>
            </a>
        </li>
    <?php endif; ?>

    <?php if(Session::get('username')=='manager' || Session::get('username')=='owner'): ?>
        <li id = "mnu_rate_update">
            <a href="<?php echo e(url('rate-update')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-rupee"></i>
                </div>
                <div class="menu-title">Rate Update</div>
            </a>
        </li>
    <?php endif; ?>

    <?php if(Session::get('username')=='received' || Session::get('username')=='owner'): ?>
        <li id = "mnu_customer_fund">
            <a href="<?php echo e(url('customer-fund')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-transfer-alt"></i>
                </div>
                <div class="menu-title">Due Collection</div>
            </a>
        </li>

        <li id = "mnu_expenses">
            <a href="<?php echo e(url('expenses')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-layer-minus"></i>
                </div>
                <div class="menu-title">Expenses</div>
            </a>
        </li>
    <?php endif; ?>

    <?php if(Session::get('username')!='card'): ?>
        <li id = "mnu_own_fund">
            <a href="<?php echo e(url('own-fund')); ?>">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-money"></i>
                </div>
                <div class="menu-title">Own Fund</div>
            </a>
        </li>
    <?php endif; ?>

    <?php if(Session::get('username')!='card'): ?>
        <li id = "mnu_satement">
            <a href="javascript:;">
                <div class="parent-icon icon-color-2">
                    <i class="fadeIn animated bx bx-book-reader"></i>
                </div>
                <div class="menu-title">Statement</div>
            </a>
            <ul>
                <li id="mnu_party_due_deposite"> 
                    <a href="<?php echo e(url('party-due-deposite-statement')); ?>">
                        <i class="bx bx-right-arrow-alt"></i>Party Due Deposite
                    </a>
                </li>
                <li id="mnu_daily_seet"> 
                    <a href="<?php echo e(url('daily-seet-statement')); ?>">
                        <i class="bx bx-right-arrow-alt"></i>Daily Sheet
                    </a>
                </li>
                <li id ="mnu_card_in_out"> 
                    <a href="<?php echo e(url('card-in-out-statement')); ?>">
                        <i class="bx bx-right-arrow-alt"></i>Card In Out
                    </a>
                </li>
                <li id ="mnu_rebons_in_out"> 
                    <a href="<?php echo e(url('rebons-in-out-statement')); ?>">
                        <i class="bx bx-right-arrow-alt"></i>Rebons In Out
                    </a>
                </li>
                <li id ="mnu_photo_in_out"> 
                    <a href="<?php echo e(url('photo-in-out-statement')); ?>">
                        <i class="bx bx-right-arrow-alt"></i>Photo In Out
                    </a>
                </li>
                <li id ="mnu_absent_party"> 
                    <a href="<?php echo e(url('absent-party-statement')); ?>">
                        <i class="bx bx-right-arrow-alt"></i>Absent Party
                    </a>
                </li>
                <li id ="mnu_all_party_due"> 
                    <a href="<?php echo e(url('all-party-due-statement')); ?>">
                        <i class="bx bx-right-arrow-alt"></i>All Party Due
                    </a>
                </li>
                <?php if(Session::get('username')=='owner'): ?>
                    <li id="mnu_monthly_working_sheet"> 
                        <a href="<?php echo e(url('monthly-working-sheet-statement')); ?>">
                            <i class="bx bx-right-arrow-alt"></i>Monthly Working Sheet
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Session::get('username')=='owner' || Session::get('username')=='manager'): ?>
                    <li id="mnu_own_fund_statement"> 
                        <a href="<?php echo e(url('own-fund-statement')); ?>">
                            <i class="bx bx-right-arrow-alt"></i>Own Fund
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </li>
    <?php endif; ?>
</ul><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/common/menubar.blade.php ENDPATH**/ ?>