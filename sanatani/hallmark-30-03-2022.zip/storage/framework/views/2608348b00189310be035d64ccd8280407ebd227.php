<table class="table table-striped table-bordered" id="table1">
    <thead class="thead-dark">
        <tr>
            <th scope="col" class="width-5-p">SL No</th>
            <th scope="col">Token No.</th>
            <th scope="col">P/F</th>
            <th scope="col">Jewellers Name</th>
            <th scope="col">Propriter Name</th>
            <th scope="col">Reain Weight</th>
            <th scope="col">Delivery Weight</th>
            <th scope="col">Ornament Piece</th>
            <th scope="col">Hallmark Rate/P</th>
            <th scope="col">Card Rate/P</th>
            <th scope="col">Photo Rate/P</th>
            <th scope="col">Ready</th>
            <th scope="col">Total ch.</th>
            <th scope="col">Paid Amount</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
</table><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/delivery/renderTable.blade.php ENDPATH**/ ?>