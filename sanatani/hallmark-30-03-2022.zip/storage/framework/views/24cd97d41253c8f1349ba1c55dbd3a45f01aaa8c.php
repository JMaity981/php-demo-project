
<?php $__env->startSection('title', 'Delivery'); ?>
<?php $__env->startSection('style'); ?>
	<?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

	<?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<?php echo Html::script('public/assets/pages-js/Delivery.js'); ?>

	<?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

	<?php echo Html::script('public/assets/js/sweetalert.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/lobibox.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

	
	<script>
		CommonJS.getStockDetails();
		CommonJS.NumberValidation();
		CommonJS.NumberValidationIntger();
		DeliveryJs.Delivery();
	</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card reg-frm-loder">
        <div class="card-header">
        	<div class="row">
				<div class="col-md-5 col-sm-5 col-lg-5">
					<h4>Delivery</h4>
				</div>
				<div class="col-md-5 col-sm-5 col-lg-5">
					<?php if(Session::get('username')=='owner'): ?>
						<button class="btn btn-primary xrf-man-btn" type="button">XRF Man Update</button>
						<button class="btn btn-primary lager-man-btn" type="button">Lager Man Update</button>
						<label  class="fs-18">
							Checked
							<input type="checkbox" name="checked_xrf" class="w-28 h-18 checked-xrf" <?php echo e($data['xrf_checked']); ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</label>
					<?php endif; ?>
				</div>
				<div class="col-md-2 col-sm-2 col-lg-2">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">Old Due</span>
						</div>
						<input class="form-control old_due" type="text" id="old_due" disabled>
					</div>
				</div>
			</div>
		</div>
        <div class="card-body">
            <table class="table table-striped table-bordered" id="deliveryTbl">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Blank Column</th>
                        <th scope="col">SL No</th>
                        
                        <th scope="col">P/F</th>
                        <th scope="col">Jewellers Name</th>
                        <th scope="col">Propriter Name</th>
                        <th scope="col">Received Weight</th>
                        <th scope="col" width="85px">Delivery Weight</th>
                        <th scope="col">Ornament Piece</th>
                        <th scope="col">Hallmark Rate/P</th>
                        <th scope="col">Card Rate/P</th>
                        <th scope="col">Photo Rate/P</th>
                        <th scope="col">Ready</th>
                        <th scope="col">Total ch.</th>
                        <th scope="col" width="75px">Paid Amount</th>
                        <th scope="col" width="75px">Action</th>
                        
                    </tr>
                </thead>
            </table>
		</div>
	</div>
	
    <div class='card'>
        <div class="col-md-12 card-body render-info-box">
        </div>
    </div>
	
	<div class="modal fade" id="xrfManModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<div class="row">
						<div class="col-md-7 col-sm-7 col-lg-7">
							<h5 class="modal-title">XRF Man Update</h5>
						</div>
						<div class="col-md-4 col-sm-4 col-lg-4">
							<div class="input-group">
								<input class="form-control input-red total-pcs-xrf" type="text" disabled>
								<div class="input-group-prepend">
									<span class="input-group-text">pcs.</span>
								</div>
							</div>
						</div>
						<div class="col-md-1 col-sm-1 col-lg-1">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>
					</div>
				</div>
				<?php echo e(Form::open(array('id' => 'xrfManForm'))); ?>

					<div class="modal-body row">
						<div class="col-md-6 col-sm-6 col-lg-6 form-group">
							<div class="input-group mb-3">
								<input type="text" class="form-control number-validate-int xrf-sl-no" name="xrf_sl_no" placeholder="SL No."> 
							</div>
						</div>
						<div class="col-md-6 col-sm-6 col-lg-6 form-group">
							<div class="wraper">
								<input type="radio" name="xrf_result" id="xrfResultPid" value="P">
								<input type="radio" name="xrf_result" id="xrfResultFid" value="F">
								<label for="xrfResultPid" class="option xrf-p-option">
									<div class="dot"></div>
									<span>PASS</span>
								</label>
								<label for="xrfResultFid" class="option xrf-f-option">
									<div class="dot"></div>
									<span>FAIL</span>
								</label>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				<?php echo e(Form::close()); ?>

			</div>
		</div>
	</div>
	
	<div class="modal fade" id="lagerManModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<div class="row">
						<div class="col-md-7 col-sm-7 col-lg-7">
							<h5 class="modal-title">Lager Man Update</h5>
						</div>
						<div class="col-md-4 col-sm-4 col-lg-4">
							<div class="input-group">
								<input class="form-control input-red total-pcs-lager" type="text" disabled>
								<div class="input-group-prepend">
									<span class="input-group-text">pcs.</span>
								</div>
							</div>
						</div>
						<div class="col-md-1 col-sm-1 col-lg-1">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
							</button>
						</div>
					</div>
				</div>
				<?php echo e(Form::open(array('id' => 'lagerManForm'))); ?>

					<div class="modal-body row">
						<div class="col-md-6 col-sm-6 col-lg-6 form-group">
							<div class="input-group mb-3">
								<input type="text" class="form-control number-validate-int lager-sl-no" name="lager_sl_no" placeholder="SL No."> 
							</div>
						</div>
						<div class="col-md-6 col-sm-6 col-lg-6 form-group">
							<div class="wraper">
								<input type="radio" name="lager_result" id="lagerResultYid" value="Y">
								<input type="radio" name="lager_result" id="lagerResultNid" value="N">
								<label for="lagerResultYid" class="option lager-y-option">
									<div class="dot"></div>
									<span><i class="fadeIn animated bx bx-check"></i></span>
								</label>
								<label for="lagerResultNid" class="option lager-n-option">
									<div class="dot"></div>
									<span><i class="fadeIn animated bx bx-x"></i></span>
								</label>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				<?php echo e(Form::close()); ?>

			</div>
		</div>
	</div>
	
	<div class="modal fade" id="viewDetailsModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title apend-slno"></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body row">
					<table class="table table-bordered" id="hallmarkTbl">
						<thead class="thead-dark">
							<tr>
								<th scope="col">Type</th>
								<th scope="col">Weight</th>
								<th scope="col">Piece</th>
								<th scope="col">Purity</th>
								<th scope="col">Remarks</th>
							</tr>
						</thead>
						<tbody class="apend-tbody">
						</tbody>
					</table>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/delivery/delivery.blade.php ENDPATH**/ ?>