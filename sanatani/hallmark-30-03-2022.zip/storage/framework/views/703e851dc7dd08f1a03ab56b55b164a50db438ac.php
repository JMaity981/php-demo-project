
<?php $__env->startSection('title', 'Statement'); ?>
<?php $__env->startSection('style'); ?>
    <?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

    <?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

    <?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

    <?php echo Html::style('public/assets/npm/daterangepicker/daterangepicker.css'); ?>

    <?php echo Html::style('public/assets/npm/date-picker/bootstrap-datepicker.css'); ?>

	<?php echo Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

    <?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

    <?php echo Html::script('public/assets/momentjs/latest/moment.min.js'); ?>

    <?php echo Html::script('public/assets/npm/daterangepicker/daterangepicker.min.js'); ?>

    <?php echo Html::script('public/assets/npm/date-picker/bootstrap-datepicker.js'); ?>

    <?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

    <?php echo Html::script('public/assets/pages-js/Statement.js'); ?>


    <script>
        CommonJS.SingleDropdown();
		StatementJs.DailySeet();
        $(".datepicker").datepicker({
	        autoclose: true,
	        todayHighlight: true,
	        format: "dd/mm/yyyy"
	    });
        $('.datepicker').datepicker({ dateFormat: 'dd/mm/yyyy' });
        $('.datepicker').datepicker('setDate', new Date());
    </script>
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="card-title">
                <h5 class="mb-0">Search Daily Sheet</h5>
            </div>
			<hr />
			<div class="form-row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label>Select Date</label>
                        <input type="text" class="form-control datepicker" name="datepicker" placeholder="dd/mm/yyyy">
                    </div>
                </div>
                <input type = "hidden" class="hidden_pageno" value="0">
                <input type="hidden" class="hidden_filepath" value="">
                <div class="col-md-1">
                    <label for="validationCustom02">&nbsp;</label>
                    <div class="form-group">
                        <button class="btn btn-primary statement-search" type="button">Search</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="card-title">
				<div class="row">
					<div class="col-md-9">
						<h5 class="mb-0">Daily Sheet</h5>
					</div>
					<div class="col-md-3">
						<button type="button" class="btn btn-primary btn-sm ml-5 daily-seet-download float-right">Download Statement</button>
					</div>
				</div>
            </div>
            <hr />
			<input type="hidden" class="hidden_tbl_id" value="dailySeetStatementTbl">
            <table class="table table-bordered" id="dailySeetStatementTbl" style="width:100%">
                <thead class="thead-dark ">
                    <tr>
                        <th scope="col">Sl No.</th>
                        
                        <th scope="col">Jewellers/ Customer Name</th>
                        
                        <th scope="col">Received Weight</th>
                        <th scope="col">Delivery Weight</th>
                        <th scope="col">Ornament Piece</th>
                        <th scope="col">Hallmark ch./pcs.</th>
                        
                        <th scope="col">Card rate/P</th>
                        
                        <th scope="col">Photo rate/P</th>
                        <th scope="col">Received Time</th>
                        <th scope="col">Delivery<br>Time</th>
                        <th scope="col">Total Amount</th>
                        <th scope="col">Due</th>
                        <th scope="col">Discount</th>
                        <th scope="col">Received</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/statement/daily_seet.blade.php ENDPATH**/ ?>