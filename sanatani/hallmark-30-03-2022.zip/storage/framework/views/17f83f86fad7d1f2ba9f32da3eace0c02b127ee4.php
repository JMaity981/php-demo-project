
<?php $__env->startSection('title', 'Expenses'); ?>
<?php $__env->startSection('style'); ?>
	<?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

	<?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

	<?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
	<?php echo Html::script('public/assets/pages-js/Expenses.js'); ?>

	<?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

	<?php echo Html::script('public/assets/js/sweetalert.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/lobibox.min.js'); ?>

	<?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

	
	<script>
		CommonJS.getStockDetails();
		CommonJS.NumberValidation();
		ExpensesJs.Expenses();
	</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card reg-frm-loder">
        <div class="card-header">
            <h4>Shop Own Expenses</h4>
        </div>
        <div class="card-body">
            <div class="card">
				<?php echo e(Form::open(['id' => 'expensesForm'])); ?>

                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-lg-5">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Remarks</span>
                                </div>
                                <input class="form-control remarks" type="text" name="remarks">
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-3 col-lg-3">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Amount</span>
                                </div>
                                <input class="form-control number-validate amount" type="text" name="amount">
                            </div>
                        </div>
                        <div class="col-md-1 col-sm- col-lg-1">
                            <button type="submit" class="btn btn-primary finish-btn">Submit</button>
                        </div>
                        <div class="col-md-3 col-sm-3 col-lg-3">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Monthly Expenses</span>
                                </div>
                                <input class="form-control input-field-red monthly-expenses" type="text" value="<?php echo e($data['monthly_expenses']); ?>" disabled>
                            </div>
                        </div>
                    </div>
				<?php echo e(Form::close()); ?>

            </div>
            <table class="table table-bordered" id="expensesTbl">
                <thead class="thead-dark ">
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Remarks</th>
                        <th scope="col">Amount</th>
                    </tr>
                </thead>
            </table>         
		</div>
	</div>
    
    <div class='card'>
        <div class="col-md-12 card-body render-info-box">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/expenses/expenses.blade.php ENDPATH**/ ?>