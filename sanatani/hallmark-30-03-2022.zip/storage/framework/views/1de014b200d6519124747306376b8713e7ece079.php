
<?php $__env->startSection('title', 'Statement'); ?>
<?php $__env->startSection('style'); ?>
    <?php echo Html::style('public/assets/plugins/select2/css/select2.min.css'); ?>

    <?php echo Html::style('public/assets/plugins/select2/css/select2-bootstrap4.css'); ?>

    <?php echo Html::style('public/assets/plugins/notifications/css/lobibox.min.css'); ?>

    <?php echo Html::style('public/assets/npm/daterangepicker/daterangepicker.css'); ?>

	<?php echo Html::style('public/assets/plugins/datatable/css/dataTables.bootstrap4.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo Html::script('public/assets/plugins/select2/js/select2.min.js'); ?>

    <?php echo Html::script('public/assets/plugins/notifications/js/notifications.min.js'); ?>

    <?php echo Html::script('public/assets/momentjs/latest/moment.min.js'); ?>

    <?php echo Html::script('public/assets/npm/daterangepicker/daterangepicker.min.js'); ?>

    <?php echo Html::script('public/assets/plugins/datatable/js/jquery.dataTables.min.js'); ?>

    <?php echo Html::script('public/assets/pages-js/Statement.js'); ?>


    <script>
        CommonJS.SingleDropdown();
		StatementJs.RebonsInOut();
    </script>
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="card-title">
                <h5 class="mb-0">Search Rebons In Out Statement</h5>
            </div>
			<hr />
			<?php echo $__env->make('common.commonStatementSearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="card-title">
				<div class="row">
					<div class="col-md-9">
						<h5 class="mb-0">Rebons In Out Statement List</h5>
					</div>
					<div class="col-md-3">
						
					</div>
				</div>
            </div>
            <hr />
			<input type="hidden" class="hidden_tbl_id" value="rebonsStatementTbl">
            <table class="table table-bordered" id="rebonsStatementTbl">
                <thead class="thead-dark ">
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Jewellers Name</th>
                        <th scope="col">Proprieter Name</th>
                        <th scope="col">Weight</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Buy</th>
                        <th scope="col">Sell</th>
                        <th scope="col">Reject</th>
                        <th scope="col">Balance</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/hallmark/resources/views/statement/rebons_in_out.blade.php ENDPATH**/ ?>