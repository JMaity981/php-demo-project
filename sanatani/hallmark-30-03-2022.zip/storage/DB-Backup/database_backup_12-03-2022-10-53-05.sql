

CREATE TABLE `tbl_customer_transection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_ledger_id` int(10) NOT NULL,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''C''=Credit ''D''=Debit',
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `created_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_customer_transection (id, fk_ledger_id, type, remarks, amount, balance, created_date_time) VALUES ('1','1','D','SL No.-4, Weight-50.296,Ornament-5, Card-3, Photo-4','30.75','-30.75','2022-03-10 16:14:13');

INSERT INTO tbl_customer_transection (id, fk_ledger_id, type, remarks, amount, balance, created_date_time) VALUES ('2','1','D','SL No.-5, Weight-35, Card-15','750.00','-780.75','2022-03-10 17:13:22');

INSERT INTO tbl_customer_transection (id, fk_ledger_id, type, remarks, amount, balance, created_date_time) VALUES ('3','1','C','580 due','200.00','-580.75','2022-03-10 17:14:34');

INSERT INTO tbl_customer_transection (id, fk_ledger_id, type, remarks, amount, balance, created_date_time) VALUES ('4','2','C','300 extra','300.00','300.00','2022-03-10 17:14:58');

INSERT INTO tbl_customer_transection (id, fk_ledger_id, type, remarks, amount, balance, created_date_time) VALUES ('5','2','D','SL No.-9, Weight-45, Card-1','47.01','252.99','2022-03-10 17:21:49');

INSERT INTO tbl_customer_transection (id, fk_ledger_id, type, remarks, amount, balance, created_date_time) VALUES ('6','2','D','SL No.-11, Weight-34.78, Ornament-5','50.00','202.99','2022-03-11 14:33:57');

INSERT INTO tbl_customer_transection (id, fk_ledger_id, type, remarks, amount, balance, created_date_time) VALUES ('7','2','D','SL No.-13, Weight-23.25, Card-10','450.00','-247.01','2022-03-11 14:34:23');


CREATE TABLE `tbl_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `created_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_expenses (id, amount, remarks, created_date_time) VALUES ('1','15.00','tiffin','2022-03-10 17:15:23');

INSERT INTO tbl_expenses (id, amount, remarks, created_date_time) VALUES ('2','472.00','net','2022-03-10 17:15:39');

INSERT INTO tbl_expenses (id, amount, remarks, created_date_time) VALUES ('3','1.00','coin','2022-03-11 12:49:05');


CREATE TABLE `tbl_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jewellers_name` varchar(70) COLLATE utf8_bin NOT NULL,
  `propriter_name` varchar(70) COLLATE utf8_bin NOT NULL,
  `ph_no` varchar(15) COLLATE utf8_bin NOT NULL,
  `lc_no` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `gst_no` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `address` text COLLATE utf8_bin NOT NULL,
  `logo` varchar(15) COLLATE utf8_bin NOT NULL,
  `hallmarking_rate_h` decimal(10,2) NOT NULL,
  `hallmarking_rate_o` decimal(10,2) NOT NULL,
  `card_rate` decimal(10,2) NOT NULL,
  `photo_rate` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `updated_balance_time` datetime DEFAULT current_timestamp(),
  `is_active` char(1) COLLATE utf8_bin NOT NULL COMMENT 'A=''active'',I=''inactive''',
  `is_delete` char(1) COLLATE utf8_bin NOT NULL COMMENT 'Y=''delete'',N=''notdelete''',
  `created_date_time` datetime NOT NULL,
  `updated_date_time` datetime DEFAULT NULL,
  `last_transaction_time` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_ledger (id, jewellers_name, propriter_name, ph_no, lc_no, gst_no, address, logo, hallmarking_rate_h, hallmarking_rate_o, card_rate, photo_rate, balance, updated_balance_time, is_active, is_delete, created_date_time, updated_date_time, last_transaction_time) VALUES ('1','Maity Jewellers','Jayanta Maity','7866955855','LC123456','GST789654','Tamluk','JM','68.00','70.00','50.00','60.00','-580.75','2022-03-10 17:14:34','A','N','2022-03-08 17:32:37','','2022-03-10 17:14:34');

INSERT INTO tbl_ledger (id, jewellers_name, propriter_name, ph_no, lc_no, gst_no, address, logo, hallmarking_rate_h, hallmarking_rate_o, card_rate, photo_rate, balance, updated_balance_time, is_active, is_delete, created_date_time, updated_date_time, last_transaction_time) VALUES ('2','TEST','TEST','1234567890','TEST','TEST','TEST','TEST','68.00','70.00','50.00','60.00','-247.01','2022-03-11 14:34:23','A','N','2022-03-08 17:39:19','','2022-03-11 14:34:23');


CREATE TABLE `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(50) COLLATE utf8_bin NOT NULL,
  `status` char(1) COLLATE utf8_bin NOT NULL COMMENT 'A=''active'',I=''inactive''',
  `last_login` datetime NOT NULL,
  `licence_key` varchar(50) COLLATE utf8_bin NOT NULL,
  `is_delete` char(1) COLLATE utf8_bin NOT NULL COMMENT 'Y=''delete'',N=''not delete''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_login (id, user_name, password, status, last_login, licence_key, is_delete) VALUES ('1','admin','MTIz','A','2022-03-12 10:47:32','MjAyMi0xMC0wMQ==','N');

INSERT INTO tbl_login (id, user_name, password, status, last_login, licence_key, is_delete) VALUES ('2','xrf','MTIz','A','2022-03-08 10:42:17','MjAyMi0xMC0wMQ==','N');

INSERT INTO tbl_login (id, user_name, password, status, last_login, licence_key, is_delete) VALUES ('3','lager','MTIz','A','2022-03-08 10:44:04','MjAyMi0xMC0wMQ==','N');

INSERT INTO tbl_login (id, user_name, password, status, last_login, licence_key, is_delete) VALUES ('4','owner','MTIz','A','2022-03-11 14:30:02','MjAyMi0xMC0wMQ==','N');


CREATE TABLE `tbl_own_fund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''P''=Paid Amount, ''C''=Customer Fund',
  `amount` decimal(10,2) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `updated_balance` decimal(10,2) NOT NULL,
  `created_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_own_fund (id, type, amount, remarks, updated_balance, created_date_time) VALUES ('1','P','300.00','','329.25','2022-03-10 17:15:57');

INSERT INTO tbl_own_fund (id, type, amount, remarks, updated_balance, created_date_time) VALUES ('2','C','200.00','','300.00','2022-03-10 17:16:04');


CREATE TABLE `tbl_rate_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hallmarking_h` decimal(10,2) NOT NULL,
  `hallmarking_o` decimal(10,2) NOT NULL,
  `card` decimal(10,2) NOT NULL,
  `photo` decimal(10,2) NOT NULL,
  `created_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_rate_update (id, hallmarking_h, hallmarking_o, card, photo, created_date_time) VALUES ('1','68.00','70.00','50.00','60.00','2022-03-09 15:40:10');

INSERT INTO tbl_rate_update (id, hallmarking_h, hallmarking_o, card, photo, created_date_time) VALUES ('2','68.00','70.00','50.00','60.00','2022-03-11 14:44:53');

INSERT INTO tbl_rate_update (id, hallmarking_h, hallmarking_o, card, photo, created_date_time) VALUES ('3','68.00','70.00','50.00','60.00','2022-03-11 14:44:57');

INSERT INTO tbl_rate_update (id, hallmarking_h, hallmarking_o, card, photo, created_date_time) VALUES ('4','68.00','70.00','50.00','60.00','2022-03-11 14:45:00');

INSERT INTO tbl_rate_update (id, hallmarking_h, hallmarking_o, card, photo, created_date_time) VALUES ('5','68.00','70.00','50.00','60.00','2022-03-11 14:45:34');


CREATE TABLE `tbl_received` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_ledger_id` int(10) NOT NULL,
  `customer_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `token_no` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `xrf_man` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '''P''= Pass, ''F''=Fail',
  `lager_man` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '''Y''= Yes, ''N''= No',
  `total` decimal(10,2) DEFAULT NULL,
  `paid` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hallmark_type` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '''H''/''O''',
  `hallmark_rate` decimal(10,2) DEFAULT NULL,
  `hallmark_weight` decimal(10,3) DEFAULT NULL,
  `hallmark_piece` int(10) DEFAULT NULL,
  `hallmark_amount` decimal(10,2) DEFAULT NULL,
  `card_rate` decimal(10,2) NOT NULL,
  `card_weight` decimal(10,3) DEFAULT NULL,
  `card_piece` int(10) DEFAULT NULL,
  `card_amount` decimal(10,2) DEFAULT NULL,
  `photo_rate` decimal(10,2) NOT NULL,
  `photo_weight` decimal(10,3) DEFAULT NULL,
  `photo_piece` int(10) DEFAULT NULL,
  `photo_amount` decimal(10,2) DEFAULT NULL,
  `received_time` datetime NOT NULL,
  `delivery_time` datetime DEFAULT NULL,
  `delivery_weight` decimal(10,3) DEFAULT NULL,
  `is_delete` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'N' COMMENT '''Y''=yes, ''N''=no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('1','2','','','P','Y','80.00','77.00','3.00','H','0.00','0.000','0','0.00','40.00','1.123','2','80.00','50.00','0.000','0','0.00','2022-03-09 13:52:09','2022-03-10 15:42:53','1.099','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('2','0','customer demo','','F','Y','350.00','340.00','10.00','O','70.00','25.020','5','350.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-09 15:40:40','2022-03-10 16:06:05','22.300','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('3','0','customer demo','','P','N','100.00','99.00','1.00','H','0.00','0.000','0','0.00','50.00','22.000','2','100.00','60.00','0.000','0','0.00','2022-03-09 15:41:51','2022-03-11 12:46:00','21.000','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('4','1','','150','P','Y','730.00','699.25','0.00','H','68.00','45.657','5','340.00','50.00','1.874','3','150.00','60.00','2.765','4','240.00','2022-03-09 16:34:54','2022-03-10 16:14:13','47.658','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('5','1','','','F','Y','750.00','0.00','0.00','','0.00','0.000','0','0.00','50.00','35.000','15','750.00','60.00','0.000','0','0.00','2022-03-09 19:06:00','2022-03-10 17:13:22','32.000','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('6','0','alan walker','100','P','Y','1140.00','','0.00','O','0.00','0.000','0','0.00','50.00','1.000','12','600.00','60.00','4.545','9','540.00','2022-03-10 16:15:55','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('7','2','','45','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-10 16:20:46','','','Y');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('8','2','','45','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-10 16:21:59','','','Y');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('9','2','','','P','Y','50.00','2.99','0.00','','0.00','0.000','0','0.00','50.00','45.000','1','50.00','60.00','0.000','0','0.00','2022-03-10 16:28:35','2022-03-10 17:21:49','42.350','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('10','1','','','P','','340.00','','0.00','H','68.00','25.020','5','340.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 16:29:12','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('11','2','','','P','Y','350.00','300.00','0.00','O','70.00','34.780','5','350.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 16:30:03','2022-03-11 14:33:57','32.250','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('12','1','','','P','N','340.00','','0.00','H','68.00','34.780','5','340.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 16:49:25','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('13','2','','','P','Y','500.00','50.00','0.00','','0.00','0.000','0','0.00','50.00','23.250','10','500.00','60.00','0.000','0','0.00','2022-03-10 16:51:51','2022-03-11 14:34:23','25.000','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('14','1','','','','','340.00','','0.00','H','68.00','25.020','5','340.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 16:53:25','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('15','1','','','F','','50.00','','0.00','','0.00','0.000','0','0.00','50.00','12.000','1','50.00','60.00','0.000','0','0.00','2022-03-10 16:54:06','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('16','1','','','','','340.00','','0.00','H','68.00','34.780','5','340.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 16:54:38','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('17','2','','','P','','350.00','','0.00','O','70.00','25.020','5','350.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 17:04:09','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('18','2','','','','','350.00','','0.00','O','70.00','45.657','5','350.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 17:07:10','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('19','1','','','','','360.00','','0.00','O','72.00','34.780','5','360.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-10 17:09:37','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('20','0','customer','','','','250.00','','0.00','','0.00','0.000','0','0.00','50.00','1.123','5','250.00','60.00','0.000','0','0.00','2022-03-10 17:10:16','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('21','2','','','','','250.00','','0.00','','0.00','0.000','0','0.00','50.00','22.000','5','250.00','60.00','0.000','0','0.00','2022-03-11 13:04:49','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('22','1','','','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-11 13:06:35','','','Y');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('23','1','','','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-11 13:08:07','','','Y');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('24','1','','','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-11 13:08:20','','','Y');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('25','1','','','','','250.00','','0.00','','0.00','0.000','0','0.00','50.00','11.250','5','250.00','60.00','0.000','0','0.00','2022-03-11 13:08:45','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('26','1','','','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-11 13:09:07','','','Y');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('27','1','','','','','360.00','','0.00','O','72.00','34.780','5','360.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-11 13:09:52','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('28','2','','','','','50.00','','0.00','','0.00','0.000','0','0.00','50.00','45.000','1','50.00','60.00','0.000','0','0.00','2022-03-11 13:13:27','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('29','1','','','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-11 13:13:56','','','Y');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('30','1','','','','','144.00','','0.00','O','72.00','25.020','2','144.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-11 13:14:40','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('31','1','','','','','360.00','','0.00','O','72.00','34.780','5','360.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-11 13:16:21','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('32','1','','','','','340.00','','0.00','H','68.00','45.657','5','340.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-11 13:16:40','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('33','1','','','','','100.00','','0.00','','0.00','0.000','0','0.00','50.00','11.250','2','100.00','60.00','0.000','0','0.00','2022-03-11 13:17:01','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('34','2','','','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-11 13:17:28','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('35','2','','','','','','','0.00','','','','','','50.00','','','','60.00','','','','2022-03-11 13:17:44','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('36','2','','','','','350.00','','0.00','O','70.00','34.780','5','350.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-11 13:18:14','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('37','1','','','','','350.00','','0.00','','0.00','0.000','0','0.00','50.00','13.000','7','350.00','60.00','0.000','0','0.00','2022-03-11 13:21:00','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('38','2','','','','','350.00','','0.00','O','70.00','34.780','5','350.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-11 13:21:28','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('39','2','','','','','60.00','','0.00','','0.00','0.000','0','0.00','50.00','0.000','0','0.00','60.00','1.890','1','60.00','2022-03-11 13:21:43','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('40','1','','','','','340.00','','0.00','H','68.00','34.780','5','340.00','50.00','0.000','0','0.00','60.00','0.000','0','0.00','2022-03-11 13:22:23','','','N');

INSERT INTO tbl_received (id, fk_ledger_id, customer_name, token_no, xrf_man, lager_man, total, paid, discount, hallmark_type, hallmark_rate, hallmark_weight, hallmark_piece, hallmark_amount, card_rate, card_weight, card_piece, card_amount, photo_rate, photo_weight, photo_piece, photo_amount, received_time, delivery_time, delivery_weight, is_delete) VALUES ('41','2','','','','','240.00','','0.00','','0.00','0.000','0','0.00','50.00','0.000','0','0.00','60.00','2.765','4','240.00','2022-03-11 13:22:48','','','N');


CREATE TABLE `tbl_received_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_received_id` int(11) NOT NULL,
  `weight` decimal(10,3) NOT NULL,
  `piece` int(5) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('1','1','1.123','2','remarks2');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('2','3','22.000','2','remarks2');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('3','4','1.874','3','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('4','5','22.000','2','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('5','5','1.000','12','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('6','5','12.000','1','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('7','6','1.000','12','remarks2');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('8','9','45.000','1','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('9','13','12.000','5','remarks2');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('10','13','11.250','5','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('11','15','12.000','1','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('12','20','1.123','5','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('13','21','22.000','5','remarks2');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('14','25','11.250','5','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('15','28','45.000','1','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('16','33','11.250','2','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('17','37','12.000','5','');

INSERT INTO tbl_received_card (id, fk_received_id, weight, piece, remarks) VALUES ('18','37','1.000','2','');


CREATE TABLE `tbl_received_hallmark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_received_id` int(11) NOT NULL,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''H''/''O''',
  `weight` decimal(10,3) NOT NULL,
  `piece` int(5) NOT NULL,
  `purity` decimal(10,2) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `delivery_weight` decimal(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('1','2','O','25.020','5','12.00','cash','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('2','4','H','45.657','5','12.30','cash','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('3','7','O','34.780','5','20.53','hallmark','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('4','8','O','34.780','5','20.53','hallmark','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('5','10','H','25.020','5','80.25','','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('6','11','O','34.780','5','20.53','cash','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('7','12','H','34.780','5','12.30','','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('8','14','H','25.020','5','20.53','','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('9','16','H','34.780','5','18.82','','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('10','17','O','25.020','5','12.30','cash','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('11','18','O','45.657','5','50.32','remarks1','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('12','19','O','34.780','5','18.82','','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('13','26','O','34.780','5','50.32','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('14','27','O','34.780','5','50.32','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('15','29','O','25.020','2','20.53','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('16','30','O','25.020','2','20.53','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('17','31','O','34.780','5','20.53','tiffin','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('18','32','H','45.657','5','18.82','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('19','34','O','34.780','5','12.30','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('20','35','O','34.780','5','12.30','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('21','36','O','34.780','5','12.30','580 due','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('22','38','O','34.780','5','18.82','tiffin','');

INSERT INTO tbl_received_hallmark (id, fk_received_id, type, weight, piece, purity, remarks, delivery_weight) VALUES ('23','40','H','34.780','5','12.30','580 due','');


CREATE TABLE `tbl_received_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_received_id` int(11) NOT NULL,
  `weight` decimal(10,3) NOT NULL,
  `piece` int(5) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_received_photo (id, fk_received_id, weight, piece, remarks) VALUES ('1','4','2.765','4','');

INSERT INTO tbl_received_photo (id, fk_received_id, weight, piece, remarks) VALUES ('2','6','1.890','4','remarks4454vbxcvcvxb');

INSERT INTO tbl_received_photo (id, fk_received_id, weight, piece, remarks) VALUES ('3','6','2.655','5','remarks4fgfdvbvccvbbvbcx');

INSERT INTO tbl_received_photo (id, fk_received_id, weight, piece, remarks) VALUES ('4','39','1.890','1','');

INSERT INTO tbl_received_photo (id, fk_received_id, weight, piece, remarks) VALUES ('5','41','2.765','4','');


CREATE TABLE `tbl_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `proprietor_name` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `address` text COLLATE utf8_bin DEFAULT NULL,
  `ph_no` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `billing_name` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_shop (id, shop_name, proprietor_name, address, ph_no, email, billing_name) VALUES ('1','SANATANI','','','','','S.H.C.');


CREATE TABLE `tbl_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card` int(10) NOT NULL,
  `photo` int(10) NOT NULL,
  `rebons` int(10) NOT NULL,
  `paid_amount` decimal(10,2) NOT NULL,
  `customer_fund` decimal(10,2) NOT NULL,
  `updated_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_stock (id, card, photo, rebons, paid_amount, customer_fund, updated_date_time) VALUES ('1','65','94','65','780.24','300.00','2022-03-10 17:13:51');


CREATE TABLE `tbl_stock_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''I''=In, ''R''=Reject, ''S''=Sell',
  `fk_received_id` int(11) DEFAULT NULL COMMENT 'If type=''S''',
  `fk_ledger_id` int(11) DEFAULT NULL,
  `stock_type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''C''=Card, ''P''=Photo, ''R''= Rebons',
  `piece` int(5) NOT NULL,
  `balance` int(11) NOT NULL,
  `created_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('1','S','1','2','C','2','-2','2022-03-10 15:42:53');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('2','S','1','2','R','2','-2','2022-03-10 15:42:53');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('3','I','','','C','100','98','2022-03-10 15:43:35');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('4','I','','','P','100','100','2022-03-10 15:43:38');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('5','I','','','R','100','98','2022-03-10 15:43:42');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('6','S','4','1','C','3','95','2022-03-10 16:14:13');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('7','S','4','1','R','3','95','2022-03-10 16:14:13');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('8','S','4','1','P','4','96','2022-03-10 16:14:13');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('9','S','5','1','C','15','80','2022-03-10 17:13:22');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('10','S','5','1','R','15','80','2022-03-10 17:13:22');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('11','R','','1','C','2','78','2022-03-10 17:13:45');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('12','R','','1','R','2','78','2022-03-10 17:13:45');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('13','R','','1','P','2','94','2022-03-10 17:13:51');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('14','S','9','2','C','1','77','2022-03-10 17:21:49');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('15','S','9','2','R','1','77','2022-03-10 17:21:49');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('16','S','3','0','C','2','75','2022-03-11 12:46:00');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('17','S','3','0','R','2','75','2022-03-11 12:46:00');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('18','S','13','2','C','10','65','2022-03-11 14:34:23');

INSERT INTO tbl_stock_update (id, type, fk_received_id, fk_ledger_id, stock_type, piece, balance, created_date_time) VALUES ('19','S','13','2','R','10','65','2022-03-11 14:34:23');
