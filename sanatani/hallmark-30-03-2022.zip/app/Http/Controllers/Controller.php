<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Ledger;
use App\Models\Mlogin;
use App\Models\CustomerTransection;
use App\Models\Expenses;
use App\Models\OwnFund;
use App\Models\RateUpdate;
use App\Models\Received;
use App\Models\ReceivedCard;
use App\Models\ReceivedPhoto;
use App\Models\ReceivedHallmark;
use App\Models\Shop;
use App\Models\Stock;
use App\Models\StockUpdate;

use DirectoryIterator;
use ZipArchive;
use \RecursiveIteratorIterator;
use File;
use DB;
use PDF;
use Illuminate\Support\Facades\View;


class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

	protected $shop_name;

	public function __construct(){
		$shop_data = Shop::get()->toArray();
		$this->shop_name = $shop_data[0]['shop_name'];

		$viewShare['shop_name'] = $this->shop_name;
		View::share('commonViewShare', $viewShare);
	}

	//get gold cash details
	public function getStockDetails (Request $request){
		$val = Stock::get()->toArray();
		return $val;
	}
	/*----------------- Create zip folder in the server ---------------*/
	public function zipDownload ($filename){
		//print_r($filename);die;
		$filenameexp = explode('/', $filename);
		
		$rootPath = $filename;
		
        $fileName = storage_path('zip-pdf/'.$filenameexp[1].'.zip');
        $zip = new ZipArchive;
        if ($zip->open($fileName, ZipArchive::CREATE) === TRUE)
        {
			foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($rootPath)) as $filename) {
				$files[] = $filename;
			}
			foreach ($files as $name => $file)
			{
				if (!$file->isDir())
				{
					$filePath = $file->getRealPath();
					$relativePath = substr($filePath, strlen($rootPath) + 1);

					$zip->addFile($filePath, $relativePath);
				}
			}
			$zip->close();
        }
	}
	public function downloadAnyFile(Request $request){
		$file = $request->filename;
		
		$headers = array(
			'Content-Type: application/pdf',
		);

  		return Response::download($file, basename($file), $headers)->deleteFileAfterSend(true);
	}
	/*------------------ Zip download in the local server -----------------*/
	/*public function saveZipFile(Request $request){
		//print_r($request->all());die;
		$filename = $request->filename;
		$fileurl = storage_path('zip-pdf/'.$filename.'.zip');
		return Response::download($fileurl, ''.$filename.'.zip', array('Content-Type: application/octet-stream','Content-Length: '. filesize($fileurl)))->deleteFileAfterSend(true);
	}*/
	/*--------- db bkp -----------*/
	/*public function dbBkp (Request $request){
		$file = storage_path('test/test.sql');
		//exec('mysqldump gold_store --user=root --password=Lionofsai!23 > '.$file.'/fileName.sql', $errors);
		
		Spatie\DbDumper\Databases\MySql::create()
			->setDbName('gold_store')
			->setUserName('root')
			->setPassword('Lionofsai!23')
			->dumpToFile($file);
			
			
		/*$filename = "backup_".strtotime(now()).".sql";
		$command = "mysqldump --user=".env('DB_USERNAME')." --password=".env('DB_PASSWORD')." --host=".env('DB_HOST')." ".env('DB_DATABASE')." > ".storage_path()."/app/backup/".$filename;
		//print_r($command);die;
		$t = exec($command);
		//return $t;
	}*/

	public function dbexport(Request $request){
		$path = self::backupDatabaseAllTables();
		return response()->download($path)->deleteFileAfterSend(true);
	}

	public static function backupDatabaseAllTables(){
		//ENTER THE RELEVANT INFO BELOW
		$mysqlHostName      = env('DB_HOST');
		$mysqlUserName      = env('DB_USERNAME');
		$mysqlPassword      = env('DB_PASSWORD');
		$DbName             = env('DB_DATABASE');
		$file_name = 'database_backup_' . date('d-m-Y-H-i-s') . '.sql';


		$queryTables = json_decode(json_encode(\DB::select(\DB::raw('SHOW TABLES')), true), true);
		$tables= array_column($queryTables, 'Tables_in_hallmark') ;
		
		$connect = DB::connection()->getPdo();
		$get_all_table_query = "SHOW TABLES";
		$statement = $connect->prepare($get_all_table_query);
		$statement->execute();
		$result = $statement->fetchAll();
		$output = '';
		foreach($tables as $table)
		{
			$show_table_query = "SHOW CREATE TABLE " . $table . "";
			$statement = $connect->prepare($show_table_query);
			$statement->execute();
			$show_table_result = $statement->fetchAll();

			foreach($show_table_result as $show_table_row)
			{
				$output .= "\n\n" . $show_table_row["Create Table"] . ";\n\n";
			}
			$select_query = "SELECT * FROM " . $table . "";
			$statement = $connect->prepare($select_query);
			$statement->execute();
			$total_row = $statement->rowCount();

			for($count=0; $count<$total_row; $count++)
			{
				$single_result = $statement->fetch(\PDO::FETCH_ASSOC);
				$table_column_array = array_keys($single_result);
				$table_value_array = array_values($single_result);
				$output .= "\nINSERT INTO $table (";
				$output .= "" . implode(", ", $table_column_array) . ") VALUES (";
				$output .= "'" . implode("','", $table_value_array) . "');\n";
			}
		}

		$path = storage_path("DB-Backup");
		File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);
		File::put($path."/".$file_name,$output);	
		return $path."/".$file_name;
	}
}
