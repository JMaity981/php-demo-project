<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Ledger;
use App\Models\RateUpdate;
use DB;
use Response;
use Session;


class RateUpdateCtrl extends Controller{
    public function rateUpdate (){
		$data['main_menu'] = 'mnu_rate_update';
		$data['sub_menu'] = '';
		$data['breadcrumb'] = [['rate-update', 'Rate Update']];
        $rate_data = RateUpdate::take(1)->orderBy('created_date_time', 'DESC')->get()->toArray();
		$data['hallmarking_h_rate'] = (!empty($rate_data)) ? $rate_data[0]['hallmarking_h'] : '0.00';
		$data['hallmarking_h_rate_more'] = (!empty($rate_data)) ? $rate_data[0]['hallmarking_h_more'] : '0.00';
		$data['more_then'] = (!empty($rate_data)) ? $rate_data[0]['more_then'] : 0;
		$data['hallmarking_o_rate'] = (!empty($rate_data)) ? $rate_data[0]['hallmarking_o'] : '0.00';
		$data['card_rate'] = (!empty($rate_data)) ? $rate_data[0]['card'] : '0.00';
		$data['photo_rate'] = (!empty($rate_data)) ? $rate_data[0]['photo'] : '0.00';
        $username = Session::get('username');
		if($username=='owner' || $username=='manager')
		return view('rate_update.rate_update')->withData($data);
        else
        return abort(404);
    }

    public function insertRateUpdate (Request $request){
        $insert_array = array(
			"hallmarking_h" => $request->hallmarking_rate_h,
			"hallmarking_h_more" => $request->hallmarking_rate_h_more,
			"more_then" => $request->more_then,
			"hallmarking_o" => $request->hallmarking_rate_o,
			"card" => $request->card_rate,
			"photo" => $request->photo_rate,
			"created_date_time" => date('Y-m-d H:i:s')
		);  
		$insert = RateUpdate::insertGetId($insert_array);

		$update = Ledger::query()->update(['hallmarking_rate_h'=> $request->hallmarking_rate_h, 'hallmarking_rate_h_more'=> $request->hallmarking_rate_h_more, 'hallmarking_rate_o'=> $request->hallmarking_rate_o, 'card_rate'=> $request->card_rate, 'photo_rate'=> $request->photo_rate]);

		$return = ($insert) ? ['key' => 'S', 'msg' => 'All Ledger Rate Updated Successfully.'] : ['key' => 'E', 'msg' => 'Updated Un-successfully.'];
        return $return;
    }

    public function ledgerTblRateData (Request $request){
		$columns = array('jewellers_name', 'propriter_name', 'hallmarking_rate_h', 'hallmarking_rate_h_more', 'hallmarking_rate_o', 'card_rate', 'photo_rate');
		$orderBy = "ORDER BY ". $columns[$request->input('order.0.column')] ." " .$request->input('order.0.dir');
		$search_qry = '';
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$search_qry = " AND (UPPER(jewellers_name) LIKE '%".$search."%' OR UPPER(propriter_name) LIKE '%".$search."%')";
		}

		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		$where = "WHERE is_active = 'A' AND is_delete = 'N'";
		$from = "FROM tbl_ledger";
		$qry = "SELECT id, jewellers_name, propriter_name, hallmarking_rate_h, hallmarking_rate_h_more, hallmarking_rate_o, card_rate, photo_rate $from $where  $search_qry $orderBy $limitOffset";

		$total_row = DB::select("SELECT COUNT(*) as total_record $from $where $search_qry");
		
		$j_decode_total_row = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($j_decode_total_row) > 0){
			$total_data = $j_decode_total_row[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decodeGetData = json_decode(json_encode($GetData , true), true);
		$data = [];

		if(!empty($decodeGetData)){
			foreach($decodeGetData as $value){
				$hallmarking_rate_h = '<span class="hallmarking-rate-h-value'.$value['id'].'">'.$value['hallmarking_rate_h'].'</span><input type="text" class="form-control number-validate input-sm hallmarking-rate-h'.$value['id'].' d-none" value="'.$value['hallmarking_rate_h'].'">';
				$hallmarking_rate_h_more = '<span class="hallmarking-rate-h-more-value'.$value['id'].'">'.$value['hallmarking_rate_h_more'].'</span><input type="text" class="form-control number-validate input-sm hallmarking-rate-h-more'.$value['id'].' d-none" value="'.$value['hallmarking_rate_h_more'].'">';
                $hallmarking_rate_o = '<span class="hallmarking-rate-o-value'.$value['id'].'">'.$value['hallmarking_rate_o'].'</span><input type="text" class="form-control number-validate input-sm hallmarking-rate-o'.$value['id'].' d-none" value="'.$value['hallmarking_rate_o'].'">';
                $card_rate = '<span class="card-rate-value'.$value['id'].'">'.$value['card_rate'].'</span><input type="text" class="form-control number-validate input-sm card-rate'.$value['id'].' d-none" value="'.$value['card_rate'].'">';
                $photo_rate = '<span class="photo-rate-value'.$value['id'].'">'.$value['photo_rate'].'</span><input type="text" class="form-control number-validate input-sm photo-rate'.$value['id'].' d-none" value="'.$value['photo_rate'].'">';
				$btn = '<button type="button" class="btn btn-primary btn-sm ml-4 open-tbl-frm edittable-add-data'.$value['id'].'" data-id="'.$value['id'].'"><i class="fadeIn animated bx bx-edit"></i></button>';
				$row = array();
				$row[] = $value['jewellers_name'];
				$row[] = $value['propriter_name'];
				$row[] = $hallmarking_rate_h;
				$row[] = $hallmarking_rate_h_more;
				$row[] = $hallmarking_rate_o;
				$row[] = $card_rate;
				$row[] = $photo_rate;
				$row[] = $btn;
				$data[] = $row;
			}
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

    public function ledgerRateUpdate (Request $request){
        $update_ledger_data = Ledger::where('id', $request->id)->update(['hallmarking_rate_h'=> $request->hallmarking_rate_h, 'hallmarking_rate_h_more'=> $request->hallmarking_rate_h_more,  'hallmarking_rate_o'=> $request->hallmarking_rate_o, 'card_rate'=> $request->card_rate, 'photo_rate'=> $request->photo_rate]);
		$return = $update_ledger_data ? ['key' => 'S', 'msg' => 'Rate Updated Successfully.'] : ['key' => 'E', 'msg' => 'Updated Un-successfully.'];
        return $return;
    }
}