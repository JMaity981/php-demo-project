<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Ledger;
use App\Models\RateUpdate;
use App\Models\CustomerTransection;
use App\Models\Stock;

use DB;
use Response;
use Session;

class CustomerFundCtrl extends Controller{
    public function customerFund (){
        $data['main_menu'] = 'mnu_customer_fund';
        $data['sub_menu'] = '';
        $data['breadcrumb'] = [['customer-fund', 'Customer Fund']];
        $data['ledger'] = Ledger::get()->where('is_active','A')->where('is_delete','N')->toArray();
        $username = Session::get('username');
		if($username=='received' || $username=='owner')
        return view('customer_fund.customer_fund')->withData($data);
        else
        return abort(404);
    }

    public function customerFundSubmit (Request $request){
		$time = date('Y-m-d H:i:s');
		$ledger_id = $request->ledger_name;
        $amount = $request->amount;
        $type = $request->transaction_type;

        $ledger_data = Ledger::select('balance')->where('id',$ledger_id)->get()->toArray();
        $update_balance = ($type=='C') ? ($ledger_data[0]['balance'] + $amount) : ($ledger_data[0]['balance'] - $amount);

        if($type=='C'){
            $stock_data = Stock::select('customer_fund')->get()->toArray();
            $customer_fund = $stock_data[0]['customer_fund'] + $amount;
            $update_stock = Stock::query()->update(['customer_fund'=> $customer_fund]);
        }
       

		$insert_array = array(
			"fk_ledger_id" => $ledger_id,
			"type" => $type,
            "remarks" => $request->remarks,
			"amount" => $amount,
			"balance" => $update_balance,
			"created_date_time" => $time
		);  
		$insert = CustomerTransection::insertGetId($insert_array);
        $update_ledger = Ledger::where('id', $ledger_id)->update(['balance'=> $update_balance, 'updated_balance_time'=> $time, 'last_transaction_time'=> $time]);

        $return = ($insert && $update_ledger) ? ['key' => 'S', 'msg' => 'Inserted Successfully.'] : ['key' => 'E', 'msg' => 'Inserted Un-successfully.'];
        return $return;
    }
}