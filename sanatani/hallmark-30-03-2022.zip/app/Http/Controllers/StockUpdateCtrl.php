<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Ledger;
use App\Models\Stock;
use App\Models\StockUpdate;
use DB;
use Response;
use Session;

class StockUpdateCtrl extends Controller{
    public function stockUpdate (){
        $data['main_menu'] = 'mnu_stock_update';
        $data['sub_menu'] = '';
        $data['breadcrumb'] = [['stock-update', 'Stock Update']];
        $data['ledger'] = Ledger::get()->where('is_active','A')->where('is_delete','N')->toArray();
        $username = Session::get('username');
		if($username=='manager' || $username=='card' || $username=='owner')
        return view('stock_update.stock_update')->withData($data);
        else
        return abort(404);
    }

    public function cardIn (Request $request){
        $pcs = $request->pcs;
        $stock_data = Stock::select('card','id')->take(1)->orderBy('id', 'DESC')->get()->toArray();
		$stock = $stock_data[0]['card'];
        $update_stock = $stock + $pcs;
        $time = date('Y-m-d H:i:s');

        $insert_array = array(
			"type" => 'I',
			"stock_type" => 'C',
			"piece" => $pcs,
			"balance" => $update_stock,
			"created_date_time" => $time
		);  
		$insert = StockUpdate::insertGetId($insert_array);

        $update = Stock::where('id', $stock_data[0]['id'])->update(['card'=> $update_stock, 'updated_date_time'=> $time]);

        $return = ($insert && $update) ? ['key' => 'S', 'msg' => 'Card Inserted Successfully.'] : ['key' => 'E', 'msg' => 'Card Updated Un-successfully.'];
        return $return;
    }

    public function photoIn (Request $request){
        $pcs = $request->pcs;
        $stock_data = Stock::select('photo','id')->take(1)->orderBy('id', 'DESC')->get()->toArray();
		$stock = $stock_data[0]['photo'];
        $update_stock = $stock + $pcs;
        $time = date('Y-m-d H:i:s');

        $insert_array = array(
			"type" => 'I',
			"stock_type" => 'P',
			"piece" => $pcs,
			"balance" => $update_stock,
			"created_date_time" => $time
		);  
		$insert = StockUpdate::insertGetId($insert_array);

        $update = Stock::where('id', $stock_data[0]['id'])->update(['photo'=> $update_stock, 'updated_date_time'=> $time]);

        $return = ($insert && $update) ? ['key' => 'S', 'msg' => 'Photo Inserted Successfully.'] : ['key' => 'E', 'msg' => 'Photo Updated Un-successfully.'];
        return $return;
    }

    public function rebonsIn (Request $request){
        $pcs = $request->pcs;
        $stock_data = Stock::select('rebons','id')->take(1)->orderBy('id', 'DESC')->get()->toArray();
		$stock = $stock_data[0]['rebons'];
        $update_stock = $stock + $pcs;
        $time = date('Y-m-d H:i:s');

        $insert_array = array(
			"type" => 'I',
			"stock_type" => 'R',
			"piece" => $pcs,
			"balance" => $update_stock,
			"created_date_time" => $time
		);  
		$insert = StockUpdate::insertGetId($insert_array);

        $update = Stock::where('id', $stock_data[0]['id'])->update(['rebons'=> $update_stock, 'updated_date_time'=> $time]);

        $return = ($insert && $update) ? ['key' => 'S', 'msg' => 'Rebons Inserted Successfully.'] : ['key' => 'E', 'msg' => 'Rebons Updated Un-successfully.'];
        return $return;
    }

    public function cardRebonsOut (Request $request){
        $pcs = $request->pcs;
        $ledger_id = $request->ledger_id;
        $stock_data = Stock::select('card','rebons','id')->take(1)->orderBy('id', 'DESC')->get()->toArray();
		$card_stock = $stock_data[0]['card'];
		$rebons_stock = $stock_data[0]['rebons'];
        $update_card_stock = $card_stock - $pcs;
        $update_rebons_stock = $rebons_stock - $pcs;
        $time = date('Y-m-d H:i:s');

        $insert_array = [];
        $insert_array[] = [
			"type" => 'R',
            "fk_ledger_id" => $ledger_id,
			"stock_type" => 'C',
			"piece" => $pcs,
			"balance" => $update_card_stock,
			"created_date_time" => $time
        ];  
        $insert_array[] = [
			"type" => 'R',
            "fk_ledger_id" => $ledger_id,
			"stock_type" => 'R',
			"piece" => $pcs,
			"balance" => $update_rebons_stock,
			"created_date_time" => $time
        ];
		$insert = StockUpdate::insert($insert_array);

        $update = Stock::where('id', $stock_data[0]['id'])->update(['card'=> $update_card_stock, 'rebons'=> $update_rebons_stock, 'updated_date_time'=> $time]);

        $return = ($insert && $update) ? ['key' => 'S', 'msg' => 'Card/Rebons Rejected Successfully.'] : ['key' => 'E', 'msg' => 'Card/Rebons Updated Un-successfully.'];
        return $return;
    }

    public function photoOut (Request $request){
        $pcs = $request->pcs;
        $ledger_id = $request->ledger_id;
        $stock_data = Stock::select('photo','id')->take(1)->orderBy('id', 'DESC')->get()->toArray();
		$stock = $stock_data[0]['photo'];
        $update_stock = $stock - $pcs;
        $time = date('Y-m-d H:i:s');

        $insert_array = array(
			"type" => 'R',
            "fk_ledger_id" => $ledger_id,
			"stock_type" => 'P',
			"piece" => $pcs,
			"balance" => $update_stock,
			"created_date_time" => $time
		);  
		$insert = StockUpdate::insertGetId($insert_array);

        $update = Stock::where('id', $stock_data[0]['id'])->update(['photo'=> $update_stock, 'updated_date_time'=> $time]);

        $return = ($insert && $update) ? ['key' => 'S', 'msg' => 'Photo Rejected Successfully.'] : ['key' => 'E', 'msg' => 'Photo Updated Un-successfully.'];
        return $return;
    }
}
