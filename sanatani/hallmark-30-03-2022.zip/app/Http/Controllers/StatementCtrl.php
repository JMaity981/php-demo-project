<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Ledger;
use App\Models\Mlogin;
use App\Models\CustomerTransection;
use App\Models\Expenses;
use App\Models\OwnFund;
use App\Models\RateUpdate;
use App\Models\Received;
use App\Models\ReceivedCard;
use App\Models\ReceivedPhoto;
use App\Models\ReceivedHallmark;
use App\Models\Shop;
use App\Models\Stock;
use App\Models\StockUpdate;
use DB;
use Response;
use PDF;
use Session;


class StatementCtrl extends Controller{
    /*=========== Party Due Deposit View ============*/
    public function partyDueDepositeStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_party_due_deposite';
		$data['breadcrumb'] = [['party-due-deposite-statement', 'Statement'],['party-due-deposite-statement','Party Due Deposite']];
		$data['ledger'] = Ledger::where('is_active','A')->where('is_delete','N')->get()->toArray();
		$username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('statement.party_due_deposit')->withData($data);
		else
        return abort(404);
    }

    /*=========== Party Due Deposit Table ============*/
	public function partyDueDepositeStatementData (Request $request){
		$ledger_id = $request->ledger_id;
		$columns = array('tbl_customer_transection.created_date_time', 'tbl_ledger.jewellers_name','tbl_ledger.propriter_name','tbl_customer_transection.remarks','tbl_customer_transection.amount','tbl_customer_transection.amount','tbl_customer_transection.balance','tbl_customer_transection.balance');

		$daterange = explode('-', $request->daterange);

		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]) .' 00:00:00';

		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]).' 23:59:59';

		$where = '';
		$whereraw = '';
		if($ledger_id != ''){
			$where = " AND tbl_customer_transection.fk_ledger_id = '".$ledger_id."'";
		}
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$whereraw = " AND (UPPER(tbl_ledger.jewellers_name) LIKE '%".$search."%' OR UPPER(tbl_ledger.propriter_name) LIKE '%".$search."%' OR UPPER(tbl_customer_transection.remarks) LIKE '%".$search."%')";
		}
		$orderBy = "ORDER BY ". $columns[$request->input('order.0.column')] ." " .$request->input('order.0.dir');

		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";

		$qry = "SELECT tbl_customer_transection.*, tbl_ledger.jewellers_name, tbl_ledger.propriter_name FROM tbl_customer_transection LEFT JOIN tbl_ledger ON tbl_customer_transection.fk_ledger_id = tbl_ledger.id WHERE tbl_customer_transection.created_date_time BETWEEN '".$startDate."' AND '".$endDate."' $where $whereraw $orderBy $limitOffset";

		$total_row = DB::select("SELECT COUNT(*) as total_record FROM tbl_customer_transection LEFT JOIN tbl_ledger ON tbl_customer_transection.fk_ledger_id=tbl_ledger.id WHERE tbl_customer_transection.created_date_time BETWEEN '".$startDate."' AND '".$endDate."' $where $whereraw");

		$sum_table = DB::select("SELECT SUM(CASE WHEN type = 'C' THEN amount ELSE 0 END) TotalCredit, SUM(CASE WHEN type = 'D' THEN amount ELSE 0 END) TotalDebit FROM tbl_customer_transection LEFT JOIN tbl_ledger ON tbl_customer_transection.fk_ledger_id=tbl_ledger.id WHERE tbl_customer_transection.created_date_time BETWEEN '".$startDate."' AND '".$endDate."' $where $whereraw");
		$sum_decode = json_decode(json_encode($sum_table,true),true);

		$j_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($j_decode) > 0){
			$total_data = $j_decode[0]['total_record'];
		}
		$GetData = DB::select($qry);

		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				$expdate = explode(' ', $value['created_date_time']);
				$date = date("d/m/Y", strtotime($expdate[0]));

				$row = array();
				$row[] = $date;
				$row[] = $value['jewellers_name'];
				$row[] = $value['propriter_name'];
				$row[] = $value['remarks'];
				$row[] = $value['type'] == 'C' ? $value['amount'] : '';
				$row[] = $value['type'] == 'D' ? $value['amount'] : '';
				$row[] = $value['balance'] < 0 ? '-': '+';
				$row[] = number_format(abs($value['balance']),2);
				$data[] = $row;
			}
			$row2 = ['', '', '', '<h6><b>Total</b></h6>', '<h6><b>'.$sum_decode[0]['TotalCredit'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalDebit'].'</b></h6>', '', ''];
			$data[] = $row2;
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== Daily Seet View ============*/
    public function dailySeetStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_daily_seet';
		$data['breadcrumb'] = [['daily-seet-statement', 'Statement'],['daily-seet-statement','Daily Seet']];
		$username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('statement.daily_seet')->withData($data);
		else
        return abort(404);
    }

	/*=========== Daily Seet Table ============*/
	public function dailySeetStatementData (Request $request){
		$exp_date = explode('/', $request->datepicker);
		$startDate = trim($exp_date[2]).'-'.trim($exp_date[1]).'-'.trim($exp_date[0]) .' 00:00:00';
		$endDate = trim($exp_date[2]).'-'.trim($exp_date[1]).'-'.trim($exp_date[0]).' 23:59:59';

		$whereraw = '';
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$whereraw = " AND (UPPER(tbl_ledger.jewellers_name) LIKE '%".$search."%' OR UPPER(tbl_ledger.propriter_name) LIKE '%".$search."%' OR tbl_received.id LIKE '%".$search."%' OR UPPER(tbl_received.customer_name) LIKE '%".$search."%' OR UPPER(tbl_received.token_no) LIKE '%".$search."%')";
		}

		// $limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";

		$qry = "SELECT tbl_received.*, tbl_ledger.jewellers_name, tbl_ledger.propriter_name FROM tbl_received LEFT JOIN tbl_ledger ON tbl_received.fk_ledger_id = tbl_ledger.id WHERE tbl_received.delivery_time BETWEEN '".$startDate."' AND '".$endDate."' $whereraw";

		$total_row = DB::select("SELECT COUNT(*) as total_record FROM tbl_received LEFT JOIN tbl_ledger ON tbl_received.fk_ledger_id=tbl_ledger.id WHERE tbl_received.delivery_time BETWEEN '".$startDate."' AND '".$endDate."' $whereraw");

		$sum_table = DB::select("SELECT SUM(total) TotalTotal, SUM(paid) TotalPaid FROM tbl_received WHERE is_delete = 'N' AND delivery_time BETWEEN '".$startDate."' AND '".$endDate."' ");
		$sum_decode = json_decode(json_encode($sum_table,true),true);

		$j_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($j_decode) > 0){
			$total_data = $j_decode[0]['total_record'];
		}
		$GetData = DB::select($qry);

		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			$total_due = 0;
			$total_discount = 0;
			$total_ornament = 0;
			$total_card = 0;
			$total_photo = 0;
			foreach($decode as $value){
				$due = $value['total'] - $value['paid'];
				$total_due = ($due > 10 && $value['is_delete']=='N') ? ($total_due + $due) : $total_due;
				$total_ornament = ($value['is_delete']=='N') ? ($total_ornament + $value['hallmark_piece']) : $total_ornament;
				$total_card = ($value['is_delete']=='N') ? ($total_card + $value['card_piece']) : $total_card;
				$total_photo = ($value['is_delete']=='N') ? ($total_photo + $value['photo_piece']) : $total_photo;
				$total_discount += $value['discount'];
				$row = array();
				$row[] = $value['id'];
				// $row[] = $value['token_no'];
				$row[] = $value['fk_ledger_id'] == 0 ? $value['customer_name'] : $value['jewellers_name'];
				// $row[] = $value['fk_ledger_id'] == 0 ?  $value['customer_name'] : $value['propriter_name'];
				$row[] = ($value['hallmark_weight']==0) ? (number_format(($value['card_weight'] + $value['photo_weight']),3)) : $value['hallmark_weight'];
				$row[] = $value['delivery_weight'];
				$row[] = ($value['hallmark_piece']==0) ? '-' : $value['hallmark_piece'];
				$row[] = ($value['hallmark_piece']==0) ? '-' : $value['hallmark_rate'].' ('.$value['hallmark_type'].')';
				// $row[] = $value['card_piece'] == 0 ? '-' : $value['card_piece'];
				$row[] = $value['card_piece'] == 0 ? '-' : $value['card_rate'].'/'.$value['card_piece'];
				// $row[] = $value['photo_piece'] == 0 ? '-' : $value['photo_piece'];
				$row[] = $value['photo_piece'] == 0 ? '-' : $value['photo_rate'].'/'.$value['photo_piece'];
				$row[] = date("d/m/Y, h:i A", strtotime($value['received_time']));
				$row[] = date("d/m/Y, h:i A", strtotime($value['delivery_time']));
				$row[] = $value['total'];
				$row[] = ($due > 10 && $value['is_delete']=='N') ? number_format($due, 2) : '-';
				$row[] = ($value['discount'] == 0 || $value['is_delete']=='Y') ? '-' : $value['discount'];
				$row[] = ($value['is_delete']=='Y') ? 'Deleted' : $value['paid'];
				$data[] = $row;
			}
			$row2 = ['', '', '', '<h6><b>Total</b></h6>', '<h6><b>'.$total_ornament.'</b></h6>', '', '<h6><b>'.$total_card.'</b></h6>', '<h6><b>'.$total_photo.'</b></h6>', '', '', '<h6><b>'.$sum_decode[0]['TotalTotal'].'</b></h6>', '<h6><b>'.number_format($total_due, 2).'</b></h6>', '<h6><b>'.number_format($total_discount,2).'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalPaid'].'</b></h6>'];
			$data[] = $row2;
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== Card In Out View ============*/
    public function cardInOutStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_card_in_out';
		$data['breadcrumb'] = [['card-in-out-statement', 'Statement'],['card-in-out-statement','Card In Out']];
		$data['ledger'] = Ledger::where('is_active','A')->where('is_delete','N')->get()->toArray();
		$username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('statement.card_in_out')->withData($data);
		else
        return abort(404);
    }

	/*=========== Card In Out Table ============*/
	public function cardInOutStatementData (Request $request){
		$ledger_id = $request->ledger_id;

		$daterange = explode('-', $request->daterange);

		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]) .' 00:00:00';

		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]).' 23:59:59';

		$from_qry = " FROM tbl_stock_update LEFT JOIN tbl_ledger ON tbl_stock_update.fk_ledger_id = tbl_ledger.id LEFT JOIN tbl_received ON tbl_stock_update.fk_received_id = tbl_received.id";
		$where_qry = " WHERE tbl_stock_update.created_date_time BETWEEN '".$startDate."' AND '".$endDate."' AND tbl_stock_update.stock_type = 'C'";
		$ledger_qry = '';
		$search_qry = '';
		if($ledger_id != ''){
			$ledger_qry = " AND tbl_stock_update.fk_ledger_id = '".$ledger_id."'";
		}
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$search_qry = " AND (UPPER(tbl_ledger.jewellers_name) LIKE '%".$search."%' OR UPPER(tbl_ledger.propriter_name) LIKE '%".$search."%' OR UPPER(tbl_received.customer_name) LIKE '%".$search."%')";
		}
		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		
		$qry = "SELECT tbl_stock_update.*, tbl_received.customer_name, tbl_received.card_weight, tbl_received.card_amount, tbl_ledger.jewellers_name, tbl_ledger.propriter_name $from_qry $where_qry $ledger_qry $search_qry $limitOffset";

		$sum_table = DB::select("SELECT SUM(CASE WHEN tbl_stock_update.type = 'I' THEN tbl_stock_update.piece ELSE 0 END) TotalIn, SUM(CASE WHEN tbl_stock_update.type = 'R' THEN tbl_stock_update.piece ELSE 0 END) TotalReject, SUM(CASE WHEN tbl_stock_update.type = 'S' THEN tbl_stock_update.piece ELSE 0 END) TotalSell $from_qry $where_qry $ledger_qry $search_qry");
		$sum_decode = json_decode(json_encode($sum_table,true),true);

		$total_row = DB::select("SELECT COUNT(*) as total_record $from_qry $where_qry $ledger_qry $search_qry");
		$total_row_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($total_row_decode) > 0){
			$total_data = $total_row_decode[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				$expdate = explode(' ', $value['created_date_time']);
				$date = date("d/m/Y", strtotime($expdate[0]));

				$row = array();
				$row[] = $date;
				$row[] = $value['jewellers_name'];
				$row[] = $value['fk_ledger_id'] == 0 ? $value['customer_name'] : $value['propriter_name'];
				$row[] = $value['card_weight'];
				$row[] = $value['card_amount'];
				$row[] = $value['type'] == 'I' ? $value['piece'] : '';
				$row[] = $value['type'] == 'S' ? $value['piece'] : '';
				$row[] = $value['type'] == 'R' ? $value['piece'] : '';
				$row[] = $value['balance'];
				$data[] = $row;
			}
			$row2 = ['', '', '', '', '<h6><b>Total</b></h6>', '<h6><b>'.$sum_decode[0]['TotalIn'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalSell'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalReject'].'</b></h6>',''];
			$data[] = $row2;
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== Rebons In Out View ============*/
    public function rebonsInOutStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_rebons_in_out';
		$data['breadcrumb'] = [['rebons-in-out-statement', 'Statement'],['rebons-in-out-statement','Rebons In Out']];
		$data['ledger'] = Ledger::where('is_active','A')->where('is_delete','N')->get()->toArray();
		$username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('statement.rebons_in_out')->withData($data);
		else
        return abort(404);
    }

	/*=========== Rebons In Out Table ============*/
	public function rebonsInOutStatementData (Request $request){
		$ledger_id = $request->ledger_id;

		$daterange = explode('-', $request->daterange);

		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]) .' 00:00:00';

		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]).' 23:59:59';

		$from_qry = " FROM tbl_stock_update LEFT JOIN tbl_ledger ON tbl_stock_update.fk_ledger_id = tbl_ledger.id LEFT JOIN tbl_received ON tbl_stock_update.fk_received_id = tbl_received.id";
		$where_qry = " WHERE tbl_stock_update.created_date_time BETWEEN '".$startDate."' AND '".$endDate."' AND tbl_stock_update.stock_type = 'R'";
		$ledger_qry = '';
		$search_qry = '';
		if($ledger_id != ''){
			$ledger_qry = " AND tbl_stock_update.fk_ledger_id = '".$ledger_id."'";
		}
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$search_qry = " AND (UPPER(tbl_ledger.jewellers_name) LIKE '%".$search."%' OR UPPER(tbl_ledger.propriter_name) LIKE '%".$search."%' OR UPPER(tbl_received.customer_name) LIKE '%".$search."%')";
		}
		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		
		$qry = "SELECT tbl_stock_update.*, tbl_received.customer_name, tbl_received.card_weight, tbl_received.card_amount, tbl_ledger.jewellers_name, tbl_ledger.propriter_name $from_qry $where_qry $ledger_qry $search_qry $limitOffset";

		$sum_table = DB::select("SELECT SUM(CASE WHEN tbl_stock_update.type = 'I' THEN tbl_stock_update.piece ELSE 0 END) TotalIn, SUM(CASE WHEN tbl_stock_update.type = 'R' THEN tbl_stock_update.piece ELSE 0 END) TotalReject, SUM(CASE WHEN tbl_stock_update.type = 'S' THEN tbl_stock_update.piece ELSE 0 END) TotalSell $from_qry $where_qry $ledger_qry $search_qry");
		$sum_decode = json_decode(json_encode($sum_table,true),true);

		$total_row = DB::select("SELECT COUNT(*) as total_record $from_qry $where_qry $ledger_qry $search_qry");
		$total_row_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($total_row_decode) > 0){
			$total_data = $total_row_decode[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				$expdate = explode(' ', $value['created_date_time']);
				$date = date("d/m/Y", strtotime($expdate[0]));

				$row = array();
				$row[] = $date;
				$row[] = $value['jewellers_name'];
				$row[] = $value['fk_ledger_id'] == 0 ? $value['customer_name'] : $value['propriter_name'];
				$row[] = $value['card_weight'];
				$row[] = $value['card_amount'];
				$row[] = $value['type'] == 'I' ? $value['piece'] : '';
				$row[] = $value['type'] == 'S' ? $value['piece'] : '';
				$row[] = $value['type'] == 'R' ? $value['piece'] : '';
				$row[] = $value['balance'];
				$data[] = $row;
			}
			$row2 = ['', '', '', '', '<h6><b>Total</b></h6>', '<h6><b>'.$sum_decode[0]['TotalIn'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalSell'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalReject'].'</b></h6>',''];
			$data[] = $row2;
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== Photo In Out View ============*/
    public function photoInOutStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_photo_in_out';
		$data['breadcrumb'] = [['photo-in-out-statement', 'Statement'],['photo-in-out-statement','Photo In Out']];
		$data['ledger'] = Ledger::where('is_active','A')->where('is_delete','N')->get()->toArray();
		$username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('statement.photo_in_out')->withData($data);
		else
        return abort(404);
    }

	/*=========== Photo In Out Table ============*/
	public function photoInOutStatementData (Request $request){
		$ledger_id = $request->ledger_id;

		$daterange = explode('-', $request->daterange);

		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]) .' 00:00:00';

		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]).' 23:59:59';

		$from_qry = " FROM tbl_stock_update";
		$join_qry = " LEFT JOIN tbl_ledger ON tbl_stock_update.fk_ledger_id = tbl_ledger.id LEFT JOIN tbl_received ON tbl_stock_update.fk_received_id = tbl_received.id";
		$where_qry = " WHERE tbl_stock_update.created_date_time BETWEEN '".$startDate."' AND '".$endDate."' AND tbl_stock_update.stock_type = 'P'";
		$ledger_qry = '';
		$search_qry = '';
		if($ledger_id != ''){
			$ledger_qry = " AND tbl_stock_update.fk_ledger_id = '".$ledger_id."'";
		}
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$search_qry = " AND (UPPER(tbl_ledger.jewellers_name) LIKE '%".$search."%' OR UPPER(tbl_ledger.propriter_name) LIKE '%".$search."%' OR UPPER(tbl_received.customer_name) LIKE '%".$search."%')";
		}
		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		
		$qry = "SELECT tbl_stock_update.*, tbl_received.customer_name, tbl_received.photo_weight, tbl_received.photo_amount, tbl_ledger.jewellers_name, tbl_ledger.propriter_name $from_qry $join_qry $where_qry $ledger_qry $search_qry $limitOffset";

		$sum_table = DB::select("SELECT SUM(CASE WHEN type = 'I' THEN piece ELSE 0 END) TotalIn, SUM(CASE WHEN type = 'R' THEN piece ELSE 0 END) TotalReject, SUM(CASE WHEN type = 'S' THEN piece ELSE 0 END) TotalSell $from_qry $where_qry $ledger_qry $search_qry");
		$sum_decode = json_decode(json_encode($sum_table,true),true);

		$total_row = DB::select("SELECT COUNT(*) as total_record $from_qry $where_qry $ledger_qry $search_qry");
		$total_row_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($total_row_decode) > 0){
			$total_data = $total_row_decode[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				$expdate = explode(' ', $value['created_date_time']);
				$date = date("d/m/Y", strtotime($expdate[0]));

				$row = array();
				$row[] = $date;
				$row[] = $value['jewellers_name'];
				$row[] = $value['fk_ledger_id'] == 0 ? $value['customer_name'] : $value['propriter_name'];
				$row[] = $value['photo_weight'];
				$row[] = $value['photo_amount'];
				$row[] = $value['type'] == 'I' ? $value['piece'] : '';
				$row[] = $value['type'] == 'S' ? $value['piece'] : '';
				$row[] = $value['type'] == 'R' ? $value['piece'] : '';
				$row[] = $value['balance'];
				$data[] = $row;
			}
			$row2 = ['', '', '', '', '<h6><b>Total</b></h6>', '<h6><b>'.$sum_decode[0]['TotalIn'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalSell'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalReject'].'</b></h6>',''];
			$data[] = $row2;
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== Absent Party View ============*/
    public function absentPartyStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_absent_party';
		$data['breadcrumb'] = [['absent-party-statement', 'Statement'],['absent-party-statement','Absent Party']];
		$username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('statement.absent_party')->withData($data);
		else
        return abort(404);
    }

	/*=========== Absent Party Table ============*/
	public function absentPartyStatementData (Request $request){
		$from_qry = " FROM tbl_ledger";
		$where_qry = " WHERE is_active = 'A' AND is_delete = 'N'";
	
		$search_qry = '';
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$search_qry = " AND (UPPER(jewellers_name) LIKE '%".$search."%' OR UPPER(propriter_name) LIKE '%".$search."%' OR ph_no LIKE '%".$search."%')";
		}
		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		
		$qry = "SELECT jewellers_name, propriter_name, ph_no, last_transaction_time $from_qry $where_qry $search_qry ORDER BY last_transaction_time ASC $limitOffset";

		$total_row = DB::select("SELECT COUNT(*) as total_record $from_qry $where_qry $search_qry");
		$total_row_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($total_row_decode) > 0){
			$total_data = $total_row_decode[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				$row = array();
				$row[] = $value['jewellers_name'];
				$row[] = $value['propriter_name'];
				$row[] = $value['ph_no'];
				$row[] = date("d/m/Y, h:i A", strtotime($value['last_transaction_time']));
				$data[] = $row;
			}
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== All Party Due View ============*/
    public function allPartyDueStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_all_party_due';
		$data['breadcrumb'] = [['all-party-due-statement', 'Statement'],['all-party-due-statement','All Party Due']];
		$data['ledger'] = Ledger::where('is_active','A')->where('is_delete','N')->get()->toArray();
		$username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('statement.all_party_due')->withData($data);
		else
        return abort(404);
    }

	/*=========== All Party Due Table ============*/
	public function allPartyDueStatementData (Request $request){
		$ledger_id = $request->ledger_id;

		$daterange = explode('-', $request->daterange);

		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]) .' 00:00:00';

		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]).' 23:59:59';

		$columns = array('updated_balance_time', 'jewellers_name','propriter_name','balance','balance');

		$from_qry = " FROM tbl_ledger";

		$where_qry = " WHERE updated_balance_time BETWEEN '".$startDate."' AND '".$endDate."' AND balance <> 0";

		$ledger_qry = '';
		if($ledger_id != ''){
			$ledger_qry = " AND id = '".$ledger_id."'";
		}

		$search_qry = '';
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$search_qry = " AND (UPPER(tbl_ledger.jewellers_name) LIKE '%".$search."%' OR UPPER(tbl_ledger.propriter_name) LIKE '%".$search."%')";
		}
		// $limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		$orderBy = "ORDER BY ". $columns[$request->input('order.0.column')] ." " .$request->input('order.0.dir');

		$qry = "SELECT jewellers_name, propriter_name, balance, updated_balance_time $from_qry $where_qry $ledger_qry $search_qry $orderBy";

		$total_row = DB::select("SELECT COUNT(*) as total_record $from_qry $where_qry $ledger_qry $search_qry");
		$total_row_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($total_row_decode) > 0){
			$total_data = $total_row_decode[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		$total_due = 0;
		$total_deposit = 0;
		if(!empty($decode)){
			foreach($decode as $value){
				$expdate = explode(' ', $value['updated_balance_time']);
				$date = date("d/m/Y", strtotime($expdate[0]));
				$balance = $value['balance'];
				$total_due = $balance < 0 ? $total_due - $balance : $total_due;
				$total_deposit = $balance > 0 ? $total_deposit + $balance : $total_deposit;
				$row = array();
				$row[] = $date;
				$row[] = $value['jewellers_name'];
				$row[] = $value['propriter_name'];
				$row[] = $balance < 0 ? number_format(abs($balance),2) : '';
				$row[] = $balance > 0 ? $balance : '';
				$data[] = $row;
			}
			$row2 = ['', '', '<h6><b>Total</b></h6>', '<h6><b>'.number_format($total_due,2).'</b></h6>', '<h6><b>'.number_format($total_deposit,2).'</b></h6>'];
			$data[] = $row2;
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== Monthly Working Sheet View ============*/
    public function monthlyWorkingSheetStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_monthly_working_sheet';
		$data['breadcrumb'] = [['monthly-working-sheet-statement', 'Statement'],['monthly-working-sheet-statement','Monthly Working Sheet']];
		$data['year_month'] = date('Y-m');
		$username = Session::get('username');
		if($username=='owner')
        return view('statement.monthly_working_sheet')->withData($data);
		else
        return abort(404);
    }

	/*=========== Monthly Working Sheet Table ============*/
	public function monthlyWorkingSheetStatementData (Request $request){
		$month_year = $request->month_year;

		$tbl_received_qry = "SELECT SUM(total) as work_amount, SUM(paid) as paid_amount, SUM(discount) as discount_amount, DATE_FORMAT(delivery_time, '%Y-%m-%d') as date FROM `tbl_received` WHERE delivery_time is not null AND delivery_time between '".$month_year.'-01 00:00:00'."' AND '".$month_year.'-31 23:59:59'."' GROUP BY DATE_FORMAT(delivery_time, '%Y-%m-%d')";

		$tbl_expenses_qry = "SELECT SUM(amount) as expenses_amount, GROUP_CONCAT(CONCAT(remarks, ' ', substring_index(amount,'.',1)) SEPARATOR ' + ') as expenses, DATE_FORMAT(created_date_time, '%Y-%m-%d') as date FROM `tbl_expenses` WHERE created_date_time between '".$month_year.'-01 00:00:00'."' AND '".$month_year.'-31 23:59:59'."' GROUP BY DATE_FORMAT(created_date_time, '%Y-%m-%d')";

		// $total_data = 0;

		$tbl_received_get_data = DB::select($tbl_received_qry);
		$received_array = json_decode(json_encode($tbl_received_get_data , true), true);
		$tbl_expenses_get_data = DB::select($tbl_expenses_qry);
		$expenses_array= json_decode(json_encode($tbl_expenses_get_data , true), true);
		$data = [];
		$total_work_amount = 0;
		$total_due_amount = 0;
		$total_discount_amount = 0;
		$total_paid_amount = 0;
		$total_expenses_amount = 0;
		$balance = 0;

		// print_r($expenses_array);die;
		if((!empty($received_array)) || (!empty($expenses_array))){
			for($d = 1; $d<=31; $d++){
				$d = ($d<10) ? '0'.$d : $d;
				$date_val = $month_year.'-'.$d;
				// print($date_val);
				$received_key = array_search($date_val, array_column($received_array, 'date'));
				$expenses_key = array_search($date_val, array_column($expenses_array, 'date'));
				if($received_key != '' || $expenses_key != ''){
					$row = array();
					$row[] = date("d/m/Y", strtotime($date_val));
					if($received_key != ''){
						$work_amount = $received_array[$received_key]['work_amount'];
						$paid_amount = $received_array[$received_key]['paid_amount'];
						$discount_amount = $received_array[$received_key]['discount_amount'];
						$due_amount = $work_amount - $discount_amount - $paid_amount;
						$total_work_amount += $work_amount;
						$total_due_amount += $due_amount;
						$total_discount_amount += $discount_amount;
						$total_paid_amount += $paid_amount;
						$row[] = $work_amount;
						$row[] = number_format($due_amount,2);
						$row[] = $discount_amount;
						$row[] = $paid_amount;
					}else{
						$paid_amount = 0;
						$row[] = '';
						$row[] = '';
						$row[] = '';
						$row[] = '';
					}
					if($expenses_key != ''){
						$expenses_amount = $expenses_array[$expenses_key]['expenses_amount'];
						$total_expenses_amount += $expenses_amount;
						$row[] = $expenses_array[$expenses_key]['expenses'];
						$row[] = $expenses_amount;
					}else{
						$expenses_amount = 0;
						$row[] = '';
						$row[] = '-';
					}
					$remaining_amount = $paid_amount - $expenses_amount;
					$balance += $remaining_amount;
					$row[] = number_format($remaining_amount,2);
					$row[] = number_format($balance,2);
					$data[] = $row;
				}
			}
			$row2 = ['<h6><b>Total</b></h6>', '<h6><b>'.number_format($total_work_amount,2).'</b></h6>', '<h6><b>'.number_format($total_due_amount,2).'</b></h6>', '<h6><b>'.number_format($total_discount_amount,2).'</b></h6>', '<h6><b>'.number_format($total_paid_amount,2).'</b></h6>', '', '<h6><b>'.number_format($total_expenses_amount,2).'</b></h6>', '', ''];
			$data[] = $row2;
		}
		$json_data = array(
			// "draw" => $request->input('draw'),
			// "recordsTotal" => $total_data,
			// "recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

	/*=========== Clear All Data============*/
    public function clearAllData(){
		$time = date('Y-m-d H:i:s');
		Ledger::query()->update(['balance'=> 0, 'updated_balance_time'=> $time, 'last_transaction_time'=>$time]);
		Stock::query()->update(['card'=> 0, 'photo'=> 0, 'rebons'=> 0, 'paid_amount'=> 0, 'customer_fund'=> 0, 'updated_date_time'=> $time]);
		CustomerTransection::getQuery()->delete();
		Expenses::getQuery()->delete();
		OwnFund::getQuery()->delete();
		Received::getQuery()->delete();
		ReceivedCard::getQuery()->delete();
		ReceivedHallmark::getQuery()->delete();
		ReceivedPhoto::getQuery()->delete();
		StockUpdate::getQuery()->delete();
		DB::statement("ALTER TABLE tbl_customer_transection AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_expenses AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_own_fund AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received_card AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received_hallmark AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received_photo AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_stock_update AUTO_INCREMENT = 1");
		$return = ['key' => 'S', 'msg' => 'Clear All Data Successfully.'];
        return $return;
    }

	/*=========== Clear Data============*/
    public function clearData(){
		Expenses::getQuery()->delete();
		OwnFund::getQuery()->delete();
		Received::getQuery()->delete();
		ReceivedCard::getQuery()->delete();
		ReceivedHallmark::getQuery()->delete();
		ReceivedPhoto::getQuery()->delete();
		StockUpdate::getQuery()->delete();
		DB::statement("ALTER TABLE tbl_expenses AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_own_fund AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received_card AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received_hallmark AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_received_photo AUTO_INCREMENT = 1");
		DB::statement("ALTER TABLE tbl_stock_update AUTO_INCREMENT = 1");
		$return = ['key' => 'S', 'msg' => 'Clear All Data Successfully.'];
        return $return;
    }

	/*=========== Own Fund View ============*/
    public function ownFundStatement(){
        $data['main_menu'] = 'mnu_satement';
		$data['sub_menu'] = 'mnu_own_fund_statement';
		$data['breadcrumb'] = [['own-fund-statement', 'Statement'],['own-fund-statement','Own Fund']];
		$username = Session::get('username');
		if($username=='owner' || $username=='manager')
        return view('statement.own_fund')->withData($data);
		else
        return abort(404);
    }

	/*=========== Own Fund Table ============*/
	public function ownFundStatementData (Request $request){
		$paid_amount_checked = $request->paid_amount;
		$customer_fund_checked = $request->customer_fund;

		$daterange = explode('-', $request->daterange);
		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]) .' 00:00:00';

		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]).' 23:59:59';
		$from_qry = " FROM tbl_own_fund";
		$where_qry = " WHERE created_date_time BETWEEN '".$startDate."' AND '".$endDate."'";

		if($paid_amount_checked == 'Y' && $customer_fund_checked == 'N'){
			$checked_qry = " AND type = 'P'";
		}elseif($paid_amount_checked == 'N' && $customer_fund_checked == 'Y'){
			$checked_qry = " AND type = 'C'";
		}elseif($paid_amount_checked == 'N' && $customer_fund_checked == 'N'){
			$checked_qry = " AND type = 'N'";
		}else{
			$checked_qry = "";
		}

		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		
		$qry = "SELECT * $from_qry $where_qry $checked_qry $limitOffset";

		$sum_table = DB::select("SELECT SUM(CASE WHEN type = 'P' THEN amount ELSE 0 END) TotalPaid, SUM(CASE WHEN type = 'C' THEN amount ELSE 0 END) TotalCstmFund $from_qry $where_qry $checked_qry");
		$sum_decode = json_decode(json_encode($sum_table,true),true);

		$total_row = DB::select("SELECT COUNT(*) as total_record $from_qry $where_qry $checked_qry");
		$total_row_decode = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($total_row_decode) > 0){
			$total_data = $total_row_decode[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				$expdate = explode(' ', $value['created_date_time']);
				$date = date("d/m/Y", strtotime($expdate[0]));

				$row = array();
				$row[] = $date;
				$row[] = $value['remarks'];
				$row[] = $value['type'] == 'P' ? $value['amount'] : '';
				$row[] = $value['type'] == 'C' ? $value['amount'] : '';
				$row[] = $value['updated_balance'];
				$data[] = $row;
			}
			$row2 = ['', '<h6><b>Total</b></h6>', '<h6><b>'.$sum_decode[0]['TotalPaid'].'</b></h6>', '<h6><b>'.$sum_decode[0]['TotalCstmFund'].'</b></h6>', ''];
			$data[] = $row2;
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}
}