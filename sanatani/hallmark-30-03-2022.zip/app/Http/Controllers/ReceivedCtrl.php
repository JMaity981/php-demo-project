<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Ledger;
use App\Models\Received;
use App\Models\ReceivedCard;
use App\Models\ReceivedPhoto;
use App\Models\ReceivedHallmark;
use App\Models\RateUpdate;
use DB;
use Session;


class ReceivedCtrl extends Controller
{
    public function received (){
		$data['main_menu'] = 'mnu_received';
		$data['sub_menu'] = '';
		$data['breadcrumb'] = [['received', 'Received']];
		$received_data = Received::select('id')->take(1)->orderBy('id', 'DESC')->get()->toArray();
		$data['sl_no'] = (!empty($received_data)) ? ($received_data[0]['id']+1) : 1;
		$data['ledger'] = Ledger::get()->where('is_active','A')->where('is_delete','N')->toArray();
		$username = Session::get('username');
		if($username=='received' || $username=='owner')
        return view('received.received')->withData($data);
        else
        return abort(404);
    }

	public function getLedgerData (Request $request){
		$ledger_id = $request->ledgerId;
        $data['ledger_details'] = Ledger::where('id',$ledger_id)->get()->toArray();
        return $data;
	}

	public function insertReceivedData (Request $request){
		$time = date('Y-m-d H:i:s');
		$ledger_id = $request->ledger_id;
		$rate_data = RateUpdate::take(1)->orderBy('created_date_time', 'DESC')->get()->toArray();
		$more_then = $rate_data[0]['more_then'];
		if($ledger_id != 0){
			$ledger_rate_data = Ledger::select('hallmarking_rate_h','hallmarking_rate_h_more','hallmarking_rate_o', 'card_rate', 'photo_rate')->where('id',$ledger_id)->get()->toArray();
			$hallmarking_rate_h = $ledger_rate_data[0]['hallmarking_rate_h'];
			$hallmarking_rate_h_more = $ledger_rate_data[0]['hallmarking_rate_h_more'];
			$hallmarking_rate_o = $ledger_rate_data[0]['hallmarking_rate_o'];
			$card_rate = $ledger_rate_data[0]['card_rate'];
			$photo_rate = $ledger_rate_data[0]['photo_rate'];
		}else{
			$hallmarking_rate_h = $rate_data[0]['hallmarking_h'];
			$hallmarking_rate_h_more = $rate_data[0]['hallmarking_h_more'];
			$hallmarking_rate_o = $rate_data[0]['hallmarking_o'];
			$card_rate = $rate_data[0]['card'];
			$photo_rate = $rate_data[0]['photo'];
		}
		// $h_rate = $request->h_rate;
		// $h_rate_4 = $request->h_rate_4;
		// $o_rate = $request->o_rate;
		// $card_rate = $request->card_rate;
		// $photo_rate = $request->photo_rate;
		$full_total_amount = 0;

		//INSERT Received
		$received_insert_array = array(
			"fk_ledger_id" => $ledger_id,
			"customer_name" => $request->customer_name,
			"token_no" => $request->token_no,
			"card_rate" => $card_rate,
			"photo_rate" => $photo_rate,
			"received_time" => $time
		);  
		$received_id = Received::insertGetId($received_insert_array);

		//Insert Received Hallmark
		$hallmark_piece = $request->piece;
		$hallmark_type = $request->type;
		$hallmark_weight = $request->weight;
		if($hallmark_type!= '' && $hallmark_weight != '' && $hallmark_piece != '' && $request->purity != ''){	
			$received_hallmark_array = array(
				"fk_received_id" => $received_id,
				"type" => $hallmark_type,
				"weight" => $hallmark_weight,
				"piece" => $hallmark_piece,
				"purity" => $request->purity,
				"remarks" => $request->remarks
			);  
			$insert_received_hallmark = ReceivedHallmark::insertGetId($received_hallmark_array);
			$hallmark_rate = ($hallmark_type=='H') ? (($hallmark_piece > $more_then) ? $hallmarking_rate_h_more : ($hallmarking_rate_h/$hallmark_piece)) : $hallmarking_rate_o;
			$total_hallmark_amount = $hallmark_piece * $hallmark_rate;
			$full_total_amount += $total_hallmark_amount;
		}else{
			$hallmark_type = '';
			$hallmark_rate = 0;
			$hallmark_piece = 0;
			$total_hallmark_amount = 0;
			$hallmark_weight = 0;
		}

		//Insert Received Card
		$total_card_weight = 0;
		$total_card_piece = 0;
		$total_card_amount = 0;
		if($request->card_view == 'S'){
			$card_array = [];
			foreach ($request['card_weight'] as $key => $card_weight) {
				$card_piece = $request['card_piece'][$key];
				$card_array[] = [
					'fk_received_id' => $received_id,
					'weight' => $card_weight,
					'piece' => $card_piece,
					'remarks' => $request['card_remarks'][$key]
				];
				$total_card_weight += $card_weight;
				$total_card_piece += $card_piece;
			}
			$insert_received_card = ReceivedCard::insert($card_array);
			$total_card_amount = $total_card_piece * $card_rate;
			$full_total_amount += $total_card_amount;
		}

		//Insert Received Photo
		$total_photo_weight = 0;
		$total_photo_piece = 0;
		$total_photo_amount = 0;
		if($request->photo_view == 'S'){
			$photo_array = [];
			foreach ($request['photo_weight'] as $key => $photo_weight) {
				$photo_piece = $request['photo_piece'][$key];
				$photo_array[] = [
					'fk_received_id' => $received_id,
					'weight' => $photo_weight,
					'piece' => $photo_piece,
					'remarks' => $request['photo_remarks'][$key]
				];
				$total_photo_weight += $photo_weight;
				$total_photo_piece += $photo_piece;
			}
			$insert_received_card = ReceivedPhoto::insert($photo_array);
			$total_photo_amount = $total_photo_piece * $photo_rate;
			$full_total_amount += $total_photo_amount;
		}

		//Update Received
		$received_update_array = array(
			"total" => $full_total_amount,
			"hallmark_type"=> $hallmark_type,
			"hallmark_rate" => $hallmark_rate,
			"hallmark_weight" => $hallmark_weight,
			"hallmark_piece" => $hallmark_piece,
			"hallmark_amount" => $total_hallmark_amount,
			"card_weight" => $total_card_weight,
			"card_piece" => $total_card_piece,
			"card_amount" => $total_card_amount,
			"photo_weight" => $total_photo_weight,
			"photo_piece" => $total_photo_piece,
			"photo_amount" => $total_photo_amount
		); 
		$received_update = Received::where('id',$received_id)->update($received_update_array);

		$return = ($received_id && $received_update) ? ['key' => 'S', 'msg' => 'Data Inserted Successfully.', 'sl_no' => $received_id] : ['key' => 'E', 'msg' => 'Data Can Not Inserted Successfully.'];
        return $return;
	}

	/*public function getRateData (){
		$data = RateUpdate::take(1)->orderBy('created_date_time', 'DESC')->get()->toArray();
		return $data;
	}*/
}
