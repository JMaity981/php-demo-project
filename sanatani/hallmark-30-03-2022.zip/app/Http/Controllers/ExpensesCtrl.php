<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Expenses;
use App\Models\Stock;

use DB;
use Response;
use Session;

class ExpensesCtrl extends Controller{
    public function expenses (){
        $data['main_menu'] = 'mnu_expenses';
        $data['sub_menu'] = '';
        $data['breadcrumb'] = [['expenses', 'Expenses']];

        $date_explode = explode("-",date('Y-m-d'));
        $start_date = $date_explode[0].'-'.$date_explode[1].'-1 00:00:00';
        $end_date = $date_explode[0].'-'.$date_explode[1].'-31 23:59:59';
        $sum_query = DB::select("SELECT SUM(amount) FROM tbl_expenses WHERE created_date_time BETWEEN '".$start_date."' AND '".$end_date."'");
		$sum_decode = json_decode(json_encode($sum_query,true),true);
        $data['monthly_expenses'] = $sum_decode[0]['SUM(amount)'];
        $username = Session::get('username');
        if($username=='received' || $username=='owner')
        return view('expenses.expenses')->withData($data);
        else
        return abort(404);
    }

    public function expensesSubmit(Request $request){
        $time = date('Y-m-d H:i:s');
        $remarks = $request->remarks;
        $amount = $request->amount;

        $stock_data = Stock::select('paid_amount')->get()->toArray();
        $paid_amount = $stock_data[0]['paid_amount'] - $amount;
        if($paid_amount >= 0){
            $insert_array = array(
                "amount" => $amount,
                "remarks" => $remarks,
                "created_date_time" => $time
            );  
            $insert = Expenses::insertGetId($insert_array);
            $update_stock = Stock::query()->update(['paid_amount'=> $paid_amount]);

            $date_explode = explode("-",date('Y-m-d'));
            $start_date = $date_explode[0].'-'.$date_explode[1].'-1 00:00:00';
            $end_date = $date_explode[0].'-'.$date_explode[1].'-31 23:59:59';
            $sum_query = DB::select("SELECT SUM(amount) FROM tbl_expenses WHERE created_date_time BETWEEN '".$start_date."' AND '".$end_date."'");
            $sum_decode = json_decode(json_encode($sum_query,true),true);

            $return = ($insert && $update_stock) ? ['key' => 'S', 'msg' => 'Inserted Successfully.','monthly_expenses' => $sum_decode[0]['SUM(amount)']] : ['key' => 'E', 'msg' => 'Inserted Un-successfully.'];
        }else{
            $return = ['key' => 'E', 'msg' => 'Non Sufficient Funds'];
        }
        return $return;
    }

	public function expensesTblData (Request $request){
		$today = date('Y-m-d');
		$yesterday = date('Y-m-d',strtotime("-1 days"));
		$startDate = $yesterday.' 00:00:00';
		$endDate = $today.' 23:59:59';
		
		$qry = "SELECT * FROM tbl_expenses  WHERE created_date_time BETWEEN '".$startDate."' AND '".$endDate."' ORDER BY created_date_time DESC";

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				// $expdate = explode(' ', $value['created_date_time']);
				$date = date("d/m/Y, h:i A", strtotime($value['created_date_time']));

				$row = array();
				$row[] = $date;
				$row[] = $value['remarks'];
				$row[] = $value['amount'];
				$data[] = $row;
			}
		}

		$json_data = array(
			"data" => $data
		);
		return Response::json($json_data);
	}
}