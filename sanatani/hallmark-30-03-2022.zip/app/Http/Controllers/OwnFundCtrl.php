<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\OwnFund;
use App\Models\Stock;

use DB;
use Response;
use Session;

class OwnFundCtrl extends Controller{
    public function ownFund (){
        $data['main_menu'] = 'mnu_own_fund';
        $data['sub_menu'] = '';
        $data['breadcrumb'] = [['own-fund', 'Own Fund']];
        $username = Session::get('username');
		if($username=='received' || $username=='manager' || $username=='owner')
        return view('own_fund.own_fund')->withData($data);
        else
        return abort(404);
    }

    public function ownFundSubmit(Request $request){
        $time = date('Y-m-d H:i:s');
        $type = $request->amount_type;
        $amount = $request->amount;
        $remarks = $request->remarks;
        
        $stock_data = Stock::select('paid_amount','customer_fund')->get()->toArray();
        $update_stock = ($type == 'P') ? ($stock_data[0]['paid_amount'] - $amount) : ($stock_data[0]['customer_fund'] - $amount);

        if($update_stock >= 0){
            $insert_array = array(
                "type" => $type,
                "amount" => $amount,
                "remarks" => $remarks,
                "updated_balance" => $update_stock,
                "created_date_time" => $time
            );  
            $insert = OwnFund::insertGetId($insert_array);
            $update = ($type == 'P') ? (Stock::query()->update(['paid_amount'=> $update_stock])) : (Stock::query()->update(['customer_fund'=> $update_stock]));
            $return = ($insert && $update) ? ['key' => 'S', 'msg' => 'Inserted Successfully.'] : ['key' => 'E', 'msg' => 'Inserted Un-successfully.'];
        }else{
            $return = ['key' => 'E', 'msg' => 'Non Sufficient Funds'];
        }
        return $return;
    }
}