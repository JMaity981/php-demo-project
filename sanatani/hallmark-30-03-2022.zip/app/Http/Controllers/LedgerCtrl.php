<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Ledger;
use App\Models\RateUpdate;

use DB;
use Response;
use Session;

class LedgerCtrl extends Controller
{
    public function ledger (){
		$data['main_menu'] = 'mnu_ledger';
		$data['sub_menu'] = '';
		$data['breadcrumb'] = [['ledger', 'Ledger']];
		$username = Session::get('username');
		if($username=='xrf' || $username=='lager' || $username=='card')
        return abort(404);
        else
        return view('ledger.ledger')->withData($data);
    }
	/*---------- User Registration -----------*/
	public function addLager (Request $request){
		//print_r($request->all());die;
		$updateid = $request->hidden_userid;
		$hiddenmbno = $request->hidden_mb_no;
		$mobilenocount = Ledger::where('ph_no',$request->ph_no)->count();
		
		//image upload
		/*$customer_photo = '';
		$imagepath = storage_path('userimage');
		if($request->has('user_photo')){
			$file = $request->file('user_photo');
			$extention = $file->getClientOriginalExtension();
			if($extention == 'jpg' || $extention == 'jpeg' || $extention == 'png'){
				$customer_photo = rand(200,800).'.'.$extention;
				$file->move($imagepath, $customer_photo);
			}else{
				$return['key'] = 'E';
				$return['msg'] = 'You can upload only .jpg , .jpeg , .png file';
				return $return;
			}
		}*/
		
		if($updateid == ''){
			//get Rate Data
			$rate_data = RateUpdate::take(1)->orderBy('created_date_time', 'DESC')->get()->toArray();
			$hallmarking_rate_h = (!empty($rate_data)) ? $rate_data[0]['hallmarking_h'] : 0;
			$hallmarking_rate_h_more = (!empty($rate_data)) ? $rate_data[0]['hallmarking_h_more'] : 0;
			$hallmarking_rate_o = (!empty($rate_data)) ? $rate_data[0]['hallmarking_o'] : 0;
			$card_rate = (!empty($rate_data)) ? $rate_data[0]['card'] : 0;
			$photo_rate =(!empty($rate_data)) ? $rate_data[0]['photo'] : 0;
			$userRegArr = [
				'jewellers_name' 	     => $request->jewellers_name,
				'propriter_name'	     => $request->propriter_name,
				'ph_no' 			     => $request->ph_no,
				'lc_no' 			     => $request->lc_no,
				// 'proprietor_image'	     => $customer_photo,
				'gst_no' 			     => $request->gst_no,
				'address' 			     => $request->address,
				'logo' 				     => $request->logo,
				'hallmarking_rate_h'     => $hallmarking_rate_h,
				'hallmarking_rate_h_more'=>	$hallmarking_rate_h_more,
				'hallmarking_rate_o'     => $hallmarking_rate_o,
				'card_rate'              => $card_rate,
				'photo_rate'             => $photo_rate,
				'balance'        	     => 0,
				'is_active' 		     => 'A',
				'is_delete' 		     => 'N',
				'created_date_time'      => date('Y-m-d H:i:s')
			];
			if($mobilenocount == 0){
				$adduser = Ledger::insert($userRegArr);
				$return['key'] = 'S';
				$return['msg'] = 'Customer successfully added.';
			}else{
				$return['key'] = 'E';
				$return['msg'] = 'Phone no already exist.';
			}
			
		}else{
			/*if(!$request->has('user_photo')){
				$customer_photo = $request->hidden_file_name;
			}else{
				unlink("storage/userimage/".$request->hidden_file_name);
			}*/
			$userUpdateArr = [
				'jewellers_name' 	=> $request->jewellers_name,
				'propriter_name'	=> $request->propriter_name,
				'ph_no' 			=> $request->ph_no,
				'lc_no' 			=> $request->lc_no,
				// 'proprietor_image'	=> $customer_photo,
				'gst_no' 			=> $request->gst_no,
				'address' 			=> $request->address,
				'logo' 				=> $request->logo,
				'updated_date_time' => date('Y-m-d H:i:s')
			];
			if($request->hidden_mb_no != $request->ph_no){
				if($mobilenocount == 0){
					$updateuser = Ledger::where('id', $updateid)->update($userUpdateArr);
					$return['key'] = 'S';
					$return['msg'] = 'Value successfully updated.';
				}else{
					$return['key'] = 'E';
					$return['msg'] = 'Phone no already exist.';
				}
			}else{
				$updateuser = Ledger::where('id', $updateid)->update($userUpdateArr);
				$return['key'] = 'S';
				$return['msg'] = 'Value successfully updated.';
			}
			
		}
		return $return;
	}
	/*------------- User Registration data-table ------------*/
	public function userregistrationAjaxTbl (Request $request){
		// print_r($request->all());die;
		$columns = array('jewellers_name','propriter_name','ph_no','lc_no', 'gst_no','address','logo');
		$table_name = 'tbl_ledger';
		$where = "WHERE is_delete = 'N'";
		$data_qury = "SELECT * FROM $table_name $where";
		$count_qury = "SELECT COUNT(id) FROM $table_name $where";
		
		if(!empty($request->input('search.value'))){
			$search_value = strtoupper($request->input('search.value'));
			$search = "AND (UPPER(jewellers_name) LIKE '%".$search_value."%' OR UPPER(propriter_name) LIKE '%".$search_value."%' OR ph_no LIKE '%".$search_value."%' OR UPPER(lc_no) LIKE '%".$search_value."%' OR UPPER(gst_no) LIKE '%".$search_value."%' OR UPPER(address) LIKE '%".$search_value."%' OR UPPER(logo) LIKE '%".$search_value."%')";
			$data_qury = "$data_qury $search";
			$count_qury = "$count_qury $search";
		}
		$count = DB::select($count_qury);
		$j_decode = json_decode(json_encode($count,true),true);
		$total_data = 0;
		if(count($j_decode) > 0){
			$total_data = $j_decode[0]['COUNT(id)'];
		}
		$order = $columns[$request->input('order.0.column')];
		$dir = $request->input('order.0.dir');
		$offset = $request->input('start');
		$limit = $request->input('length');
		$final_qry = $data_qury." ORDER BY ".$order." ".$dir." LIMIT ".$limit." OFFSET ".$offset."";
		$GetData = DB::select($final_qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];
		if(!empty($decode)){
			foreach($decode as $value){
				//check active inactive
				switch ($value['is_active']) {
					case "A":
						$status = 'Active';
						$checked = 'checked';
						$color = 'primary';
					break;
					case "I":
						$status = 'Inactive';
						$checked = '';
						$color = 'danger';
					break;
				}				
				$row = array();
				$row[] = $value['jewellers_name'];
				$row[] = $value['propriter_name'];
				$row[] = $value['ph_no'];
				$row[] = $value['lc_no'];
				$row[] = $value['gst_no'];
				$row[] = $value['address'];
				$row[] = $value['logo'];
				$row[] = '<div class="custom-control custom-switch">
							<input type="checkbox" data-id="'.$value['id'].'" class="custom-control-input change-status" id="'.$value['id'].'" '.$checked.'>
							<label class="custom-control-label" for="'.$value['id'].'"></label>
							<span class="badge badge-'.$color.'">'.$status.'</span>
						</div>';
				$row[] = 
						'<button type="button" class="btn btn-primary btn-sm customer-update" data-id="'.$value['id'].'">
							<i class="fadeIn animated bx bx-pencil"></i>
						</button>
						<button type="button" class="btn btn-success btn-sm view-user-details" data-id="'.$value['id'].'">
							<i class="fadeIn animated bx bx-user"></i>
						</button>
						<button type="button" class="btn btn-danger btn-sm customer-delete" data-id="'.$value['id'].'">
							<i class="fadeIn animated bx bx-trash-alt"></i>
						</button>';
				$data[] = $row;
			}
		}
		$json_data = array(
			"draw" => intval($request->input('draw')),
			"recordsTotal" => intval($total_data),
			"recordsFiltered" => intval($total_data),
			"data" => $data
		);
		return Response::json($json_data);
	}
	/*------------- customer status change ---------------*/
	public function customerStatusChange (Request $request){
		$updateid = $request->id;
		$status = $request->status;
		$statusupdate = Ledger::where('id',$updateid)->update(['is_active'=> $status]);
		$return['key'] = 'S';
		$return['msg'] = 'Status has been updated.';
		return $return;
	}
	/*------------- customer delete ------------*/
	public function customerDelete (Request $request){
		$deleteid = $request->id;
		$balance = Ledger::where('id', $deleteid)->pluck('balance');
		if($balance[0] == 0){
			$userdelete = Ledger::where('id',$deleteid)->update(['is_delete' => 'Y']);
			$return['key'] = 'S';
			$return['msg'] = 'User has been deleted.';
		}else{
			$return['key'] = 'E';
			$return['msg'] = 'Balence Not Clear.';
		}
		return $return;
	}
	/*---------- customer update -------------*/
	public function customerUpdate (Request $request){
		$updateid = $request->id;
		$getupdatedata = Ledger::where('id',$updateid)->get()->toArray();
		return $getupdatedata;
	}
}
