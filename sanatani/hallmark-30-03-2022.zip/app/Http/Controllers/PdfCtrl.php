<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

use App\Models\Ledger;
use App\Models\Mlogin;
use App\Models\CustomerTransection;
use App\Models\Expenses;
use App\Models\OwnFund;
use App\Models\RateUpdate;
use App\Models\Received;
use App\Models\ReceivedCard;
use App\Models\ReceivedPhoto;
use App\Models\ReceivedHallmark;
use App\Models\Shop;
use App\Models\Stock;
use App\Models\StockUpdate;
use DB;
use PDF;
use File;
use DirectoryIterator;
use ZipArchive;
use \RecursiveIteratorIterator;

class PdfCtrl extends Controller{
	public function generateBillPdf (Request $request){
		//------------- get val qry ---------------//
		$sl_no = $request->slno;
		$get_shop_name = Shop::select('billing_name')->get()->toArray();
		$shop_name_billing = $get_shop_name[0]['billing_name'];
		$get_val = Received::leftjoin('tbl_ledger','tbl_received.fk_ledger_id','=','tbl_ledger.id')
						->select('tbl_received.*','tbl_ledger.jewellers_name','tbl_ledger.propriter_name','tbl_ledger.balance')
						->where('tbl_received.id',$sl_no)
						->get()->toArray();
		$expdate = explode(' ', $get_val[0]['received_time']);
		$date = date('d/m/Y',strtotime($expdate[0]));
		$time = date('H:i:s', strtotime($expdate[1]));
		$balance = $get_val[0]['balance'];
		$hallmark_type = $get_val[0]['hallmark_type'];
		$weight = ($get_val[0]['hallmark_weight'] == 0) ? ($get_val[0]['card_weight'] + $get_val[0]['photo_weight']) : $get_val[0]['hallmark_weight'];
		$card = $get_val[0]['card_piece'];
		$photo = $get_val[0]['photo_piece'];
		//---------------- start pdf section -----------------//		
        PDF::AddPage('P', [70,100]);
		PDF::SetFont('helvetica', '', 10);
		$x=5;$y=10;
		PDF::Text($x, $y, 'SL No:- '.$sl_no);
		$x=36;
		PDF::Text($x, $y, 'Date: '.$date);
		$y+=4;
		PDF::Text($x, $y, 'Time: '.$time);
		$x=5;$y+=5;
		if($get_val[0]['fk_ledger_id']==0){
			PDF::Text($x, $y, $get_val[0]['customer_name']);
		}else{
			PDF::Text($x, $y, $get_val[0]['jewellers_name']);
			$y+=4;
			PDF::Text($x, $y, $get_val[0]['propriter_name']);
			if($balance < 0){
				$x=30;$y+=4;
				PDF::Text($x, $y, 'Old Due: '.number_format(abs($balance),2).'/-');
			}elseif($balance > 0){
				$x=26;$y+=4;
				PDF::Text($x, $y, 'Old Deposit: '.$balance.'/-');
			}
		}
		$y+=6;
		$style = array('width' => 0.1, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0,0,0));
		if($hallmark_type == 'H'){
			PDF::Line(4, $y, 10, $y, $style);$y1=$y;
		}
		$y+=6;
		if($hallmark_type == 'H'){
			PDF::Line(4, $y, 10, $y, $style);
			PDF::Line(4, $y1, 4, $y, $style);
			PDF::Line(10, $y1, 10, $y, $style);
		}
		$x=5;$y-=5;
		if($hallmark_type == 'H'){
			PDF::Text($x, $y, $hallmark_type);
		}
		// elseif($hallmark_type == 'O'){
		// 	PDF::Text($x, $y, $hallmark_type);
		// }
		$x+=6;
		PDF::Text($x, $y, 'Weight:- '.number_format($weight,3).'gm.');
		if($hallmark_type != ''){
			$x+=36;
			PDF::Text($x, $y, 'Piece:- '.$get_val[0]['hallmark_piece']);
		}
		if($card != 0 || $photo != 0){
			$x=11;$y+=5;
			if($card != 0){
				PDF::Text($x, $y, 'Card:- '.$card.' pcs.');
				$x+=27;
			}
			if($photo != 0){
				PDF::Text($x, $y, 'Photo:- '.$photo.' pcs.');
			}
		}
		$y+=6;
		PDF::Line(0, $y, 70, $y, $style);
		$x=11;$y+=0.5;
		PDF::SetFont('helvetica', '', 12);
		PDF::Text($x, $y, 'Thank you for visit: '.$shop_name_billing);

		PDF::Output('received_bill.pdf');
	}

    public function partyDueDepositeStatementPdf (Request $request){		
		$ledger_id = $request->ledger_id;		
		$daterange = explode('-', $request->dateRange);
		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]);
		
		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]);
		
		if($ledger_id == ''){
			$countval = CustomerTransection::whereBetween('created_date_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))->count();
			$table_data = CustomerTransection::leftJoin('tbl_ledger','tbl_customer_transection.fk_ledger_id','=','tbl_ledger.id')->whereBetween('tbl_customer_transection.created_date_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))
                            ->select('tbl_customer_transection.*','tbl_ledger.jewellers_name','tbl_ledger.propriter_name')
                            ->get()->toArray();
            $sum_table = DB::select("SELECT SUM(CASE WHEN type = 'C' THEN amount ELSE 0 END) TotalCredit, SUM(CASE WHEN type = 'D' THEN amount ELSE 0 END) TotalDebit FROM tbl_customer_transection WHERE created_date_time BETWEEN'".$startDate.' '.'00:00:00'."' AND '".$endDate.' '.'23:59:59'."' ");
            $sum_decode = json_decode(json_encode($sum_table,true),true);
		}else{
            $countval = CustomerTransection::where('fk_ledger_id',$ledger_id)->whereBetween('created_date_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))->count();
			$table_data = CustomerTransection::leftJoin('tbl_ledger','tbl_customer_transection.fk_ledger_id','=','tbl_ledger.id')->whereBetween('tbl_customer_transection.created_date_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))
                            ->where('fk_ledger_id',$ledger_id)
                            ->select('tbl_customer_transection.*','tbl_ledger.jewellers_name','tbl_ledger.propriter_name')
                            ->get()->toArray();
            $sum_table = DB::select("SELECT SUM(CASE WHEN type = 'C' THEN amount ELSE 0 END) TotalCredit, SUM(CASE WHEN type = 'D' THEN amount ELSE 0 END) TotalDebit FROM tbl_customer_transection WHERE created_date_time BETWEEN'".$startDate.' '.'00:00:00'."' AND '".$endDate.' '.'23:59:59'."' AND fk_ledger_id = '".$ledger_id."' ");
            $sum_decode = json_decode(json_encode($sum_table,true),true);		
		}
		
		$tr = '';
		foreach($table_data as $data){
			
			//date 
			$expdate = explode(' ', $data['created_date_time']);
			$credit = $data['type'] == 'C' ? $data['amount'] : '';
			$debit = $data['type'] == 'D' ? $data['amount'] : '';
			$plus_minuse = $data['balance'] < 0 ? '-': '+';
			$tr .= '<tr>
						<td align="center" style="font-size: 8px;">'.date('d/m/Y',strtotime($expdate[0])).'</td>
						<td align="center" style="font-size: 8px;">'.$data['jewellers_name'].'</td>
						<td align="center" style="font-size: 8px;">'.$data['propriter_name'].'</td>
						<td align="center" style="font-size: 8px;">'.$data['remarks'].'</td>
						<td align="center" style="font-size: 8px;">'.$credit.'</td>
						<td align="center" style="font-size: 8px;">'.$debit.'</td>
						<td align="center" style="font-size: 8px;">'.$plus_minuse.'</td>
						<td align="center" style="font-size: 8px;">'.number_format(abs($data['balance']),2).'</td>
					</tr>';
		}
		if(sizeof($sum_decode)>0){
			
			$tr .= '<tr>
						<td style="font-size: 8px;"></td>
						<td style="font-size: 8px;"></td>
						<td style="font-size: 8px;"></td>
						<td align="right" style="font-size: 10px; font-weight: bold;">TOTAL</td>
                        <td align="center" style="font-size: 8px; font-weight: bold;">'.$sum_decode[0]['TotalCredit'].'</td>
						<td align="center" style="font-size: 8px; font-weight: bold;">'.$sum_decode[0]['TotalDebit'].'</td>
						<td align="center" style="font-size: 8px;"></td>
						<td align="center" style="font-size: 8px;"></td>						
					</tr>';
		}
		$tr.= 
		$html = '<h1 align="center">Party Due Deposit Statement</h1>
				<table border="1" cellpadding="2" cellspacing="0" nobr="true">
					<tr>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Date</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 19%;">Jewellers Name</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 19%;">Proprietor Name</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 23%;">Remarks</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Credit</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Debit</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 3%;">+/-</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Balance</th>
					</tr>
					'.$tr.'
				</table>';
		PDF::SetTitle('Party Due Deposite Statement');
		PDF::AddPage();
		PDF::writeHTML($html, true, false, true, false, '');

        $path = storage_path('export-pdf/party-due-deposite-statement');
        File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);
		$fullfilepath = $path.'/party-due-deposite-statement.pdf';
		$file = PDF::Output($fullfilepath, 'F');
		
		$return['filepath'] = $fullfilepath;
		$return['key'] = 'S';
		$return['msg'] = 'Your File Downloaded.';
		return $return;
	}

	public function dailySeetStatementPdf (Request $request){	
		$exp_date = explode('/', $request->datepicker);
		$date = trim($exp_date[2]).'-'.trim($exp_date[1]).'-'.trim($exp_date[0]);
		
		$sum_expenses_query = DB::select("SELECT SUM(amount) FROM tbl_expenses WHERE created_date_time BETWEEN '".$date.' '.'00:00:00'."' AND '".$date.' '.'23:59:59'."'");
		$sum_expenses_decode = json_decode(json_encode($sum_expenses_query,true),true);
        $daily_expenses = $sum_expenses_decode[0]['SUM(amount)'];

		$countval = Received::whereBetween('delivery_time',array($date.' '.'00:00:00',$date.' '.'23:59:59'))->count();

		$table_data = Received::leftJoin('tbl_ledger','tbl_received.fk_ledger_id','=','tbl_ledger.id')->whereBetween('tbl_received.delivery_time',array($date.' '.'00:00:00',$date.' '.'23:59:59'))
					->select('tbl_received.*','tbl_ledger.jewellers_name','tbl_ledger.propriter_name')
					->get()->toArray();
        $sum_table = DB::select("SELECT SUM(total) TotalTotal, SUM(paid) TotalPaid FROM tbl_received WHERE is_delete = 'N' AND delivery_time BETWEEN'".$date.' '.'00:00:00'."' AND '".$date.' '.'23:59:59'."' ");
        $sum_decode = json_decode(json_encode($sum_table,true),true);
		
		$tr = '';
		$total_due = 0;
		$total_discount = 0;
		$total_ornament = 0;
		$total_card = 0;
		$total_photo = 0;
		foreach($table_data as $data){
			$due = $data['total'] - $data['paid'];
			$total_due = ($due > 10 && $data['is_delete']=='N') ? ($total_due + $due) : $total_due;
			$total_discount += $data['discount'];
			$total_ornament = ($data['is_delete']=='N') ? ($total_ornament + $data['hallmark_piece']) : $total_ornament;
			$total_card = ($data['is_delete']=='N') ? ($total_card + $data['card_piece']) : $total_card;
			$total_photo = ($data['is_delete']=='N') ? ($total_photo + $data['photo_piece']) : $total_photo;
			$jewellers_customer_name = $data['fk_ledger_id'] == 0 ? $data['customer_name'] : $data['jewellers_name'];
			// $propriter_name = $data['fk_ledger_id'] == 0 ?  $data['customer_name'] : $data['propriter_name'];
			$reain_weight = ($data['hallmark_weight']==0) ? ($data['hallmark_weight'] + $data['card_weight'] + $data['photo_weight']) : $data['hallmark_weight'];
			$ornament_piece = $data['hallmark_piece']==0 ? '-' : $data['hallmark_piece'];
			$hallmark_ch = $data['hallmark_piece']==0 ? '-' : $data['hallmark_rate'].' ('.$data['hallmark_type'].')';
			$card = $data['card_piece'] == 0 ? '-' : $data['card_piece'];
			$card_rate = $data['card_piece'] == 0 ? '-' : $data['card_rate'];
			$photo = $data['photo_piece'] == 0 ? '-' : $data['photo_piece'];
			$photo_rate = $data['photo_piece'] == 0 ? '-' : $data['photo_rate'];
			$due_amount = ($due > 10 && $data['is_delete']=='N') ? number_format($due, 2) : '-';
			$discount = ($data['discount'] == 0 || $data['is_delete']=='Y') ? '-' : $data['discount'];
			$paid = ($data['is_delete']=='Y') ? 'Deleted' : $data['paid'];
			$bgcolor = ($data['is_delete']=='Y') ? '#d9d9d9' : '#ffffff';
			$tr .= '<tr style="background-color: '.$bgcolor.';">
						<td align="center" style="font-size: 7px;">'.$data['id'].'</td>
						<td align="center" style="font-size: 7px;">'.$data['token_no'].'</td>
						<td align="center" style="font-size: 7px;">'.$jewellers_customer_name.'</td>
						<td align="center" style="font-size: 7px;">'.number_format($reain_weight, 3).'</td>
						<td align="center" style="font-size: 7px;">'.$data['delivery_weight'].'</td>
						<td align="center" style="font-size: 7px;">'.$ornament_piece.'</td>
						<td align="center" style="font-size: 7px;">'.$hallmark_ch.'</td>
						<td align="center" style="font-size: 7px;">'.$card.'</td>
						<td align="center" style="font-size: 7px;">'.$card_rate.'</td>
						<td align="center" style="font-size: 7px;">'.$photo.'</td>
						<td align="center" style="font-size: 7px;">'.$photo_rate.'</td>
						<td align="center" style="font-size: 7px;">'.date("d/m/Y, h:i A", strtotime($data['received_time'])).'</td>
						<td align="center" style="font-size: 7px;">'.date("d/m/Y, h:i A", strtotime($data['delivery_time'])).'</td>
						<td align="center" style="font-size: 7px;">'.$data['total'].'</td>
						<td align="center" style="font-size: 7px;">'.$due_amount.'</td>
						<td align="center" style="font-size: 7px;">'.$discount.'</td>
						<td align="center" style="font-size: 7px;">'.$paid.'</td>
					</tr>';
		}
		if(sizeof($sum_decode)>0){
			
			$tr .= '<tr>
						<td style="font-size: 7px;"></td>
						<td style="font-size: 7px;"></td>
						<td style="font-size: 7px;"></td>
						<td style="font-size: 7px;"></td>
						<td align="right" style="font-size: 7px; font-weight: bold;">Total</td>
						<td align="center" style="font-size: 7px; font-weight: bold;">'.$total_ornament.'</td>
						<td style="font-size: 7px;"></td>
						<td align="center" style="font-size: 7px; font-weight: bold;">'.$total_card.'</td>
						<td style="font-size: 7px;"></td>

						<td align="center" style="font-size: 7px; font-weight: bold;">'.$total_photo.'</td>
						<td style="font-size: 7px;"></td>
						<td style="font-size: 7px;"></td>
						<td style="font-size: 7px;"></td>
						<td align="center" style="font-size: 7px; font-weight: bold;">'.$sum_decode[0]['TotalTotal'].'</td>
						<td align="center" style="font-size: 7px; font-weight: bold;">'.number_format($total_due, 2).'</td>				
						<td align="center" style="font-size: 7px; font-weight: bold;">'.number_format($total_discount, 2).'</td>
						<td align="center" style="font-size: 7px; font-weight: bold;">'.$sum_decode[0]['TotalPaid'].'</td>
					</tr>';
		}
		$tr.= 
		$html = '<h1 align="center">Daily Sheet Statement('.$request->datepicker.')</h1>
				<table border="1" cellpadding="2" cellspacing="0" nobr="true">
					<tr>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 6%;">Sl No.</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Token No.</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 12%;">Jewellers/Customer Name</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Received Weight</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Delivery Weight</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Ornament Piece</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Hallmark ch./pcs.</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 3%;">Card</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 4%;">Card rate/pcs</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 4%;">Photo</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Photo rate/ pcs.</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 10%;">Received Time</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 10%;">Delivery Time</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Total Amount</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Due</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 5%;">Discount</th>
						<th align="center" style="font-size: 7px; font-weight: bold; width: 6%;">Received</th>
					</tr>
					'.$tr.'
				</table>
				<table style="padding-top: 5px;">
					<tr style="font-size:11px;">
						<td>
							<table border="1" cellpadding="2" cellspacing="0" nobr="true">				
								<thead>
									<tr>
										<th align="center" style="font-size: 10px; font-weight: bold;">Total</th>
										<th align="center" style="font-size: 10px; font-weight: bold; ">Due</th>
										<th align="center" style="font-size: 10px; font-weight: bold;">Discount</th>
										<th align="center" style="font-size: 10px; font-weight: bold;">Received</th>
										<th align="center" style="font-size: 10px; font-weight: bold;">Expenses</th>
										<th align="center" style="font-size: 10px; font-weight: bold;">Remaining</th>
									</tr>
								</thead> 
								<tbody>
									<tr>
										<td align="center" style="font-size: 10px;">'.$sum_decode[0]['TotalTotal'].'</td>
										<td align="center" style="font-size: 10px;">'.number_format($total_due, 2).'</td>
										<td align="center" style="font-size: 10px;">'.number_format($total_discount, 2).'</td>
										<td align="center" style="font-size: 10px;">'.$sum_decode[0]['TotalPaid'].'</td>
										<td align="center" style="font-size: 10px;">'.$daily_expenses.'</td>
										<td align="center" style="font-size: 10px;">'.number_format(($sum_decode[0]['TotalPaid']-$daily_expenses),2).'</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</table>';
		PDF::SetTitle('Daily Sheet Statement');
		PDF::AddPage('L');
		PDF::writeHTML($html, true, false, true, false, '');

        $path = storage_path('export-pdf/daily-sheet-statement');
        File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);
		$fullfilepath = $path.'/daily-sheet.pdf';
		$file = PDF::Output($fullfilepath, 'F');
		
		$return['filepath'] = $fullfilepath;
		$return['key'] = 'S';
		$return['msg'] = 'Your File Downloaded.';
		return $return;
	}

	public function allPartyDueStatementPdf (Request $request){		
		$ledger_id = $request->ledger_id;		
		$daterange = explode('-', $request->dateRange);
		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]);
		
		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]);
		
		if($ledger_id == ''){
			$countval = Ledger::where('balance', '<>', 0)->whereBetween('updated_balance_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))->count();
			$table_data = Ledger::whereBetween('updated_balance_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))
						->where('balance', '<>', 0)
                        ->select('jewellers_name', 'propriter_name', 'balance', 'updated_balance_time')
                        ->get()->toArray();
            $sum_table = DB::select("SELECT SUM(CASE WHEN balance < 0 THEN balance ELSE 0 END) TotalDue, SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END) TotalDeposit FROM tbl_ledger WHERE balance <> 0 AND updated_balance_time BETWEEN'".$startDate.' '.'00:00:00'."' AND '".$endDate.' '.'23:59:59'."' ");
            $sum_decode = json_decode(json_encode($sum_table,true),true);
		}else{
            $countval = Ledger::where('id',$ledger_id)->where('balance', '<>', 0)->whereBetween('updated_balance_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))->count();
			$table_data = Ledger::whereBetween('updated_balance_time',array($startDate.' '.'00:00:00',$endDate.' '.'23:59:59'))
                            ->where('id',$ledger_id)
							->where('balance', '<>', 0)
                            ->select('jewellers_name', 'propriter_name', 'balance', 'updated_balance_time')
                            ->get()->toArray();
			$sum_table = DB::select("SELECT SUM(CASE WHEN balance < 0 THEN balance ELSE 0 END) TotalDue, SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END) TotalDeposit FROM tbl_ledger WHERE balance <> 0 AND updated_balance_time BETWEEN'".$startDate.' '.'00:00:00'."' AND '".$endDate.' '.'23:59:59'."' AND id = '".$ledger_id."'");
            $sum_decode = json_decode(json_encode($sum_table,true),true);		
		}
		
		$tr = '';
		foreach($table_data as $data){
			
			//date 
			$expdate = explode(' ', $data['updated_balance_time']);
			$due = $data['balance'] < 0 ? number_format(abs($data['balance']),2) : '';
			$deposit = $data['balance'] > 0 ? $data['balance'] : '';
			$tr .= '<tr>
						<td align="center" style="font-size: 8px;">'.date('d/m/Y',strtotime($expdate[0])).'</td>
						<td align="center" style="font-size: 8px;">'.$data['jewellers_name'].'</td>
						<td align="center" style="font-size: 8px;">'.$data['propriter_name'].'</td>
						<td align="center" style="font-size: 8px; ">'.$due.'</td>
						<td align="center" style="font-size: 8px; ">'.$deposit.'</td>
					</tr>';
		}
		if(sizeof($sum_decode)>0){			
			$tr .= '<tr>
						<td style="font-size: 8px;"></td>
						<td style="font-size: 8px;"></td>
						<td align="right" style="font-size: 10px; font-weight: bold;">TOTAL</td>
                        <td align="center" style="font-size: 8px; font-weight: bold;">'.number_format(abs($sum_decode[0]['TotalDue']),2).'</td>
						<td align="center" style="font-size: 8px; font-weight: bold;">'.$sum_decode[0]['TotalDeposit'].'</td>					
					</tr>';
		}
		$tr.= 
		$html = '<h1 align="center">All Party Due Statement</h1>
				<table border="1" cellpadding="2" cellspacing="0" nobr="true">
					<tr>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 12%;">Date</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 32%;">Jewellers Name</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 32%;">Proprietor Name</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 12%;">Due</th>
						<th align="center" style="font-size: 10px; font-weight: bold; width: 12%;">Deposit</th>
					</tr>
					'.$tr.'
				</table>';
		PDF::SetTitle('All party Due Statement');
		PDF::AddPage();
		PDF::writeHTML($html, true, false, true, false, '');

        $path = storage_path('export-pdf/all-party-due-statement');
        File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);
		$fullfilepath = $path.'/all-party-due-statement.pdf';
		$file = PDF::Output($fullfilepath, 'F');
		
		$return['filepath'] = $fullfilepath;
		$return['key'] = 'S';
		$return['msg'] = 'Your File Downloaded.';
		return $return;
	}

	public function monthlyWorkingSheetStatementPdf (Request $request){		
		$month_year = $request->month_year;

		$tbl_received_qry = "SELECT SUM(total) as work_amount, SUM(paid) as paid_amount, SUM(discount) as discount_amount, DATE_FORMAT(delivery_time, '%Y-%m-%d') as date FROM `tbl_received` WHERE delivery_time is not null AND delivery_time between '".$month_year.'-01 00:00:00'."' AND '".$month_year.'-31 23:59:59'."' GROUP BY DATE_FORMAT(delivery_time, '%Y-%m-%d')";

		$tbl_expenses_qry = "SELECT SUM(amount) as expenses_amount, GROUP_CONCAT(CONCAT(remarks, ' ', substring_index(amount,'.',1)) SEPARATOR ' + ') as expenses, DATE_FORMAT(created_date_time, '%Y-%m-%d') as date FROM `tbl_expenses` WHERE created_date_time between '".$month_year.'-01 00:00:00'."' AND '".$month_year.'-31 23:59:59'."' GROUP BY DATE_FORMAT(created_date_time, '%Y-%m-%d')";

		$tbl_received_get_data = DB::select($tbl_received_qry);
		$received_array = json_decode(json_encode($tbl_received_get_data , true), true);
		$tbl_expenses_get_data = DB::select($tbl_expenses_qry);
		$expenses_array= json_decode(json_encode($tbl_expenses_get_data , true), true);
		$data = [];
		$total_work_amount = 0;
		$total_due_amount = 0;
		$total_discount_amount = 0;
		$total_paid_amount = 0;
		$total_expenses_amount = 0;
		$balance = 0;
		$tr = '';
		if((!empty($received_array)) || (!empty($expenses_array))){			
			for($d = 1; $d<=31; $d++){
				$d = ($d<10) ? '0'.$d : $d;
				$date_val = $month_year.'-'.$d;
				$received_key = array_search($date_val, array_column($received_array, 'date'));
				$expenses_key = array_search($date_val, array_column($expenses_array, 'date'));
				if($received_key != '' || $expenses_key != ''){
					$date_td = date("d/m/Y", strtotime($date_val));
					if($received_key != ''){
						$work_amount = $received_array[$received_key]['work_amount'];
						$paid_amount = $received_array[$received_key]['paid_amount'];
						$discount_amount = $received_array[$received_key]['discount_amount'];
						$due_amount = $work_amount - $discount_amount - $paid_amount;
						$total_work_amount += $work_amount;
						$total_due_amount += $due_amount;
						$total_discount_amount += $discount_amount;
						$total_paid_amount += $paid_amount;

						$work_td = $work_amount;
						$due_td = number_format($due_amount,2);
						$discount_td = $discount_amount;
						$paid_td = $paid_amount;
					}else{
						$paid_amount = 0;

						$work_td = '';
						$due_td = '';
						$discount_td = '';
						$paid_td = '';
					}
					if($expenses_key != ''){
						$expenses_amount = $expenses_array[$expenses_key]['expenses_amount'];
						$total_expenses_amount += $expenses_amount;

						$expenses_remarks_td = $expenses_array[$expenses_key]['expenses'];
						$expenses_td = $expenses_amount;
					}else{
						$expenses_amount = 0;

						$expenses_remarks_td = '';
						$expenses_td = '-';
					}
					$remaining_amount = $paid_amount - $expenses_amount;
					$balance += $remaining_amount;

					$remaining_td = number_format($remaining_amount,2);
					$balance_td = number_format($balance,2);

					$tr .= '<tr>
						<td align="center" style="font-size: 8px;">'.$date_td.'</td>
						<td align="center" style="font-size: 8px;">'.$work_td.'</td>
						<td align="center" style="font-size: 8px;">'.$due_td.'</td>
						<td align="center" style="font-size: 8px; ">'.$discount_td.'</td>
						<td align="center" style="font-size: 8px; ">'.$paid_td.'</td>
						<td align="center" style="font-size: 8px; ">'.$expenses_remarks_td.'</td>
						<td align="center" style="font-size: 8px; ">'.$expenses_td.'</td>
						<td align="center" style="font-size: 8px; ">'.$remaining_td.'</td>
						<td align="center" style="font-size: 8px; ">'.$balance_td.'</td>
					</tr>';
				}
			}
			$tr .= '<tr>
					<td align="right" style="font-size: 10px; font-weight: bold;">TOTAL</td>
					<td align="center" style="font-size: 8px; font-weight: bold;">'.number_format($total_work_amount,2).'</td>
					<td align="center" style="font-size: 8px; font-weight: bold;">'.number_format($total_due_amount,2).'</td>	
					<td align="center" style="font-size: 8px; font-weight: bold;">'.number_format($total_discount_amount,2).'</td>
					<td align="center" style="font-size: 8px; font-weight: bold;">'.number_format($total_paid_amount,2).'</td>	
					<td style="font-size: 8px;"></td>
					<td align="center" style="font-size: 8px; font-weight: bold;">'.number_format($total_expenses_amount,2).'</td>	
					<td style="font-size: 8px;"></td>
					<td style="font-size: 8px;"></td>			
				</tr>';
			$tr.= 
			$html = '<h1 align="center">Monthly Working Sheet Statement('.date('M Y',strtotime($date_val)).')</h1>
					<table border="1" cellpadding="2" cellspacing="0" nobr="true">
						<tr>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Date</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Work</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Due</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Discount</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Paid</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 24%;">Expenses Details</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 10%;">Expenses</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 11%;">Remaining</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 10%;">Balance</th>
						</tr>
						'.$tr.'
					</table>';
			PDF::SetTitle('Monthly Working Sheet Statement');
			PDF::AddPage();
			PDF::writeHTML($html, true, false, true, false, '');
	
			$path = storage_path('export-pdf/monthly-working-sheet-statement');
			File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);
			$fullfilepath = $path.'/monthly-working-sheet-statement.pdf';
			$file = PDF::Output($fullfilepath, 'F');
			
			$return['filepath'] = $fullfilepath;
			$return['key'] = 'S';
			$return['msg'] = 'Your File Downloaded.';
			return $return;
		}
	}

	public function ownFundStatementPdf (Request $request){
		$paid_amount_checked = $request->paid_amount;
		$customer_fund_checked = $request->customer_fund;

		$daterange = explode('-', $request->daterange);
		$expstartdate = explode('/', $daterange[0]);
		$startDate = trim($expstartdate[2]).'-'.trim($expstartdate[1]).'-'.trim($expstartdate[0]) .' 00:00:00';

		$expenddate = explode('/', $daterange[1]);
		$endDate = trim($expenddate[2]).'-'.trim($expenddate[1]).'-'.trim($expenddate[0]).' 23:59:59';
		$from_qry = " FROM tbl_own_fund";
		$where_qry = " WHERE created_date_time BETWEEN '".$startDate."' AND '".$endDate."'";

		if($paid_amount_checked == 'Y' && $customer_fund_checked == 'N'){
			$checked_qry = " AND type = 'P'";
		}elseif($paid_amount_checked == 'N' && $customer_fund_checked == 'Y'){
			$checked_qry = " AND type = 'C'";
		}elseif($paid_amount_checked == 'N' && $customer_fund_checked == 'N'){
			$checked_qry = " AND type = 'N'";
		}else{
			$checked_qry = "";
		}
		
		$qry = "SELECT * $from_qry $where_qry $checked_qry";

		$sum_table = DB::select("SELECT SUM(CASE WHEN type = 'P' THEN amount ELSE 0 END) TotalPaid, SUM(CASE WHEN type = 'C' THEN amount ELSE 0 END) TotalCstmFund $from_qry $where_qry $checked_qry");
		$sum_decode = json_decode(json_encode($sum_table,true),true);

		$GetData = DB::select($qry);
		$decode = json_decode(json_encode($GetData , true), true);
		$data = [];

		$tr = '';
		if(!empty($decode)){
			foreach($decode as $value){
				$expdate = explode(' ', $value['created_date_time']);
				$date = date("d/m/Y", strtotime($expdate[0]));
				$paid_amount_debit = $value['type'] == 'P' ? $value['amount'] : '';
				$cstm_fund_debit = $value['type'] == 'C' ? $value['amount'] : '';
				$tr .= '<tr>
						<td align="center" style="font-size: 8px;">'.$date.'</td>
						<td align="center" style="font-size: 8px;">'.$value['remarks'].'</td>
						<td align="center" style="font-size: 8px;">'.$paid_amount_debit.'</td>
						<td align="center" style="font-size: 8px; ">'.$cstm_fund_debit.'</td>
						<td align="center" style="font-size: 8px; ">'.$value['updated_balance'].'</td>
					</tr>';
			}
			$tr .= '<tr>
					<td style="font-size: 8px;"></td>
					<td align="right" style="font-size: 10px; font-weight: bold;">TOTAL</td>
					<td align="center" style="font-size: 8px; font-weight: bold;">'.$sum_decode[0]['TotalPaid'].'</td>
					<td align="center" style="font-size: 8px; font-weight: bold;">'.$sum_decode[0]['TotalCstmFund'].'</td>
					<td style="font-size: 8px;"></td>			
				</tr>';
			$tr.= 
			$html = '<h1 align="center">Own Fund Statement</h1>
					<table border="1" cellpadding="2" cellspacing="0" nobr="true">
						<tr>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 9%;">Date</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 42%;">Remarks</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 19%;">Debit(Paid Amount)</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 17%;">Debit(Due Collection)</th>
							<th align="center" style="font-size: 10px; font-weight: bold; width: 13%;">Balance</th>
						</tr>
						'.$tr.'
					</table>';
			PDF::SetTitle('Own Fund Statement');
			PDF::AddPage();
			PDF::writeHTML($html, true, false, true, false, '');
	
			$path = storage_path('export-pdf/own-fund-statement');
			File::isDirectory($path) or File::makeDirectory($path, 0777, true, true);
			$fullfilepath = $path.'/own-fund-statement.pdf';
			$file = PDF::Output($fullfilepath, 'F');
			
			$return['filepath'] = $fullfilepath;
			$return['key'] = 'S';
			$return['msg'] = 'Your File Downloaded.';
			return $return;
		}
	}
}