<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Ledger;
use App\Models\Received;
use App\Models\ReceivedCard;
use App\Models\ReceivedPhoto;
use App\Models\ReceivedHallmark;
use App\Models\Stock;
use App\Models\StockUpdate;
use App\Models\CustomerTransection;
use DB;
use Response;
use Session;

class DeliveryCtrl extends Controller{
    public function delivery (){
		$data['main_menu'] = 'mnu_delivery';
		$data['sub_menu'] = '';
		$data['breadcrumb'] = [['delivery', 'Delivery']];
		$stock_data = Stock::get()->toArray();
		$data['xrf_checked'] = ($stock_data[0]['xrf_checked'] == 'A') ? 'checked' : 'uncheked';
        $username = Session::get('username');
		if($username=='received' || $username=='owner' || $username=='card')
        return view('delivery.delivery')->withData($data);
        else
        return abort(404);
    }

	public function deliveryTblData (Request $request){
		$stock_data = Stock::get()->toArray();
		$xrf_checked = $stock_data[0]['xrf_checked'];
		$search_qry = '';
		if(!empty($request->input('search.value'))) {
			$search = strtoupper($request->input('search.value'));
			$search_qry = " AND (tbl_received.id LIKE '%".$search."%' OR UPPER(tbl_received.token_no) LIKE '%".$search."%' OR UPPER(tbl_ledger.jewellers_name) LIKE '%".$search."%' OR UPPER(tbl_ledger.propriter_name) LIKE '%".$search."%' OR UPPER(tbl_received.customer_name) LIKE '%".$search."%')";
		}

		$limitOffset = " LIMIT ".$request->input('length')." OFFSET ".$request->input('start')."";
		$where = "WHERE tbl_received.delivery_time IS NULL OR tbl_received.delivery_time = '0000-00-00 00:00:00' AND tbl_received.is_delete = 'N'";
		$from = "FROM tbl_received LEFT JOIN tbl_ledger ON tbl_received.fk_ledger_id = tbl_ledger.id";
		$qry = "SELECT tbl_received.*, tbl_ledger.jewellers_name, tbl_ledger.balance, tbl_ledger.propriter_name $from $where  $search_qry  $limitOffset";

		$total_row = DB::select("SELECT COUNT(*) as total_record $from $where $search_qry");
		
		$j_decode_total_row = json_decode(json_encode($total_row,true),true);
		$total_data = 0;
		if(count($j_decode_total_row) > 0){
			$total_data = $j_decode_total_row[0]['total_record'];
		}

		$GetData = DB::select($qry);
		$decodeGetData = json_decode(json_encode($GetData , true), true);
		$data = [];

		if(!empty($decodeGetData)){
			foreach($decodeGetData as $value){
				$delivery_weight = '<span class="delivery-weight-value'.$value['id'].'">'.$value['delivery_weight'].'</span><input type="text" class="form-control input-sm number-validate delivery-weight'.$value['id'].' d-none" value="'.$value['delivery_weight'].'">';
				$paid = '<span class="paid-value'.$value['id'].'">'.$value['paid'].'</span><input type="text" class="form-control number-validate input-sm paid'.$value['id'].' d-none" value="'.$value['paid'].'">';
				$dlt_btn = '<button class="btn btn-danger btn-sm delivery-delete-btn" data-id="'.$value['id'].'" type="button"><i class="fadeIn animated bx bx-trash-alt"></i></button>';
				$btn = '<button type="button" class="btn btn-primary btn-in btn-sm ml-4 open-tbl-frm edittable-add-data'.$value['id'].'" data-id="'.$value['id'].'"><i class="fadeIn animated bx bx-edit"></i></button><button class="btn btn-danger btn-sm ml-m5 delivery-delete-btn" data-id="'.$value['id'].'" type="button"><i class="fadeIn animated bx bx-trash-alt"></i></button>';
				$view_btn = '<button class="btn btn-primary btn-sm view-btn" data-id="'.$value['id'].'" type="button">'.$value['id'].'</button>';
				// $edit_btn = '<button class="btn btn-warning btn-sm delivery-edit-btn" data-id="'.$value['id'].'" type="button"><i class="fadeIn animated bx bx-pencil"></i></button>';
				$row = array();
				$row[] = $value['balance'];
				$row[] = $view_btn;
				// $row[] = $value['token_no'];
				$row[] = $value['xrf_man'];
				$row[] = ($value['fk_ledger_id']==0) ? '' : $value['jewellers_name'];
				$row[] = ($value['fk_ledger_id']==0) ? $value['customer_name'] : $value['propriter_name'];
				$row[] = ($value['hallmark_weight']==0) ? (number_format(($value['hallmark_weight'] + $value['card_weight'] + $value['photo_weight']),3)) : $value['hallmark_weight'];
				$row[] = $delivery_weight;
				$row[] = ($value['hallmark_piece']==0) ? '-' : $value['hallmark_piece'];
				$row[] = ($value['hallmark_piece']==0) ? '-' : ($value['hallmark_rate'].' ('.$value['hallmark_type'].')');
				$row[] = $value['card_piece'] == 0 ? '-' : $value['card_rate'].'/'.$value['card_piece'];
				$row[] = $value['photo_piece'] == 0 ? '-' : $value['photo_rate'].'/'.$value['photo_piece'];
				$row[] = $value['lager_man'];
				$row[] = $value['total'];
				$row[] = $paid;
				$row[] = $xrf_checked == 'A' ? $value['xrf_man'] != NULL ? ($value['lager_man'] != NULL||$value['hallmark_piece']==0) ? $btn : $dlt_btn : $dlt_btn : $btn;
				// $row[] = $dlt_btn;
				$data[] = $row;
			}
		}
		$json_data = array(
			"draw" => $request->input('draw'),
			"recordsTotal" => $total_data,
			"recordsFiltered" => $total_data,
			"data" => $data
		);
		return Response::json($json_data);
	}

    public function deliverySubmit (Request $request){
		$received_id = $request->id;
		$delivery_weight = $request->delivery_weight;
		$paid = $request->paid;
		
		$time = date('Y-m-d H:i:s');
		if($delivery_weight == '' || $paid == ''){
			$update_received_data = Received::where('id', $received_id)->update(['paid'=> $paid, 'delivery_weight'=> $delivery_weight]);
		}else{
			$get_received_data = Received::select('tbl_received.*','tbl_received_hallmark.remarks')
												->leftJoin('tbl_received_hallmark','tbl_received.id','=','tbl_received_hallmark.fk_received_id')
												->where('tbl_received.id', $received_id)
												->get()
												->toArray();
			if($get_received_data[0]['total'] < $paid){
				$return = ['key' => 'E', 'msg' => 'Extra Amount Not Received'];
        		return $return;
			}
			$due = $get_received_data[0]['total'] - $paid;
			$ledger_id = $get_received_data[0]['fk_ledger_id'];
			$card_piece = $get_received_data[0]['card_piece'];
			$photo_piece = $get_received_data[0]['photo_piece'];

			if(($ledger_id == 0) && ($due > 10)){
				$return = ['key' => 'E', 'msg' => 'Clear the Full Amount.'];
        		return $return;
			}
			$discount = $due <= 10 ? $due : 0;
			if(($ledger_id != 0) && ($due > 10)){
				$get_ledger_data = Ledger::select('balance', 'updated_balance_time')->where('id', $ledger_id)->get()->toArray();
				$ledger_balance = $get_ledger_data[0]['balance'];
				$updated_balance_time = $get_ledger_data[0]['updated_balance_time'];

				$ledger_balance = $get_ledger_data[0]['balance'] - $due;
				$updated_balance_time = $time;

				$remarks = 'SL No.-'.$received_id.', Weight-'.($get_received_data[0]['hallmark_weight'] + $get_received_data[0]['card_weight'] + $get_received_data[0]['photo_weight']);
				$remarks = ($get_received_data[0]['hallmark_piece'] != 0) ? ($remarks.', Ornament-'.$get_received_data[0]['hallmark_piece']) : $remarks;
				$remarks = ($card_piece != 0) ? ($remarks.', Card-'.$card_piece) : $remarks;
				$remarks = ($photo_piece != 0) ? ($remarks.', Photo-'.$photo_piece) : $remarks;
				$remarks = ($get_received_data[0]['remarks']!='') ? ($remarks.'('.$get_received_data[0]['remarks'].')') : $remarks;

				$insert_array = array(
					"fk_ledger_id" => $ledger_id,
					"type" => 'D',
					"remarks" => $remarks,
					"amount" => $due,
					"balance" => $ledger_balance,
					"created_date_time" => $time
				);  
				$insert = CustomerTransection::insertGetId($insert_array);

				$update_ledger = Ledger::where('id', $ledger_id)->update(['balance'=> $ledger_balance, 'updated_balance_time'=>$updated_balance_time, 'last_transaction_time'=> $time]);
			}
			
			$stock_data = Stock::get()->toArray();
        	$paid_amount_stock = $stock_data[0]['paid_amount'] + $paid;
			$card_stock = $stock_data[0]['card'] - $card_piece;
			$photo_stock = $stock_data[0]['photo'] - $photo_piece;
			$rebons_stock = $stock_data[0]['rebons'] - $card_piece;

			if(($card_piece != 0) || ($photo_piece != 0)){
				$insert_array = [];
				if($card_piece != 0){
					$insert_array[] = [
						"type" => 'S',
						"fk_received_id" => $received_id,
						"fk_ledger_id" => $ledger_id,
						"stock_type" => 'C',
						"piece" => $card_piece,
						"balance" => $card_stock,
						"created_date_time" => $time
					]; 
					$insert_array[] = [
						"type" => 'S',
						"fk_received_id" => $received_id,
						"fk_ledger_id" => $ledger_id,
						"stock_type" => 'R',
						"piece" => $card_piece,
						"balance" => $rebons_stock,
						"created_date_time" => $time
					]; 
				}
				if($photo_piece != 0){
					$insert_array[] = [
						"type" => 'S',
						"fk_received_id" => $received_id,
						"fk_ledger_id" => $ledger_id,
						"stock_type" => 'P',
						"piece" => $photo_piece,
						"balance" => $photo_stock,
						"created_date_time" => $time
					];
				}
				$insert = StockUpdate::insert($insert_array);
			}
			$update_stock = Stock::query()->update(['card'=> $card_stock, 'photo'=> $photo_stock, 'rebons'=> $rebons_stock, 'paid_amount'=> $paid_amount_stock]);

			$update_received_data = Received::where('id', $received_id)->update(['paid'=> $paid, 'discount'=> $discount, 'delivery_weight'=> $delivery_weight, 'delivery_time'=> $time]);
		}
		$return = $update_received_data ? ['key' => 'S', 'msg' => 'Updated Successfully.'] : ['key' => 'E', 'msg' => 'Updated Un-successfully.'];
        return $return;
    }

    public function deleteDelivery (Request $request){
		$received_id = $request->id;
		$time = date('Y-m-d H:i:s');
		$update_received_data = Received::where('id', $received_id)->update(['is_delete'=> 'Y','delivery_time'=>$time]);
		$return = $update_received_data ? ['key' => 'S', 'msg' => 'Deleted Successfully.'] : ['key' => 'E', 'msg' => 'Deleted Un-successfully.'];
        return $return;
	}

	public function xrfManUpdate (Request $request){
		$sl_no = $request->sl_no;
		$xrf_result = $request->xrf_result;
		$received_data = Received::where('id', $sl_no)->get()->toArray();
		if(!empty($received_data)){
			if($received_data[0]['xrf_man']==NULL){
				$total_pcs = ($received_data[0]['hallmark_piece']==0)?($received_data[0]['card_piece']+$received_data[0]['photo_piece']):$received_data[0]['hallmark_piece'];
				$update_received_data = Received::where('id', $sl_no)->update(['xrf_man'=> $xrf_result]);
				$return = $update_received_data ? ['key' => 'S', 'msg' => 'updated Successfully.', 'total_pcs' => $total_pcs] : ['key' => 'E', 'msg' => 'Updatedted Un-successfully.'];
			}else{
				$return = ['key' => 'E', 'msg' => 'SL No. Already Updated.'];
			}
		}else{
			$return = ['key' => 'E', 'msg' => 'SL No. Invalid.'];
		}
        return $return;
	}

	public function lagerManUpdate (Request $request){
		$sl_no = $request->sl_no;
		$lager_result = $request->lager_result;
		$received_data = Received::where('id', $sl_no)->get()->toArray();
		if(!empty($received_data)){
			if($received_data[0]['xrf_man']==NULL){
				$return = ['key' => 'E', 'msg' => 'XRF man not Updated.'];
			}else{
				if($received_data[0]['lager_man']==NULL){
					$total_pcs = ($received_data[0]['hallmark_piece']==0)?($received_data[0]['card_piece']+$received_data[0]['photo_piece']):$received_data[0]['hallmark_piece'];
					$update_received_data = Received::where('id', $sl_no)->update(['lager_man'=> $lager_result]);
					$return = $update_received_data ? ['key' => 'S', 'msg' => 'updated Successfully.', 'total_pcs' => $total_pcs] : ['key' => 'E', 'msg' => 'Updatedted Un-successfully.'];
				}else{
					$return = ['key' => 'E', 'msg' => 'SL No. Already Updated.'];
				}
			}
		}else{
			$return = ['key' => 'E', 'msg' => 'SL No. Invalid.'];
		}
        return $return;
	}

	public function getReceivedData (Request $request){
		$received_id = $request->id;
		$data['hallmark'] = ReceivedHallmark::where('fk_received_id', $received_id)->get()->toArray();
		$data['card'] = ReceivedCard::where('fk_received_id', $received_id)->get()->toArray();
		$data['photo'] = ReceivedPhoto::where('fk_received_id', $received_id)->get()->toArray();
		return $data;
	}

	public function xrfManUpdateView (){
		if(Session::get('username')=='xrf')
        return view('delivery.xrf');
		else
        return abort(404);
    }

	public function lagerManUpdateView (){
		if(Session::get('username')=='lager')
        return view('delivery.lager');
		else
        return abort(404);
    }

	public function checkedXrfChange (Request $request){
		$status = $request->status;
		$statusupdate = Stock::query()->update(['xrf_checked'=> $status]);
		$return['key'] = 'S';
		$return['msg'] = 'Status has been updated.';
		return $return;
	}
}