<?php

namespace App\Http\Middleware;

use Closure;
use Session;

class BeforeLogin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->session()->has('is_login'))
        {
            $username = Session::get('username');
            if($username=='xrf')
            return redirect()->guest('xrf-man-update-view');
            elseif($username=='lager')
            return redirect()->guest('lager-man-update-view');
            else
            return redirect()->guest('ledger');
        }
        return $next($request);
    }
}
