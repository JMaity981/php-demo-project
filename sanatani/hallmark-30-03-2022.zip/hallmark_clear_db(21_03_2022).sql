-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 21, 2022 at 01:16 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hallmark`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_transection`
--

CREATE TABLE `tbl_customer_transection` (
  `id` int(11) NOT NULL,
  `fk_ledger_id` int(10) NOT NULL,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''C''=Credit ''D''=Debit',
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `created_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_expenses`
--

CREATE TABLE `tbl_expenses` (
  `id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `created_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ledger`
--

CREATE TABLE `tbl_ledger` (
  `id` int(11) NOT NULL,
  `jewellers_name` varchar(70) COLLATE utf8_bin NOT NULL,
  `propriter_name` varchar(70) COLLATE utf8_bin NOT NULL,
  `ph_no` varchar(15) COLLATE utf8_bin NOT NULL,
  `lc_no` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `gst_no` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `address` text COLLATE utf8_bin NOT NULL,
  `logo` varchar(15) COLLATE utf8_bin NOT NULL,
  `hallmarking_rate_h` decimal(10,2) NOT NULL,
  `hallmarking_rate_h_more` decimal(10,2) NOT NULL,
  `hallmarking_rate_o` decimal(10,2) NOT NULL,
  `card_rate` decimal(10,2) NOT NULL,
  `photo_rate` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `updated_balance_time` datetime DEFAULT current_timestamp(),
  `is_active` char(1) COLLATE utf8_bin NOT NULL COMMENT 'A=''active'',I=''inactive''',
  `is_delete` char(1) COLLATE utf8_bin NOT NULL COMMENT 'Y=''delete'',N=''notdelete''',
  `created_date_time` datetime NOT NULL,
  `updated_date_time` datetime DEFAULT NULL,
  `last_transaction_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(50) COLLATE utf8_bin NOT NULL,
  `status` char(1) COLLATE utf8_bin NOT NULL COMMENT 'A=''active'',I=''inactive''',
  `last_login` datetime NOT NULL,
  `licence_key` varchar(50) COLLATE utf8_bin NOT NULL,
  `is_delete` char(1) COLLATE utf8_bin NOT NULL COMMENT 'Y=''delete'',N=''not delete'''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `user_name`, `password`, `status`, `last_login`, `licence_key`, `is_delete`) VALUES
(1, 'received', 'MTIz', 'A', '2022-03-21 17:22:35', 'MjAyMi0xMC0wMQ==', 'N'),
(2, 'xrf', 'MTIz', 'A', '2022-03-21 17:23:51', 'MjAyMi0xMC0wMQ==', 'N'),
(3, 'lager', 'MTIz', 'A', '2022-03-21 17:24:12', 'MjAyMi0xMC0wMQ==', 'N'),
(4, 'owner', 'MTIz', 'A', '2022-03-21 17:26:54', 'MjAyMi0xMC0wMQ==', 'N'),
(5, 'manager', 'MTIz', 'A', '2022-03-21 17:25:35', 'MjAyMi0xMC0wMQ==', 'N'),
(6, 'card', 'MTIz', 'A', '2022-03-21 17:27:34', 'MjAyMi0xMC0wMQ==', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_own_fund`
--

CREATE TABLE `tbl_own_fund` (
  `id` int(11) NOT NULL,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''P''=Paid Amount, ''C''=Customer Fund',
  `amount` decimal(10,2) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `updated_balance` decimal(10,2) NOT NULL,
  `created_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rate_update`
--

CREATE TABLE `tbl_rate_update` (
  `id` int(11) NOT NULL,
  `hallmarking_h` decimal(10,2) NOT NULL,
  `hallmarking_h_more` decimal(10,2) NOT NULL,
  `more_then` int(3) NOT NULL,
  `hallmarking_o` decimal(10,2) NOT NULL,
  `card` decimal(10,2) NOT NULL,
  `photo` decimal(10,2) NOT NULL,
  `created_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_rate_update`
--

INSERT INTO `tbl_rate_update` (`id`, `hallmarking_h`, `hallmarking_h_more`, `more_then`, `hallmarking_o`, `card`, `photo`, `created_date_time`) VALUES
(1, '0.00', '0.00', 0, '0.00', '0.00', '0.00', '2022-03-21 17:45:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_received`
--

CREATE TABLE `tbl_received` (
  `id` int(11) NOT NULL,
  `fk_ledger_id` int(10) NOT NULL,
  `customer_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `token_no` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `xrf_man` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '''P''= Pass, ''F''=Fail',
  `lager_man` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '''Y''= Yes, ''N''= No',
  `total` decimal(10,2) DEFAULT NULL,
  `paid` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hallmark_type` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '''H''/''O''',
  `hallmark_rate` decimal(10,2) DEFAULT NULL,
  `hallmark_weight` decimal(10,3) DEFAULT NULL,
  `hallmark_piece` int(10) DEFAULT NULL,
  `hallmark_amount` decimal(10,2) DEFAULT NULL,
  `card_rate` decimal(10,2) NOT NULL,
  `card_weight` decimal(10,3) DEFAULT NULL,
  `card_piece` int(10) DEFAULT NULL,
  `card_amount` decimal(10,2) DEFAULT NULL,
  `photo_rate` decimal(10,2) NOT NULL,
  `photo_weight` decimal(10,3) DEFAULT NULL,
  `photo_piece` int(10) DEFAULT NULL,
  `photo_amount` decimal(10,2) DEFAULT NULL,
  `received_time` datetime NOT NULL,
  `delivery_time` datetime DEFAULT NULL,
  `delivery_weight` decimal(10,3) DEFAULT NULL,
  `is_delete` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'N' COMMENT '''Y''=yes, ''N''=no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_received_card`
--

CREATE TABLE `tbl_received_card` (
  `id` int(11) NOT NULL,
  `fk_received_id` int(11) NOT NULL,
  `weight` decimal(10,3) NOT NULL,
  `piece` int(5) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_received_hallmark`
--

CREATE TABLE `tbl_received_hallmark` (
  `id` int(11) NOT NULL,
  `fk_received_id` int(11) NOT NULL,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''H''/''O''',
  `weight` decimal(10,3) NOT NULL,
  `piece` int(5) NOT NULL,
  `purity` decimal(10,2) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL,
  `delivery_weight` decimal(10,3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_received_photo`
--

CREATE TABLE `tbl_received_photo` (
  `id` int(11) NOT NULL,
  `fk_received_id` int(11) NOT NULL,
  `weight` decimal(10,3) NOT NULL,
  `piece` int(5) NOT NULL,
  `remarks` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shop`
--

CREATE TABLE `tbl_shop` (
  `id` int(11) NOT NULL,
  `shop_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `proprietor_name` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `address` text COLLATE utf8_bin DEFAULT NULL,
  `ph_no` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `billing_name` varchar(25) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_shop`
--

INSERT INTO `tbl_shop` (`id`, `shop_name`, `proprietor_name`, `address`, `ph_no`, `email`, `billing_name`) VALUES
(1, 'SANATANI', '', '', '', '', 'S.H.C.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stock`
--

CREATE TABLE `tbl_stock` (
  `id` int(11) NOT NULL,
  `card` int(10) NOT NULL,
  `photo` int(10) NOT NULL,
  `rebons` int(10) NOT NULL,
  `paid_amount` decimal(10,2) NOT NULL,
  `customer_fund` decimal(10,2) NOT NULL,
  `xrf_checked` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'A' COMMENT '''A''=Active,''I''=Inactive',
  `updated_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_stock`
--

INSERT INTO `tbl_stock` (`id`, `card`, `photo`, `rebons`, `paid_amount`, `customer_fund`, `xrf_checked`, `updated_date_time`) VALUES
(1, 0, 0, 0, '0.00', '0.00', 'A', '2022-03-21 17:44:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stock_update`
--

CREATE TABLE `tbl_stock_update` (
  `id` int(11) NOT NULL,
  `type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''I''=In, ''R''=Reject, ''S''=Sell',
  `fk_received_id` int(11) DEFAULT NULL COMMENT 'If type=''S''',
  `fk_ledger_id` int(11) DEFAULT NULL,
  `stock_type` char(1) COLLATE utf8_bin NOT NULL COMMENT '''C''=Card, ''P''=Photo, ''R''= Rebons',
  `piece` int(5) NOT NULL,
  `balance` int(11) NOT NULL,
  `created_date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_customer_transection`
--
ALTER TABLE `tbl_customer_transection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_expenses`
--
ALTER TABLE `tbl_expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ledger`
--
ALTER TABLE `tbl_ledger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_own_fund`
--
ALTER TABLE `tbl_own_fund`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rate_update`
--
ALTER TABLE `tbl_rate_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_received`
--
ALTER TABLE `tbl_received`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_received_card`
--
ALTER TABLE `tbl_received_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_received_hallmark`
--
ALTER TABLE `tbl_received_hallmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_received_photo`
--
ALTER TABLE `tbl_received_photo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_shop`
--
ALTER TABLE `tbl_shop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_stock`
--
ALTER TABLE `tbl_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_stock_update`
--
ALTER TABLE `tbl_stock_update`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_customer_transection`
--
ALTER TABLE `tbl_customer_transection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_expenses`
--
ALTER TABLE `tbl_expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_ledger`
--
ALTER TABLE `tbl_ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_own_fund`
--
ALTER TABLE `tbl_own_fund`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_rate_update`
--
ALTER TABLE `tbl_rate_update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_received`
--
ALTER TABLE `tbl_received`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_received_card`
--
ALTER TABLE `tbl_received_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_received_hallmark`
--
ALTER TABLE `tbl_received_hallmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_received_photo`
--
ALTER TABLE `tbl_received_photo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_shop`
--
ALTER TABLE `tbl_shop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_stock`
--
ALTER TABLE `tbl_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_stock_update`
--
ALTER TABLE `tbl_stock_update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
