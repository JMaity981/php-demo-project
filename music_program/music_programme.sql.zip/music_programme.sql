--
-- Database: `music_programme`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `email` text COLLATE utf8_bin NOT NULL,
  `password` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`email`, `password`) VALUES
('jmaity721649@gmail.com', '7412');

-- --------------------------------------------------------

--
-- Table structure for table `band`
--

CREATE TABLE `band` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `full_name` text COLLATE utf8_bin NOT NULL,
  `short_name` text COLLATE utf8_bin NOT NULL,
  `profile_picture` varchar(255) COLLATE utf8_bin NOT NULL,
  `member_since` date NOT NULL,
  `professional` text COLLATE utf8_bin NOT NULL,
  `type` text COLLATE utf8_bin NOT NULL,
  `language` text COLLATE utf8_bin NOT NULL,
  `song` text COLLATE utf8_bin,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `band`
--

INSERT INTO `band` (`id`, `user_id`, `full_name`, `short_name`, `profile_picture`, `member_since`, `professional`, `type`, `language`, `song`, `created_at`) VALUES
(1, 0, 'Jayanta Maity', 'jmaity', 'JENPAUH-2018.jpg', '2015-12-09', 'Singer', 's:8:"Dj Mixer";', 's:13:"Hindi,Pungabi";', '', '2019-02-22 00:00:00'),
(2, 13, 'dwddsS SDVSDF', 'jmpo', 'Tara Pada Maity.png', '1985-07-19', 'Singer', 's:32:"Rapper,Composer,Remixer,Dj Mixer";', 's:21:"Bengali,English,Hindi";', NULL, '2019-02-27 12:56:31');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(10) NOT NULL,
  `fk_state_id` int(10) NOT NULL,
  `district_name` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `fk_state_id`, `district_name`) VALUES
(1, 1, 'Nicobar'),
(2, 1, '	North and Middle Andaman'),
(3, 1, 'South Andaman'),
(4, 2, '	Anantapur'),
(5, 2, 'Chittoor'),
(6, 2, 'East Godavari'),
(7, 2, 'Guntur'),
(8, 2, 'Kadapa'),
(9, 2, 'Krishna'),
(10, 2, 'Kurnool'),
(11, 2, 'Prakasam'),
(12, 2, 'Sri Potti Sriamulu Nellore'),
(13, 2, 'Srikakulam'),
(14, 2, 'Visakhapatnam'),
(15, 2, 'Vizianagaram'),
(16, 2, 'West Godavari'),
(17, 36, 'Alipurduar'),
(19, 36, 'Bankura'),
(20, 36, 'Pashim Bardhaman'),
(21, 36, 'Purba Bardhaman'),
(22, 36, 'Birbhum'),
(23, 36, 'Cooch Behar'),
(24, 36, 'Darjeeling'),
(25, 36, 'Uttar Dinajpur'),
(26, 36, 'Dakshin Dinajpur'),
(27, 36, 'Hooghly'),
(28, 36, 'Howrah'),
(29, 36, 'Jalpaiguri'),
(30, 36, 'Jhargram'),
(31, 36, 'Kolkata'),
(32, 36, 'Kalimpong'),
(33, 36, 'Malda'),
(34, 36, 'Paschim Medinipur'),
(35, 36, 'Purba Medinipur'),
(36, 36, 'Murshidabad'),
(37, 36, 'Nadia'),
(38, 36, 'North 24 Parganas'),
(39, 36, 'South 24 Parganas'),
(40, 36, 'Purulia');

-- --------------------------------------------------------

--
-- Table structure for table `sign_up_user`
--

CREATE TABLE `sign_up_user` (
  `id` int(10) NOT NULL,
  `name` text COLLATE utf8_bin NOT NULL,
  `gender` enum('M','F','O') COLLATE utf8_bin NOT NULL,
  `profile_pic` text COLLATE utf8_bin NOT NULL,
  `dob` date NOT NULL,
  `state` text COLLATE utf8_bin NOT NULL,
  `district` text COLLATE utf8_bin NOT NULL,
  `pin_code` int(6) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `email` text COLLATE utf8_bin NOT NULL,
  `password` varchar(15) COLLATE utf8_bin NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `sign_up_user`
--

INSERT INTO `sign_up_user` (`id`, `name`, `gender`, `profile_pic`, `dob`, `state`, `district`, `pin_code`, `mobile`, `email`, `password`, `created_at`, `updated_at`) VALUES
(13, 'Jayanta Maity', 'M', 'ace58f2becef2ef451d3e8e157e90c463eebca60606e3acfaa197c89d130a3da_4065673.jpg', '1997-02-06', '2', '9', 721649, 7866955855, 'jmaity721649@gmail.com', '12345678', '2019-02-13 13:04:50', '2019-02-13 13:04:50'),
(14, 'Asit Kumar Panda', 'F', 'Current-RCB-Squad (1).png', '1999-04-05', '2', '16', 789654, 8906969038, 'admin@gmail.com', '741258963', '2019-02-15 13:14:32', '2019-02-15 13:14:32');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(10) NOT NULL,
  `state_name` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state_name`) VALUES
(1, 'Andaman and Nicobar Islands'),
(2, 'Andhra Pradesh'),
(3, 'Arunachal Pradesh'),
(4, 'Assam'),
(5, 'Bihar'),
(6, 'Chandigarh'),
(7, 'Chhattisgarh'),
(8, 'Dadra and Nagar Haveli'),
(9, 'Daman and Diu'),
(10, 'National Capital Territory of Delhi'),
(11, 'Goa'),
(12, 'Gujrat'),
(13, 'Haryana'),
(14, 'Himachal Pradesh'),
(15, 'Jammu and Kashmir'),
(16, 'Jharkhand'),
(17, 'Karnataka'),
(18, 'Kerala'),
(19, 'Lakshaddweep'),
(20, 'Madhya Pradesh'),
(21, 'Maharashtra'),
(22, 'Manipur'),
(23, 'Meghalaya'),
(24, 'Mizoram'),
(25, 'Nagaland'),
(26, 'Odisha'),
(27, 'Puducherry'),
(28, 'Punjab'),
(29, 'Rajasthan'),
(30, 'Sikkim'),
(31, 'Tamil Nadu'),
(32, 'Telangana'),
(33, 'Tripura'),
(34, 'Uttar Pradesh'),
(35, 'Uttarakhand'),
(36, 'West Bengal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `band`
--
ALTER TABLE `band`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign_up_user`
--
ALTER TABLE `sign_up_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `band`
--
ALTER TABLE `band`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `sign_up_user`
--
ALTER TABLE `sign_up_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
