<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\OpeningBalance;

use App\Models\Mlogin;
use Carbon\Carbon;

class OpeningBalanceCtrl extends Controller
{
    public function openingBalance (){
		$data['main_menu'] = 'mnu_opening_balance';
		$data['sub_menu'] = '';
		$data['breadcrumb'] = [['opening-balance', 'Opening Balance']];
        return view('openingBalance.openingBalance')->withData($data);
    }
	/*================ add opening balance =================*/
	public function addOpeningBalance (Request $request){
		$h_name= $request->h_name;
		$date = Carbon::now();

		$stockArr =[
			'alloy_parchan' => $request->parchanalloy,
			'alloy_gold' 	=> $request->goldalloy,
			'fine_stock'	=> $request->finegold,
			'cash_stock'	=> $request->cashamaount,
			'updated_date_time' => $date
		];
		if($h_name == ""){
			$addstock = OpeningBalance::insert($stockArr);
			if($addstock){
				$return['key'] = 'S';
				$return['msg'] = 'Stock added Successfully.';
			}else{
				$return['key'] = 'E';
				$return['msg'] = 'Stock not Added.';
			}
		}else{
			$updatestock = OpeningBalance::where('id', $h_name)->update($stockArr);
			//update batch no
			$getbatchno = OpeningBalance::get()->toArray();
			$incriment = ($getbatchno[0]['batch_no'])+1;
			$updatebatchno = OpeningBalance::where('id', 1)->update(['batch_no' => $incriment]);
		    if($updatestock && $updatebatchno){
				$return['key'] = 'S';
				$return['msg'] = 'Stock update Successfully.';
			}
			else{
				$return['key'] = 'E';
				$return['msg'] = 'Please Update your stock.';
			}
		}
		return $return;
		// $cashamaount = $request->cashamaount;
		// $goldamaoun = $request->goldamaount;
		// if($cashamaount == '' && $goldamaoun == ''){
		// 	$return['key'] = 'E';
		// 	$return['msg'] = 'Plese enter one value.';
		// }else{
		// 	//gold check
		// 	if($goldamaoun != ''){
		// 		$goldcount = OpeningBalance::where('balance_in_gold','!=', '')->count();
		// 		if($goldcount > 0){
		// 			$return['key'] = 'E';
		// 			$return['msg'] = 'Gold already exist.';
		// 		}else{
		// 			$goldinsarr = [
		// 				'balance_in_gold' => $goldamaoun,
		// 				'gold_balance_datetime' => date('Y-m-d H:i:s'),
		// 			];
		// 			$goldinsert = OpeningBalance::insert($goldinsarr);
		// 			$return['key'] = 'S';
		// 			$return['msg'] = 'Value successfully added.';
		// 		}
		// 	}
		// 	//cash check 
		// 	if($cashamaount != ''){
		// 		$cashcount = OpeningBalance::where('balance_in_cash', '!=', '')->count();
		// 		if($cashcount > 0){
		// 			$return['key'] = 'E';
		// 			$return['msg'] = 'Cash already exist.';
		// 		}else{
		// 			$cashindarr = [
		// 				'balance_in_cash' => $cashamaount,
		// 				'cash_balance_datetime' => date('Y-m-d H:i:s'),
		// 			];
		// 			$cashinsert = OpeningBalance::insert($cashindarr);
		// 			$return['key'] = 'S';
		// 			$return['msg'] = 'Value successfully added.';
		// 		}
		// 	}
		// }
		// return $return;
    }
	/*======================= Get opening balance ==============*/
	public function getOpeningBalance (){
		$data = [];
		//get gold value
		$goldcount = OpeningBalance::where('fine_stock','!=', '')->count();
		if($goldcount > 0){
			$data['goldvalue'] = OpeningBalance::where('fine_stock','!=', '')->get(['fine_stock','updated_date_time'])->toArray(); 
		}
		//print_r($data['goldvalue']);die;
		//get cash value
		$cashcount = OpeningBalance::where('cash_stock', '!=', '')->count();
		//print_r($cashcount);die;
		if($cashcount > 0){
			$data['cashvalue'] = OpeningBalance::where('cash_stock','!=', '')->get(['cash_stock','updated_date_time'])->toArray();
		}
		$data['alloyparchan'] = OpeningBalance::where('alloy_parchan','!=', '')->get(['alloy_parchan','updated_date_time'])->toArray();
		$data['alloygold'] = OpeningBalance::where('alloy_gold','!=', '')->get(['alloy_gold','updated_date_time'])->toArray();
		//print_r($data['cashvalue']);die;
		$return['gold_disable'] = $goldcount;
		$return['cash_disable'] = $cashcount;
		$return['html'] = view('openingBalance.renderOpeningBalanceList')->withData($data)->render();
		return $return;
		
	}
	public function openingBalanceEdit(Request $request){
		// print_r($request->all());die;
		$password= $request['password'];
		$encode_password = base64_encode($password);
		// print_r($encode_password);die;
		$password_qry = Mlogin::where('opening_balance_psw', $encode_password)->get(['id'])->toArray();
		$countrow = count($password_qry);

		if($countrow > 0){
		 $qry = OpeningBalance::get()->toArray();
		 $data['qry']= $qry;
		 $data['id']= $password_qry;
         $data['key'] = 'S';
		}else{
			$data['key'] = 'E';
			$data['msg']= 'Please Enter valid password.';
		}
		return $data;
    }
}
