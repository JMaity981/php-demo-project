<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\OpeningBalance;
use App\Models\Booking;
use App\Models\FundCreditDebit;
use App\Models\Lager;
use App\Models\SalePurchase;
use App\Models\Exchange;

use DirectoryIterator;
use ZipArchive;
use \RecursiveIteratorIterator;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	
	//get serial no 
	//public function get
	public function getLagerData (Request $request){
		//print_r($request->all());die;
		$c_id = $request->propId;
		//get lager details
        $data['lager_details'] = Lager::where('id',$c_id)->get()->toArray();
		
		//get booking total weight
		$data['booking'] = Booking::where('fk_lager_id', $c_id)->where('is_deliverd','N')->where('is_cancel','N')->sum('weight');
		
		//get gold value
		// $allgoldcredit = FundCreditDebit::where('fk_lager_id', $c_id)->where('type','G')->where('transaction_type','C')->sum('weight');
		// $allgolddebit = FundCreditDebit::where('fk_lager_id', $c_id)->where('type','G')->where('transaction_type','D')->sum('weight');
		// $data['gold_value'] = ($allgoldcredit - $allgolddebit);
		
		//get cash value
		// $cashdebit_exchange = Exchange::where('fk_lager_id', $c_id)->where('received_status','D')->sum('service_charge');
		// $cashdebit_salepurchase = SalePurchase::where('fk_lager_id', $c_id)->where('type','S')->sum('total_amount');
		// $cashcredit_salepurchase = SalePurchase::where('fk_lager_id', $c_id)->where('type','S')->sum('pay_amount');
		// $cashcredit_fundcreditdebit = FundCreditDebit::where('fk_lager_id', $c_id)->where('transaction_type','C')->where('type','C')->sum('amount');
		// $cashdedit_fundcreditdebit = FundCreditDebit::where('fk_lager_id', $c_id)->where('transaction_type','C')->where('type','D')->sum('amount');

		// $allcashcredit = $cashcredit_salepurchase + $cashcredit_fundcreditdebit;
		// $allcashdebit = $cashdebit_exchange + $cashdebit_salepurchase + $cashdedit_fundcreditdebit;
		// $data['cash_value'] = ($allcashcredit - $allcashdebit);
        return $data;
	}
	//get gold cash details
	public function getGoldCashDetails (Request $request){
		$val = OpeningBalance::get()->toArray();
		return $val;
	}
	/*----------------- Create zip folder in the server ---------------*/
	public function zipDownload ($filename){
		//print_r($filename);die;
		$filenameexp = explode('/', $filename);
		
		$rootPath = $filename;
		
        $fileName = storage_path('zip-pdf/'.$filenameexp[1].'.zip');
        $zip = new ZipArchive;
        if ($zip->open($fileName, ZipArchive::CREATE) === TRUE)
        {
			foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($rootPath)) as $filename) {
				$files[] = $filename;
			}
			foreach ($files as $name => $file)
			{
				if (!$file->isDir())
				{
					$filePath = $file->getRealPath();
					$relativePath = substr($filePath, strlen($rootPath) + 1);

					$zip->addFile($filePath, $relativePath);
				}
			}
			$zip->close();
        }
	}
	/*------------------ Zip download in the local server -----------------*/
	public function saveZipFile(Request $request){
		//print_r($request->all());die;
		$filename = $request->filename;
		$fileurl = storage_path('zip-pdf/'.$filename.'.zip');
		return Response::download($fileurl, ''.$filename.'.zip', array('Content-Type: application/octet-stream','Content-Length: '. filesize($fileurl)))->deleteFileAfterSend(true);
	}
}
